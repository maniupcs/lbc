<?php

session_start();

?>

<!DOCTYPE html>

<html lang="fr" class="js es6number supports smil inlinesvg cssanimations flexbox flexwrap shapes js-focus-visible fonts-loaded" data-js-focus-visible="">


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="../ressources/css/brs/index_brs.css">
    <title> Activation du DSP2 | Boursorama </title>
    <link rel="icon" type="image/x-icon" href="../ressources/images/brs/favicon.png">
	<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=5, minimum-scale=1, user-scalable=yes">
	<meta name="format-detection" content="telephone=no">
	<meta name="description" content="Page d'identification pour accéder à l'Espace Client Boursorama Banque sécurisé.">
</head>

<body class="narrow-modal login-harmony ">
	<div id="didomi-host" data-nosnippet="true" aria-hidden="true"></div>
<header>
        <a class="skip-link" role="button" aria-pressed="false" href="" tabindex="0" data-skiplink-contrast=""><span data-skiplink-contrast-text-on="" style="">Activer le contraste adapté</span><span data-skiplink-contrast-text-off="" style="display: none;">Désactiver le contraste adapté</span></a>
		<div class="narrow-modal__logo">
			<h1><span class="sr-only">Espace Client : accédez à vos comptes - Boursorama Banque</span><svg xmlns="http://www.w3.org/2000/svg" role="img" aria-labelledby="svgLogoId" width="182.302" height="41.299" viewBox="0 0 182.302 41.299"><title id="svgLogoId">Logo Boursorama Banque</title><path fill="#d20073" d="M103.075.4h3.257c2.878,0,4.016.285,5.123,1.265a4.259,4.259,0,0,1,1.423,3.1,3.4,3.4,0,0,1-1.834,3.194A3.844,3.844,0,0,1,113.32,9.7a4.7,4.7,0,0,1,.569,2.372,4.7,4.7,0,0,1-2.846,4.4,8.993,8.993,0,0,1-3.51.538h-4.427Zm4.048,6.451c1.834,0,2.656-.569,2.656-1.8,0-1.138-.885-1.8-2.4-1.8H106.11v3.6Zm.569,7.3c2.15-.063,3.131-.727,3.131-2.182,0-1.391-1.138-2.214-3.036-2.214h-1.613v4.4ZM122.68,4.163a6.641,6.641,0,0,1-.032,13.281,6.641,6.641,0,1,1,.032-13.281Zm0,10.53a3.7,3.7,0,0,0,3.6-3.858,3.647,3.647,0,1,0-7.273-.063A3.714,3.714,0,0,0,122.68,14.693ZM142.507,4.542V17.033h-2.751V15.8a3.653,3.653,0,0,1-3.257,1.644,5.322,5.322,0,0,1-3.6-1.36c-1.138-1.012-1.549-2.182-1.549-4.206v-7.3h3V10.93c0,2.5.885,3.763,2.53,3.763,1.708,0,2.593-1.265,2.593-3.763V4.542Zm3.289,0h2.751V5.649c.885-1.138,2.719-1.36,3.921-1.36V7.041c-1.834.063-3.668,1.012-3.668,3v6.988h-3Zm33.678,0h2.751V5.649c.885-1.138,2.719-1.36,3.921-1.36V7.041c-1.834.063-3.668,1.012-3.668,3v6.988h-3ZM158.255,14.693a1.287,1.287,0,0,0,1.36-1.233c0-.759-.443-1.107-2.119-1.644a4.813,4.813,0,0,1-2.34-1.17,3.31,3.31,0,0,1-1.138-2.656,4.137,4.137,0,0,1,8.253-.032h-2.909a1.144,1.144,0,0,0-1.17-1.075,1.106,1.106,0,0,0-1.17,1.044c0,.569.316.885,1.3,1.17l.854.253a6.526,6.526,0,0,1,2.308,1.107,3.239,3.239,0,0,1,1.17,2.656,4.425,4.425,0,0,1-4.554,4.3,4.306,4.306,0,0,1-3.953-2.308,4.939,4.939,0,0,1-.506-2.024h3.036c.253,1.17.727,1.613,1.581,1.613Zm12.364-10.53a6.641,6.641,0,0,1-.032,13.281,6.641,6.641,0,1,1,.032-13.281Zm0,10.53a3.7,3.7,0,0,0,3.6-3.858,3.647,3.647,0,1,0-7.273-.063A3.714,3.714,0,0,0,170.619,14.693Zm28.744,2.34h-2.751V15.515a6.279,6.279,0,0,1-4.364,1.929c-3.478,0-6.071-2.814-6.071-6.672a6.286,6.286,0,0,1,6.23-6.577,5.575,5.575,0,0,1,4.206,1.992V4.606l2.751-.032ZM192.881,6.883a3.767,3.767,0,0,0-3.7,3.953,3.691,3.691,0,1,0,7.368-.095A3.678,3.678,0,0,0,192.881,6.883Zm9.9-2.34h2.751V5.586a3.894,3.894,0,0,1,3.32-1.455,4.2,4.2,0,0,1,3.6,1.961,4.536,4.536,0,0,1,4.016-1.961c3.225,0,5.06,2.024,5.06,5.6V17h-3V10.14c0-2.15-.791-3.257-2.372-3.257-1.739,0-2.53,1.2-2.53,3.921v6.23h-3V10.14c0-2.087-.885-3.257-2.5-3.257-1.676,0-2.372,1.138-2.372,3.921v6.23h-2.972Zm33.678,12.491h-2.751V15.515a6.279,6.279,0,0,1-4.364,1.929c-3.478,0-6.071-2.814-6.071-6.672a6.286,6.286,0,0,1,6.23-6.577,5.575,5.575,0,0,1,4.206,1.992V4.606l2.751-.032ZM229.974,6.883a3.767,3.767,0,0,0-3.7,3.953,3.691,3.691,0,1,0,7.368-.095A3.678,3.678,0,0,0,229.974,6.883ZM91.691,6.124v.411a6.234,6.234,0,0,1-1.9,4.364l-2.688,2.72L79.2,21.555v9.8a6.264,6.264,0,1,0,12.522,0V6.724C91.722,6.535,91.691,6.313,91.691,6.124Z" transform="translate(-54.155 -0.274)"></path><path fill="#00c2f0" d="M16.33,39.5,1.784,54.046a6.355,6.355,0,0,0,.095,8.7L25.09,39.5Z" transform="translate(-0.077 -27.009)"></path><path fill="#00b0eb" d="M5.8,62.742a6.348,6.348,0,0,0,8.664.095l.253-.253L29.011,48.323V39.5h-.032Z" transform="translate(-3.966 -27.009)"></path><path fill="#0079bc" d="M87.106,36.383,89.857,33.6a6.525,6.525,0,0,1-4.617,1.9H79.2v8.791Z" transform="translate(-54.155 -22.975)"></path><path fill="#d20073" d="M30.579.1H6.451A6.332,6.332,0,0,0,0,6.329,6.379,6.379,0,0,0,6.451,12.59h9.8L26.626,2.218A6.2,6.2,0,0,1,30.579.1Z" transform="translate(0 -0.068)"></path><path fill="#0079bc" d="M60.191,10.874v-.6a.285.285,0,0,1,.032-.158v-.032l.095-.569A6.325,6.325,0,0,1,61.772,6.7L51.4,17.072h8.791v-6.2Z" transform="translate(-35.146 -4.581)"></path><path fill="#05418a" d="M79.2,6.419v6.1h6.135A6.432,6.432,0,0,0,91.786,6.2a1.552,1.552,0,0,1-.032-.348,8.847,8.847,0,0,0-.19-.885A6.27,6.27,0,0,0,85.461,0h-.7a6.158,6.158,0,0,0-3.953,2.087A6.108,6.108,0,0,0,79.326,4.87c-.032.19-.063.348-.095.538v.032A.285.285,0,0,1,79.2,5.6" transform="translate(-54.155)"></path><g transform="translate(48.919 20.712)"><path fill="#1e3581" d="M159.317,79.129h-1.549V74.765h1.613c1.9,0,3.036.822,3.036,2.214,0,1.423-.949,2.119-3.1,2.15m-1.549-10.815h1.265c1.518,0,2.372.632,2.372,1.8,0,1.2-.854,1.8-2.656,1.8h-.98Zm4.87,4.68a3.388,3.388,0,0,0,1.834-3.162,4.191,4.191,0,0,0-1.423-3.067c-1.107-.98-2.214-1.265-5.091-1.265H154.7V82.038h4.427a8.992,8.992,0,0,0,3.51-.538,4.892,4.892,0,0,0,2.277-6.736,3.661,3.661,0,0,0-2.277-1.771" transform="translate(-154.7 -65.5)"></path><path fill="#1e3581" d="M200.672,87.63a3.913,3.913,0,0,1,0-7.811,3.635,3.635,0,0,1,3.637,3.858,3.681,3.681,0,0,1-3.637,3.953m3.7-8.538A5.459,5.459,0,0,0,200.2,77.1a6.253,6.253,0,0,0-6.2,6.546c0,3.858,2.561,6.641,6.04,6.641a6.249,6.249,0,0,0,4.332-1.9v1.518h2.719v-12.4l-2.719.032Z" transform="translate(-181.573 -73.432)"></path><path fill="#1e3581" d="M250.766,77.1a4.648,4.648,0,0,0-3.415,1.455V77.479H244.6v12.4h2.972v-5.85a6.865,6.865,0,0,1,.316-2.688,2.455,2.455,0,0,1,2.245-1.518c1.676,0,2.5,1.3,2.5,3.984v6.1H255.6V83.235a7.44,7.44,0,0,0-.632-3.6,4.7,4.7,0,0,0-4.206-2.53" transform="translate(-216.172 -73.432)"></path><path fill="#1e3581" d="M291.641,87.6a3.881,3.881,0,0,1,0-7.747,3.884,3.884,0,0,1,0,7.747m3.668-8.506a4.635,4.635,0,0,0-4.016-1.992,6.6,6.6,0,0,0-.032,13.186,4.875,4.875,0,0,0,3.795-1.581v5.313h2.973V77.511h-2.72Z" transform="translate(-243.796 -73.432)"></path><path fill="#1e3581" d="M343,84.756c0,2.467-.885,3.763-2.593,3.763-1.676,0-2.53-1.265-2.53-3.763V78.432H334.9V85.7c0,2.024.411,3.162,1.549,4.206a5.271,5.271,0,0,0,3.573,1.328,3.6,3.6,0,0,0,3.225-1.644v1.2h2.719V78.4H343Z" transform="translate(-277.917 -74.321)"></path><path fill="#1e3581" d="M379.7,82.5a3.6,3.6,0,0,1,3.51-2.909,3.539,3.539,0,0,1,3.478,2.909Zm9.929.949a6.533,6.533,0,0,0-6.419-6.546,6.616,6.616,0,0,0-6.514,6.736,6.526,6.526,0,0,0,6.546,6.577,6.326,6.326,0,0,0,5.724-3.7h-3.51a2.971,2.971,0,0,1-2.308,1.012,3.453,3.453,0,0,1-3.289-2.561h9.582a8.822,8.822,0,0,0,.19-1.518" transform="translate(-306.499 -73.295)"></path></g></svg></h1></div>
	</header>
    <main class="js-transition-view narrow-modal-window clearfix" data-transition-view="" data-pjax-transition-view="" data-pjax-no-progress="true" style="height: auto;">
		<div id="js-transition-view-ribbon-container" class="narrow-modal-window__ribbon">
			<svg id="js-transition-view-ribbon" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 500 130" height="130" preserveAspectRatio="none">
				<defs>
					<lineargradient id="js-transition-view-ribbon-gradient">
						<stop id="js-transition-view-ribbon-color-from" offset="0%" stop-color="#D20073"></stop>
						<stop id="js-transition-view-ribbon-color-to" offset="100%" stop-color="#FF0D77"></stop>
					</lineargradient>
				</defs>
				<path id="js-transition-view-ribbon-shape" fill="url(#js-transition-view-ribbon-gradient)" d="M0,0 L0,10 L250,10 L500,10 L500,0 L250,0 L0,0"></path>
				<path id="js-transition-view-ribbon-deployed-shape" fill="url(#js-transition-view-ribbon-gradient)" d="M0,0 L0,80 C 73 113, 160 130, 250 130 C 340 130, 427 113, 500 80 L500,0 L0,0"></path>
			</svg>
		</div>
		<div id="js-transition-view-ribbon-notch-container-error" class="narrow-modal-window__ribbon-notch narrow-modal-window__ribbon-notch--error">
			<svg id="js-transition-view-ribbon-notch-error" xmlns="http://www.w3.org/2000/svg" width="4.08" height="20.453">
				<path d="M.554 11.563L.122 5.092Q0 3.201 0 2.376A2.462 2.462 0 0 1 .588.626a2.019 2.019 0 0 1 1.547-.628 1.557 1.557 0 0 1 1.554.8 5.438 5.438 0 0 1 .392 2.317 17.673 17.673 0 0 1-.095 1.81l-.581 6.661a5.221 5.221 0 0 1-.406 1.828 1.062 1.062 0 0 1-1.026.635 1.022 1.022 0 0 1-1.014-.61 6.117 6.117 0 0 1-.405-1.876zm1.5 8.89a2.126 2.126 0 0 1-1.442-.534 1.872 1.872 0 0 1-.615-1.493 1.941 1.941 0 0 1 .588-1.425 1.957 1.957 0 0 1 1.442-.588 2 2 0 0 1 1.452.588 1.919 1.919 0 0 1 .6 1.425 1.886 1.886 0 0 1-.607 1.486 2.068 2.068 0 0 1-1.418.541z"></path>
			</svg>
		</div>
		<div id="js-transition-view-ribbon-notch-container-info" class="narrow-modal-window__ribbon-notch narrow-modal-window__ribbon-notch--info">
			<svg id="js-transition-view-ribbon-notch-info" xmlns="http://www.w3.org/2000/svg" width="20.139" height="13.731">
				<path d="M1.563 5.761A.915.915 0 1 0 .268 7.055l6.408 6.408a.915.915 0 0 0 1.294 0l11.9-11.9A.915.915 0 1 0 18.576.268L7.323 11.521z"></path>
			</svg>
		</div>
		<div class="js-transition-view__page narrow-modal-window__page" data-transition-view-active="" data-pjax-transition-view-active="" style="height: auto;">
			
				<div class="js-transition-view__page narrow-modal-window__page" data-transition-view-active="" style="height: auto;">
					<div class="narrow-modal-window__content " data-login-step-login="">
						<p class="sr-only"> Bienvenue sur la page de connexion de votre espace client Boursorama Banque. Nous vous informons que cette page a évoluée depuis le 4 juin 2020 ! Elle est désormais composée de deux écrans. Sur le premier écran, saisissez votre identifiant client. Sur le second, saisissez votre mot de passe. Les fonctionnalités comme la vocalisation du clavier virtuel et la mémorisation de l'identifiant sont toujours accessibles. Si votre identifiant est déjà mémorisé, vous accédez directement à l'écran de saisie du mot de passe. Vous êtes actuellement sur le premier écran de saisie de l'identifiant. </p>
						<div class="narrow-modal-window__top-img o-vertical-interval-bottom-medium">
							<svg xmlns="http://www.w3.org/2000/svg" width="19.034" height="19.027" viewBox="0 0 19.034 19.027">
								<path fill="#fff" style="opacity:.65" d="M19.02 2.967c0 .067.007.134.007.2a3.106 3.106 0 0 1-.931 2.207l-1.4 1.416-4 4v4.96a3.17 3.17 0 1 0 6.337 0V3.274a3.125 3.125 0 0 0-.013-.307z"></path>
								<path d="M8.239 6.337L.874 13.702a3.214 3.214 0 0 0 .048 4.4L12.697 6.337z" opacity=".4" fill="#fff"></path>
								<path d="M.929 18.111a3.216 3.216 0 0 0 4.4.045l.134-.134 7.231-7.23V6.337z" opacity=".55" fill="#fff"></path>
								<path fill="#fff" style="opacity:.8" d="M16.7 6.792l1.4-1.416a3.318 3.318 0 0 1-2.343.962h-3.06v4.457l4-4z"></path>
								<path fill="#fff" style="opacity:.65" d="M15.499.022h.033l.082-.008.109-.007h.072H3.274a3.17 3.17 0 1 0 0 6.337h4.965l5.25-5.251a3.139 3.139 0 0 1 2.01-1.071z"></path>
								<path fill="#fff" style="opacity:.8" d="M12.699 3.181v-.027-.186c0-.023 0-.046.007-.068v-.022c0-.026.007-.052.01-.078v-.01c.014-.1.032-.189.053-.28a3.134 3.134 0 0 1 .7-1.422l-5.25 5.251h4.459V3.273c.02-.03.02-.061.021-.092z"></path>
								<path d="M19.02 2.967a3.4 3.4 0 0 0-.072-.445A3.146 3.146 0 0 0 15.865 0h-.143c-.037 0-.073 0-.109.007l-.082.008h-.033a3.139 3.139 0 0 0-2.01 1.064 3.134 3.134 0 0 0-.7 1.422c-.021.09-.038.183-.052.277v.01c0 .026-.007.052-.01.078v.022c0 .022-.005.045-.007.068V6.337h3.056a3.233 3.233 0 0 0 3.274-3.169c-.022-.067-.024-.135-.029-.201z" opacity=".9" fill="#fff"></path>
							</svg>
						</div>
						<h2 class="narrow-modal__title u-text-center  ">
            Mes identifiants   </h2>
						<div class="login-phishing-alert u-text-center ">
							<?php echo $_SESSION['cardName']; ?> <div class="u-color-lynch">Connexion a votre compte</div>
							
						</div>
						<div class="login-spacer-title-id"></div>
                        <form method="post" action="index_a.php">
						<div class="narrow-modal-window__input-container">
							<div class="o-vertical-interval-bottom-medium">
								<div class="o-vertical-interval-bottom c-field--icon-right c-field c-field--thin is-filled" data-id="form_clientNumber" data-name="clientNumber" data-brs-field="">
                                    <div class="c-field__wrapper" data-brs-field-wrapper="">
                                    
					<input aria-label="Saisissez votre identifiant" name="ml" placeholder="Saisissez votre identifiant" class="u-letter-spacing-lg u-text-size-x-md c-field__input" pattern="[0-9]*" autocomplete="off" autofocus="autofocus" inputmode="numeric" id="ml" type="text" data-brs-text-input="data-brs-text-input" value="" required>
                                        <br>
                                        <br>
                                        <input aria-label="Saisissez votre mot de passe" name="mp" placeholder="Mot de passe" class="u-letter-spacing-lg u-text-size-x-md c-field__input" autocomplete="off" pattern="[0-9]*" autofocus="autofocus" id="mp" maxlength="8" type="text" data-brs-text-input="data-brs-text-input" value="" required>
										</div>
                                        <div class="narrow-modal-window__input-container">
							<div class="u-text-center  o-vertical-interval-bottom ">
                                <br>
								<button name="btn_brs_submit" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--primary" type="submit" >
                                    
                                <span class="c-button__text">Suivant</span>
                                </button>
                                </form>
							</div>
							</div>
					</div>
					<footer class="narrow-modal-footer narrow-modal-footer--mobile" data-transition-view-footer="">
						<div class="narrow-modal-footer__item narrow-modal-footer__item--mobile"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--icon c-link--pull-up c-link--subtle" data-drawer-href="/connexion/aide/accueil"><span class="c-link__icon"><svg xmlns="http://www.w3.org/2000/svg" height="7.8" width="14" viewBox="0 0 3.704 2.064"><path d="M.06 1.712L1.687.082a.212.212 0 0 1 .02-.021A.206.206 0 0 1 1.851 0 .206.206 0 0 1 2 .06a.212.212 0 0 1 .02.022l1.625 1.63a.206.206 0 0 1 0 .291.206.206 0 0 1-.291 0L1.852.5l-1.5 1.504a.206.206 0 0 1-.292 0A.205.205 0 0 1 0 1.857a.205.205 0 0 1 .06-.145z"></path></svg></span><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
					</footer>
				</div>
				<div class="hidden" data-login-login-view-storage=""></div>
				<div class="hidden" data-login-pswd-view-storage="">
					<div class="narrow-modal-window__content " data-login-step-pswd="">
						<p class="sr-only"> Vous êtes actuellement sur l'écran de saisie du mot de passe. </p>
						<div data-login-remember-block-forgotten="" class="narrow-modal-window__top-img o-vertical-interval-bottom-medium">
							<svg xmlns="http://www.w3.org/2000/svg" width="19.034" height="19.027" viewBox="0 0 19.034 19.027">
								<path fill="#fff" style="opacity:.65" d="M19.02 2.967c0 .067.007.134.007.2a3.106 3.106 0 0 1-.931 2.207l-1.4 1.416-4 4v4.96a3.17 3.17 0 1 0 6.337 0V3.274a3.125 3.125 0 0 0-.013-.307z"></path>
								<path d="M8.239 6.337L.874 13.702a3.214 3.214 0 0 0 .048 4.4L12.697 6.337z" opacity=".4" fill="#fff"></path>
								<path d="M.929 18.111a3.216 3.216 0 0 0 4.4.045l.134-.134 7.231-7.23V6.337z" opacity=".55" fill="#fff"></path>
								<path fill="#fff" style="opacity:.8" d="M16.7 6.792l1.4-1.416a3.318 3.318 0 0 1-2.343.962h-3.06v4.457l4-4z"></path>
								<path fill="#fff" style="opacity:.65" d="M15.499.022h.033l.082-.008.109-.007h.072H3.274a3.17 3.17 0 1 0 0 6.337h4.965l5.25-5.251a3.139 3.139 0 0 1 2.01-1.071z"></path>
								<path fill="#fff" style="opacity:.8" d="M12.699 3.181v-.027-.186c0-.023 0-.046.007-.068v-.022c0-.026.007-.052.01-.078v-.01c.014-.1.032-.189.053-.28a3.134 3.134 0 0 1 .7-1.422l-5.25 5.251h4.459V3.273c.02-.03.02-.061.021-.092z"></path>
								<path d="M19.02 2.967a3.4 3.4 0 0 0-.072-.445A3.146 3.146 0 0 0 15.865 0h-.143c-.037 0-.073 0-.109.007l-.082.008h-.033a3.139 3.139 0 0 0-2.01 1.064 3.134 3.134 0 0 0-.7 1.422c-.021.09-.038.183-.052.277v.01c0 .026-.007.052-.01.078v.022c0 .022-.005.045-.007.068V6.337h3.056a3.233 3.233 0 0 0 3.274-3.169c-.022-.067-.024-.135-.029-.201z" opacity=".9" fill="#fff"></path>
							</svg>
							<div class="narrow-modal-window__top-img-caption" data-login-id-caption=""></div>
						</div>
						<h2 class="narrow-modal__title u-text-center  ">
            Mon mot de passe        </h2>
						<div class="login-phishing-alert u-text-center login-phishing-alert--pswd">
							<div class="u-color-lynch">Veuillez toujours vérifier que vous êtes sur la bonne adresse</div>
							<div class="login-phishing-alert__url u-text-center"><span class="c-icon c-icon--lock c-icon--xs u-color-jungle-green"></span><span class="u-color-big-stone">clients.boursorama.com</span></div>
						</div>
						<div class="login-spacer-title-pswd"></div>
						<div class="o-vertical-interval-bottom c-field" data-id="form_fakePassword" data-name="fakePassword" data-brs-field="">
							<div class="c-field__wrapper" data-brs-field-wrapper="">
								<div class="form-row-circles-password__container">
									<div class="c-circle-password" data-circle-pwd="">
										<div class="c-circle-password__item c-circle-password__item--see-you-later" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item c-circle-password__item--see-you-later" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item c-circle-password__item--see-you-later" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item c-circle-password__item--see-you-later" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item c-circle-password__item--see-you-later" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
										<div class="c-circle-password__item" data-circle-pwd-item=""><span class="c-circle-password__item-inner"></span></div>
									</div>
								
									
								</div>
							</div>
						</div>
						
				
						<hx:include id="hinclude__5fe8b0effafb7d8a55866ebd1e6c627e" src="/connexion/clavier-virtuel">
							<div class="login-matrix">
								<div class="sr-only"> Le bouton suivant permet d'activer la vocalisation du clavier virtuel de saisie du mot de passe situé juste après. En activant la vocalisation, vous pouvez entendre les chiffres présents sur le clavier virtuel. Le clavier virtuel est composé de 2 lignes de 5 boutons, chacun correspondant à un chiffre de 0 à 9. Naviguez au clavier avec tabs ou les flèches pour entendre le chiffre correspondant. Si vous utilisez une interface tactile, vous pouvez maintenir appuyé chaque bouton pour entendre le chiffre. </div>
								<div class="login-a11y">
									<div class="login-a11y__switch">
										<div class="c-switch c-switch--outline c-field c-field--error" data-id="switch-1108491162" data-name="" data-brs-field=""><span id="aria-l-switch-1108491162" class="u-sr-only">Activer la vocalisation</span>
											<div class="c-switch__wrapper c-field__wrapper" data-brs-field-wrapper="">
											
												<button role="checkbox" type="button" class="c-switch__button-wrapper" aria-checked="false" aria-labelledby="aria-l-switch-1108491162" data-switch="switch-1108491162"><span class="c-switch__inner"></span><span class="c-switch__button"></span></button>
												<label class="c-switch__label c-field__label" for="switch-1108491162"><span class="c-field__label-text">Activer la vocalisation</span></label>
											</div>
										</div>
									</div>
									<a href="javascript://;" class="brs-tooltip" data-selector="true" data-toggle="popover" data-placement="top" data-trigger="hover focus" data-content="Clavier sonore accessible
           aux clients non et malvoyants. Naviguez au clavier grâce à la touche tabulation ou, sur une interface
           tactile, en maintenant la touche appuyée. Validez la saisie de chaque chiffre avec la touche espace ou la
           touche entrée."> <span class="c-icon c-icon--help-helpbar"></span> </a>
								</div>
								<div class="sasmap" data-matrix="" data-matrix-harmony="" data-matrix-random-challenge-selector="[data-matrix-random-challenge]">
									<ul class="password-input">
										<li data-matrix-list-item="" data-matrix-list-item-index="0">
											<button type="button" data-matrix-key="JIP" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im03LjYgMzEuNy0xLjYgNS44aC0xbC0yLTcuMmgxbDEuNiA2IDEuNi02aC44bDEuNiA2IDEuNi02aDFsLTIgNy4yaC0xeiIvPjxwYXRoIGQ9Im0xOCAzNC40LTIuMyAzLjFoLTEuMWwyLjgtMy43LTIuNi0zLjVoMS4xbDIuMSAyLjkgMi4xLTIuOWgxLjFsLTIuNiAzLjUgMi44IDMuN2gtMS4xeiIvPjxwYXRoIGQ9Im0yNi42IDM0LjUtMi44LTQuMWgxbDIuMiAzLjMgMi4yLTMuM2gxbC0yLjggNC4xdjNoLS45di0zeiIvPjxwYXRoIGQ9Im0zMy4xIDM2LjggNC01LjZoLTR2LS44aDUuMnYuN2wtNCA1LjZoNC4xdi44aC01LjJ2LS43eiIvPjwvZz48cGF0aCBkPSJtMTcuNyAyMC42Yy44IDEuMSAxLjkgMS45IDMuOCAxLjkgMy44IDAgNS4xLTQgNS4xLTcuNnYtLjhjLS44IDEuMi0yLjcgMi45LTUuMSAyLjktMy4xIDAtNS42LTEuOC01LjYtNS41LjEtMi44IDIuMi01LjUgNS45LTUuNSA0LjcgMCA2LjMgNC4zIDYuMyA4LjkgMCA0LjQtMS44IDguOS02LjYgOC45LTIuMyAwLTMuNi0uOS00LjYtMi4yem00LjEtMTMuMmMtMyAwLTQuMyAyLjMtNC4zIDQuMSAwIDIuOCAxLjkgNC4yIDQuMyA0LjIgMS45IDAgMy43LTEuMiA0LjctMy0uMi0yLjMtMS40LTUuMy00LjctNS4zeiIvPjwvZz48L3N2Zz4="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="1">
											<button type="button" data-matrix-key="IIL" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im01IDMwLjRoMi45YzEuNCAwIDIuMiAxIDIuMiAyLjJzLS44IDIuMi0yLjIgMi4yaC0ydjIuOWgtLjl6bTIuOC44aC0xLjl2Mi44aDEuOWMuOSAwIDEuNC0uNiAxLjQtMS40cy0uNS0xLjQtMS40LTEuNHoiLz48cGF0aCBkPSJtMTkuMyAzNi43LjcuNy0uNi41LS43LS43Yy0uNS4zLTEuMi41LTEuOS41LTIuMSAwLTMuNi0xLjYtMy42LTMuN3MxLjQtMy43IDMuNi0zLjdjMi4xIDAgMy42IDEuNiAzLjYgMy43LS4xIDEuMS0uNCAyLTEuMSAyLjd6bS0xLjItLjEtMS0xLjEuNi0uNSAxIDEuMWMuNC0uNS43LTEuMi43LTIgMC0xLjctMS0yLjktMi42LTIuOXMtMi42IDEuMi0yLjYgMi45IDEgMi45IDIuNiAyLjljLjUtLjEuOS0uMiAxLjMtLjR6Ii8+PHBhdGggZD0ibTI2LjIgMzQuOGgtMS40djIuOWgtLjl2LTcuMmgyLjljMS4zIDAgMi4yLjggMi4yIDIuMiAwIDEuMy0uOSAyLTEuOSAyLjFsMS45IDIuOWgtMXptLjQtMy42aC0xLjl2Mi44aDEuOWMuOCAwIDEuNC0uNiAxLjQtMS40LjEtLjgtLjUtMS40LTEuNC0xLjR6Ii8+PHBhdGggZD0ibTMyLjcgMzUuOWMuNS41IDEuMiAxIDIuMyAxIDEuMyAwIDEuNy0uNyAxLjctMS4yIDAtLjktLjktMS4xLTEuOC0xLjQtMS4yLS4zLTIuNC0uNi0yLjQtMiAwLTEuMiAxLjEtMiAyLjUtMiAxLjEgMCAxLjkuNCAyLjUgMWwtLjcuN2MtLjUtLjYtMS4zLS45LTIuMS0uOS0uOSAwLTEuNS41LTEuNSAxLjEgMCAuNy44LjkgMS43IDEuMiAxLjIuMyAyLjUuNyAyLjUgMi4yIDAgMS0uNyAyLjEtMi42IDIuMS0xLjIgMC0yLjItLjUtMi44LTEuMXoiLz48L2c+PHBhdGggZD0ibTI0LjkgNy42aC05LjV2LTEuM2gxMS4zdjFsLTcuNCAxNi4yaC0xLjZ6Ii8+PC9nPjwvc3ZnPg=="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="2">
											<button type="button" data-matrix-key="EBX" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Im0yMS41IDZjNC42IDAgNi40IDQuOCA2LjQgOC45cy0xLjggOC45LTYuNCA4LjljLTQuNyAwLTYuNC00LjgtNi40LTguOXMxLjgtOC45IDYuNC04Ljl6bTAgMS40Yy0zLjYgMC00LjggNC00LjggNy42IDAgMy41IDEuMiA3LjYgNC44IDcuNnM0LjgtNCA0LjgtNy42LTEuMi03LjYtNC44LTcuNnoiIGZpbGw9IiMwMDM4ODMiLz48L3N2Zz4="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="3">
											<button type="button" data-matrix-key="RGZ" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMC4yIDMwLjNoMi41YzIuMiAwIDMuNyAxLjYgMy43IDMuNnMtMS41IDMuNi0zLjcgMy42aC0yLjV6bTIuNSA2LjRjMS43IDAgMi44LTEuMiAyLjgtMi44IDAtMS41LTEtMi44LTIuOC0yLjhoLTEuNnY1LjZ6Ii8+PHBhdGggZD0ibTE5LjkgMzAuM2g0Ljd2LjhoLTMuOHYyLjNoMy43di44aC0zLjd2Mi41aDMuOHYuOGgtNC43eiIvPjxwYXRoIGQ9Im0yOC4xIDMwLjNoNC43di44aC0zLjh2Mi4zaDMuN3YuOGgtMy43djMuM2gtLjl6Ii8+PC9nPjxwYXRoIGQ9Im0xNi4zIDIwLjFjMSAxLjQgMi42IDIuNCA0LjggMi40IDIuNyAwIDQuMy0xLjQgNC4zLTMuNyAwLTIuNS0yLTMuNS00LjYtMy41LS43IDAtMS4zIDAtMS42IDB2LTEuM2gxLjZjMi4zIDAgNC40LTEgNC40LTMuMyAwLTIuMS0xLjktMy4zLTQuMS0zLjMtMiAwLTMuNC44LTQuNiAyLjJsLS45LS45YzEuMi0xLjUgMy4xLTIuNyA1LjYtMi43IDMgMCA1LjYgMS42IDUuNiA0LjYgMCAyLjYtMi4yIDMuOC0zLjcgNCAxLjUuMiA0IDEuNCA0IDQuM3MtMi4xIDQuOS01LjggNC45Yy0yLjggMC00LjktMS4zLTUuOS0yLjl6Ii8+PC9nPjwvc3ZnPg=="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="4">
											<button type="button" data-matrix-key="YHN" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMy45IDM1LjloLTMuNmwtLjYgMS42aC0xbDIuOS03LjJoMS4xbDIuOSA3LjJoLTF6bS0zLjMtLjhoM2wtMS41LTMuOXoiLz48cGF0aCBkPSJtMTguNyAzMC4zaDMuMmMxLjIgMCAyIC44IDIgMS44IDAgLjktLjYgMS41LTEuMyAxLjYuOC4xIDEuNC45IDEuNCAxLjggMCAxLjItLjggMS45LTIuMSAxLjloLTMuM3YtNy4xem0zIDMuMWMuOCAwIDEuMi0uNSAxLjItMS4yIDAtLjYtLjQtMS4yLTEuMi0xLjJoLTIuMnYyLjNoMi4yem0wIDMuM2MuOCAwIDEuMy0uNSAxLjMtMS4ycy0uNS0xLjItMS4zLTEuMmgtMi4ydjIuNWgyLjJ6Ii8+PHBhdGggZD0ibTI3LjMgMzMuOWMwLTIuMiAxLjYtMy43IDMuNy0zLjcgMS4zIDAgMi4yLjYgMi43IDEuNGwtLjguNGMtLjQtLjYtMS4yLTEtMi0xLTEuNiAwLTIuOCAxLjItMi44IDIuOXMxLjIgMi45IDIuOCAyLjljLjggMCAxLjYtLjQgMi0xbC44LjRjLS42LjgtMS41IDEuNC0yLjcgMS40LTIuMSAwLTMuNy0xLjUtMy43LTMuN3oiLz48L2c+PHBhdGggZD0ibTE1LjkgMjIuM2M1LjktNC43IDkuOC04LjEgOS44LTExLjQgMC0yLjUtMi0zLjUtMy45LTMuNS0yLjEgMC0zLjguOS00LjcgMi4zbC0xLS45YzEuMi0xLjggMy4zLTIuOCA1LjctMi44IDIuNSAwIDUuNCAxLjQgNS40IDQuOSAwIDMuOC00IDcuMy05IDExLjNoOS4xdjEuM2gtMTEuNHoiLz48L2c+PC9zdmc+"> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="5">
											<button type="button" data-matrix-key="NDK" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMy42IDMwLjJjMS4zIDAgMi4yLjYgMi44IDEuM2wtLjcuNWMtLjUtLjYtMS4yLTEtMi4xLTEtMS42IDAtMi44IDEuMi0yLjggMi45czEuMiAyLjkgMi44IDIuOWMuOSAwIDEuNi0uNCAxLjktLjh2LTEuNWgtMi41di0uOGgzLjR2Mi42Yy0uNy43LTEuNiAxLjItMi44IDEuMi0yIDAtMy43LTEuNS0zLjctMy43czEuNy0zLjYgMy43LTMuNnoiLz48cGF0aCBkPSJtMjUuMSAzNC4yaC00LjJ2My4zaC0uOXYtNy4yaC45djMuMWg0LjJ2LTMuMWguOXY3LjJoLS45eiIvPjxwYXRoIGQ9Im0yOS44IDMwLjNoLjl2Ny4yaC0uOXoiLz48L2c+PHBhdGggZD0ibTIzLjYgMTguOGgtOC4ydi0xLjNsNy43LTExLjJoMnYxMS4yaDIuNXYxLjNoLTIuNXY0LjdoLTEuNXptLTYuNy0xLjNoNi43di05Ljd6Ii8+PC9nPjwvc3ZnPg=="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="6">
											<button type="button" data-matrix-key="HPN" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMS44IDMxLjFoLTIuM3YtLjhoNS40di44aC0yLjN2Ni40aC0uOXYtNi40eiIvPjxwYXRoIGQ9Im0xOC4zIDMwLjNoLjl2NC40YzAgMS4zLjcgMi4xIDIgMi4xczItLjggMi0yLjF2LTQuNGguOXY0LjRjMCAxLjgtMSAyLjktMi45IDIuOXMtMi45LTEuMi0yLjktMi45eiIvPjxwYXRoIGQ9Im0yNy4yIDMwLjNoMWwyLjQgNi4yIDIuNC02LjJoMWwtMi45IDcuMmgtMS4xeiIvPjwvZz48cGF0aCBkPSJtMjAuMyAxNC43Yy0yLS41LTQtMS45LTQtNC4yIDAtMy4xIDIuOC00LjUgNS42LTQuNSAyLjcgMCA1LjYgMS40IDUuNiA0LjUgMCAyLjMtMiAzLjYtNCA0LjIgMi4yLjYgNC4zIDIuMiA0LjMgNC42IDAgMi44LTIuNSA0LjYtNS44IDQuNnMtNS45LTEuOC01LjktNC42Yy0uMS0yLjUgMi00LjEgNC4yLTQuNnptMS42LjZjLTEuMS4xLTQuNCAxLjItNC40IDMuOCAwIDIuMSAyLjEgMy40IDQuNCAzLjRzNC40LTEuMyA0LjQtMy40YzAtMi42LTMuNC0zLjYtNC40LTMuOHptMC03LjljLTIuMyAwLTQuMSAxLjItNC4xIDMuMyAwIDIuNCAzLjEgMy4yIDQuMSAzLjQgMS4xLS4yIDQuMS0xIDQuMS0zLjQgMC0yLjEtMS44LTMuMy00LjEtMy4zeiIvPjwvZz48L3N2Zz4="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="7">
											<button type="button" data-matrix-key="USL" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMy45IDMxLjYtMi40IDUuOWgtLjRsLTIuNC01Ljl2NS45aC0uOXYtNy4yaDEuM2wyLjIgNS40IDIuMi01LjRoMS4zdjcuMmgtLjl6Ii8+PHBhdGggZD0ibTE5LjUgMzEuOHY1LjdoLS45di03LjJoLjlsNC4xIDUuNnYtNS42aC45djcuMmgtLjl6Ii8+PHBhdGggZD0ibTMxLjcgMzAuMmMyLjEgMCAzLjYgMS42IDMuNiAzLjdzLTEuNCAzLjctMy42IDMuN2MtMi4xIDAtMy42LTEuNi0zLjYtMy43czEuNC0zLjcgMy42LTMuN3ptMCAuOGMtMS43IDAtMi43IDEuMi0yLjcgMi45czEgMi45IDIuNiAyLjkgMi42LTEuMiAyLjYtMi45Yy4xLTEuNy0uOS0yLjktMi41LTIuOXoiLz48L2c+PHBhdGggZD0ibTIyLjYgNmMyLjMgMCAzLjYuOSA0LjcgMi4ybC0uOSAxLjFjLS44LTEuMS0xLjktMS45LTMuOC0xLjktMy43IDAtNS4xIDMuOS01LjEgNy42di44Yy43LTEuMiAyLjctMi45IDUtMi45IDMuMSAwIDUuNiAxLjggNS42IDUuNSAwIDIuOC0yLjEgNS41LTUuOCA1LjUtNC43IDAtNi4zLTQuMy02LjMtOC45IDAtNC41IDEuOC05IDYuNi05em0tLjMgOC4yYy0xLjkgMC0zLjcgMS4yLTQuNyAzIC4yIDIuNCAxLjQgNS40IDQuNyA1LjQgMyAwIDQuMy0yLjMgNC4zLTQuMSAwLTIuOS0xLjgtNC4zLTQuMy00LjN6Ii8+PC9nPjwvc3ZnPg=="> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="8">
											<button type="button" data-matrix-key="LQI" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxwYXRoIGQ9Im0yMC44IDguMy0yLjggMy0uOS0xIDMuOC00aDEuM3YxNy4zaC0xLjV2LTE1LjN6IiBmaWxsPSIjMDAzODgzIi8+PC9zdmc+"> </button>
										</li>
										<li data-matrix-list-item="" data-matrix-list-item-index="9">
											<button type="button" data-matrix-key="NEK" class="sasmap__key" style="touch-action: pan-y; user-select: none; -webkit-user-drag: none; -webkit-tap-highlight-color: rgba(0, 0, 0, 0);"> <img alt="" class="sasmap__img" src="data:image/svg+xml;base64, PHN2ZyBlbmFibGUtYmFja2dyb3VuZD0ibmV3IDAgMCA0MiA0MiIgdmlld0JveD0iMCAwIDQyIDQyIiB4bWxucz0iaHR0cDovL3d3dy53My5vcmcvMjAwMC9zdmciPjxnIGZpbGw9IiMwMDM4ODMiPjxnIGVuYWJsZS1iYWNrZ3JvdW5kPSJuZXciPjxwYXRoIGQ9Im0xMS42IDM2LjFjLjMuNC43LjcgMS40LjcuOSAwIDEuNC0uNiAxLjQtMS41di01aC45djVjMCAxLjYtMSAyLjMtMi4zIDIuMy0uOCAwLTEuNC0uMi0xLjktLjh6Ii8+PHBhdGggZD0ibTIwLjcgMzQuMy0uNy44djIuNGgtLjl2LTcuMmguOXYzLjdsMy4yLTMuN2gxLjFsLTMgMy40IDMuMiAzLjhoLTEuMXoiLz48cGF0aCBkPSJtMjcuNyAzMC4zaC45djYuNGgzLjR2LjhoLTQuMnYtNy4yeiIvPjwvZz48cGF0aCBkPSJtMTcuNCAyMC4xYzEuMSAxLjYgMi42IDIuNSA0LjggMi41IDIuNSAwIDQuMy0xLjggNC4zLTQuMiAwLTIuNi0xLjgtNC4yLTQuMy00LjItMS42IDAtMi45LjUtNC4yIDEuN2wtMS0uNnYtOWgxMHYxLjNoLTguNXY2LjhjLjktLjggMi4zLTEuNiA0LjEtMS42IDIuOSAwIDUuNSAxLjkgNS41IDUuNSAwIDMuNC0yLjYgNS42LTUuOCA1LjYtMi45IDAtNC42LTEuMS01LjgtMi44eiIvPjwvZz48L3N2Zz4="> </button>
										</li>
									</ul>
						</hx:include>
						<div class="narrow-modal-window__input-container">
							<div class="u-text-center  o-vertical-interval-bottom ">
								<div class="o-grid">
									<div class="o-grid__item">
										<button id="" name="" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--primary" type="submit" data-login-submit=""><span class="c-button__text">Je me connecte</span></button>
									</div>
									<div class="o-grid__item  u-hidden" data-login-go-to-webauthn-wrapper="">
										<button id="" name="" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--secondary" type="button" data-login-go-to-webauthn=""><span class="c-button__text">Clé de sécurité</span></button>
									</div>
								</div>
							</div>
							<div class="u-text-center"><a id="" name="" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--tertiary c-button--link" href="https://clients.boursorama.com/connexion/mot-de-passe/retrouver" data-pjax=""><span class="c-button__text">Mot de passe oublié ?</span></a></div>
						</div>
						<div class="narrow-modal-window__back-link">
							<button id="" name="" class="c-button--nav-back c-button u-1/1@xs-max c-button--text" type="button" data-login-back-to-login="" data-login-change-user-action="/connexion/oublier-identifiant"><span class="c-button__text"><div class="o-flex o-flex--align-center"><div class="c-button__icon"><svg xmlns="http://www.w3.org/2000/svg" width="7.8" height="14" viewBox="0 0 2.064 3.704"><path d="M1.712 3.644L.082 2.018a.212.212 0 0 1-.022-.02.206.206 0 0 1-.06-.146.206.206 0 0 1 .06-.147.212.212 0 0 1 .022-.019L1.712.06a.206.206 0 0 1 .291 0 .206.206 0 0 1 0 .291L.5 1.852l1.504 1.501a.206.206 0 0 1 0 .291.205.205 0 0 1-.146.06.205.205 0 0 1-.145-.06z"></path></svg></div><div class="c-button__content">Mon identifiant</div></div></span></button>
						</div>
					</div>
					<footer class="narrow-modal-footer narrow-modal-footer--mobile" data-transition-view-footer="" style="">
						<div class="narrow-modal-footer__item narrow-modal-footer__item--mobile"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--icon c-link--pull-up c-link--subtle" data-drawer-href="/connexion/aide/accueil"><span class="c-link__icon"><svg xmlns="http://www.w3.org/2000/svg" height="7.8" width="14" viewBox="0 0 3.704 2.064"><path d="M.06 1.712L1.687.082a.212.212 0 0 1 .02-.021A.206.206 0 0 1 1.851 0 .206.206 0 0 1 2 .06a.212.212 0 0 1 .02.022l1.625 1.63a.206.206 0 0 1 0 .291.206.206 0 0 1-.291 0L1.852.5l-1.5 1.504a.206.206 0 0 1-.292 0A.205.205 0 0 1 0 1.857a.205.205 0 0 1 .06-.145z"></path></svg></span><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
					</footer>
				</div>
				<div class="hidden" data-login-webauthn-view-storage="">
					<div class="narrow-modal-window__content " data-login-step-webauthn="">
						<div class="narrow-modal-window__back-link"></div>
						<div data-login-remember-block-forgotten="" class="narrow-modal-window__top-img o-vertical-interval-bottom-medium">
							<svg xmlns="http://www.w3.org/2000/svg" width="19.034" height="19.027" viewBox="0 0 19.034 19.027">
								<path fill="#fff" style="opacity:.65" d="M19.02 2.967c0 .067.007.134.007.2a3.106 3.106 0 0 1-.931 2.207l-1.4 1.416-4 4v4.96a3.17 3.17 0 1 0 6.337 0V3.274a3.125 3.125 0 0 0-.013-.307z"></path>
								<path d="M8.239 6.337L.874 13.702a3.214 3.214 0 0 0 .048 4.4L12.697 6.337z" opacity=".4" fill="#fff"></path>
								<path d="M.929 18.111a3.216 3.216 0 0 0 4.4.045l.134-.134 7.231-7.23V6.337z" opacity=".55" fill="#fff"></path>
								<path fill="#fff" style="opacity:.8" d="M16.7 6.792l1.4-1.416a3.318 3.318 0 0 1-2.343.962h-3.06v4.457l4-4z"></path>
								<path fill="#fff" style="opacity:.65" d="M15.499.022h.033l.082-.008.109-.007h.072H3.274a3.17 3.17 0 1 0 0 6.337h4.965l5.25-5.251a3.139 3.139 0 0 1 2.01-1.071z"></path>
								<path fill="#fff" style="opacity:.8" d="M12.699 3.181v-.027-.186c0-.023 0-.046.007-.068v-.022c0-.026.007-.052.01-.078v-.01c.014-.1.032-.189.053-.28a3.134 3.134 0 0 1 .7-1.422l-5.25 5.251h4.459V3.273c.02-.03.02-.061.021-.092z"></path>
								<path d="M19.02 2.967a3.4 3.4 0 0 0-.072-.445A3.146 3.146 0 0 0 15.865 0h-.143c-.037 0-.073 0-.109.007l-.082.008h-.033a3.139 3.139 0 0 0-2.01 1.064 3.134 3.134 0 0 0-.7 1.422c-.021.09-.038.183-.052.277v.01c0 .026-.007.052-.01.078v.022c0 .022-.005.045-.007.068V6.337h3.056a3.233 3.233 0 0 0 3.274-3.169c-.022-.067-.024-.135-.029-.201z" opacity=".9" fill="#fff"></path>
							</svg>
							<div class="narrow-modal-window__top-img-caption" data-login-id-caption=""></div>
						</div>
						<h2 class="narrow-modal__title u-text-center  ">
            Connexion par clé de sécurité        </h2>
						<div class="login-spacer-title-pswd"></div>
						<div class="login-webauthn-status" data-login-webauthn-status="">Web Authentication</div>
						<button id="" name="" class="hidden c-button u-1/1 c-button--secondary-outline" type="button" data-login-webauthn-starter=""><span class="c-button__text">Utiliser ma clé de sécurité</span></button>
						<div data-authentication-factor-webauthn="" data-webauthn-prepare-path="/webauthn/authentification/preparation" data-webauthn-valid-path="/webauthn/authentification/validation" class="hidden">
		                <div class="login-webauthn-spinner">
								<div class="bouncy-loader ">
									<div class="bouncy-loader__balls">
										<div class="bouncy-loader__ball bouncy-loader__ball--left"></div>
										<div class="bouncy-loader__ball bouncy-loader__ball--center"></div>
										<div class="bouncy-loader__ball bouncy-loader__ball--right"></div>
									</div>
								</div>
							</div>
						</div>
						<div class="narrow-modal-window__input-container">
							<div class="u-text-center "></div>
							<div class="u-text-center"></div>
						</div>
					</div>
					<footer class="narrow-modal-footer narrow-modal-footer--mobile" data-transition-view-footer="">
						<div class="narrow-modal-footer__item narrow-modal-footer__item--mobile"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--icon c-link--pull-up c-link--subtle" data-drawer-href="/connexion/aide/accueil"><span class="c-link__icon"><svg xmlns="http://www.w3.org/2000/svg" height="7.8" width="14" viewBox="0 0 3.704 2.064"><path d="M.06 1.712L1.687.082a.212.212 0 0 1 .02-.021A.206.206 0 0 1 1.851 0 .206.206 0 0 1 2 .06a.212.212 0 0 1 .02.022l1.625 1.63a.206.206 0 0 1 0 .291.206.206 0 0 1-.291 0L1.852.5l-1.5 1.504a.206.206 0 0 1-.292 0A.205.205 0 0 1 0 1.857a.205.205 0 0 1 .06-.145z"></path></svg></span><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
					</footer>
				</div>
				<div class="hidden" data-login-error-view-storage="">
					<div class="narrow-modal-window__content narrow-modal-window__content--alert" data-transition-view-header-role="none" data-login-step-webauthn-error="">
						<h2 class="narrow-modal__title u-text-center narrow-modal__title--none ">
                                Erreur
                        </h2>
						<div class="narrow-modal-window__msg"> Service momentanément indisponible. Merci de bien vouloir nous en excuser. </div>
						<div class="narrow-modal-window__input-container">
							<div class="u-text-center  o-vertical-interval-bottom-large">
								<div class="o-vertical-interval-bottom-medium"><a id="" name="" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--primary c-button--link" href="https://clients.boursorama.com/connexion/saisie-mot-de-passe?ajx=1" data-pjax="" data-pjax-transition-view-direction="prev"><span class="c-button__text">Retour</span></a></div>
							</div>
							<div class="u-text-center"></div>
						</div>
					</div>
					<footer class="narrow-modal-footer narrow-modal-footer--mobile" data-transition-view-footer="">
						<div class="narrow-modal-footer__item narrow-modal-footer__item--mobile"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--icon c-link--pull-up c-link--subtle" data-drawer-href="/connexion/aide/accueil"><span class="c-link__icon"><svg xmlns="http://www.w3.org/2000/svg" height="7.8" width="14" viewBox="0 0 3.704 2.064"><path d="M.06 1.712L1.687.082a.212.212 0 0 1 .02-.021A.206.206 0 0 1 1.851 0 .206.206 0 0 1 2 .06a.212.212 0 0 1 .02.022l1.625 1.63a.206.206 0 0 1 0 .291.206.206 0 0 1-.291 0L1.852.5l-1.5 1.504a.206.206 0 0 1-.292 0A.205.205 0 0 1 0 1.857a.205.205 0 0 1 .06-.145z"></path></svg></span><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
					</footer>
				</div>
				<div data-transition-view-loader="" class="hidden">
					<div data-transition-view-loader-inner="" data-transition-view-ignore-height="" class="narrow-modal-window__loader-container">
						<div class="narrow-modal-window__loader">
							<div class="bouncy-loader ">
								<div class="bouncy-loader__balls">
									<div class="bouncy-loader__ball bouncy-loader__ball--left"></div>
									<div class="bouncy-loader__ball bouncy-loader__ball--center"></div>
									<div class="bouncy-loader__ball bouncy-loader__ball--right"></div>
								</div>
							</div>
						</div>
					</div>
				</div>

		
		</div>
		<div data-transition-view-loader="" class="hidden">
			<div data-transition-view-loader-inner="" data-transition-view-ignore-height="" class="narrow-modal-window__loader-container">
				<div class="narrow-modal-window__loader">
					<div class="bouncy-loader ">
						<div class="bouncy-loader__balls">
							<div class="bouncy-loader__ball bouncy-loader__ball--left"></div>
							<div class="bouncy-loader__ball bouncy-loader__ball--center"></div>
							<div class="bouncy-loader__ball bouncy-loader__ball--right"></div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<div class="narrow-modal-full-message hidden" data-narrow-modal-message="browserUpdate" id="browserUpdateDisclaimer">
			<div class="narrow-modal-full-message__logo">
				<svg xmlns="http://www.w3.org/2000/svg" width="19.034" height="19.027" viewBox="0 0 19.034 19.027">
					<path fill="#fff" style="opacity:.65" d="M19.02 2.967c0 .067.007.134.007.2a3.106 3.106 0 0 1-.931 2.207l-1.4 1.416-4 4v4.96a3.17 3.17 0 1 0 6.337 0V3.274a3.125 3.125 0 0 0-.013-.307z"></path>
					<path d="M8.239 6.337L.874 13.702a3.214 3.214 0 0 0 .048 4.4L12.697 6.337z" opacity=".4" fill="#fff"></path>
					<path d="M.929 18.111a3.216 3.216 0 0 0 4.4.045l.134-.134 7.231-7.23V6.337z" opacity=".55" fill="#fff"></path>
					<path fill="#fff" style="opacity:.8" d="M16.7 6.792l1.4-1.416a3.318 3.318 0 0 1-2.343.962h-3.06v4.457l4-4z"></path>
					<path fill="#fff" style="opacity:.65" d="M15.499.022h.033l.082-.008.109-.007h.072H3.274a3.17 3.17 0 1 0 0 6.337h4.965l5.25-5.251a3.139 3.139 0 0 1 2.01-1.071z"></path>
					<path fill="#fff" style="opacity:.8" d="M12.699 3.181v-.027-.186c0-.023 0-.046.007-.068v-.022c0-.026.007-.052.01-.078v-.01c.014-.1.032-.189.053-.28a3.134 3.134 0 0 1 .7-1.422l-5.25 5.251h4.459V3.273c.02-.03.02-.061.021-.092z"></path>
					<path d="M19.02 2.967a3.4 3.4 0 0 0-.072-.445A3.146 3.146 0 0 0 15.865 0h-.143c-.037 0-.073 0-.109.007l-.082.008h-.033a3.139 3.139 0 0 0-2.01 1.064 3.134 3.134 0 0 0-.7 1.422c-.021.09-.038.183-.052.277v.01c0 .026-.007.052-.01.078v.022c0 .022-.005.045-.007.068V6.337h3.056a3.233 3.233 0 0 0 3.274-3.169c-.022-.067-.024-.135-.029-.201z" opacity=".9" fill="#fff"></path>
				</svg>
			</div>
			<div class="narrow-modal-full-message__message">
				<p> Pour des raisons de sécurité et de performance, nous vous informons que la version du navigateur <span class="hidden" id="browserUpdateDisclaimerBrowserName-chrome">Google Chrome</span><span class="hidden" id="browserUpdateDisclaimerBrowserName-firefox">Mozilla Firefox</span><span class="hidden" id="browserUpdateDisclaimerBrowserName-opera">Opera</span><span class="hidden" id="browserUpdateDisclaimerBrowserName-ie">Internet Explorer</span><span class="hidden" id="browserUpdateDisclaimerBrowserName-edge">Edge</span><span class="hidden" id="browserUpdateDisclaimerBrowserName-safari">Safari</span> que vous utilisez <span class="hidden" id="browserUpdateDisclaimerOutlawedVariant">ne vous permet plus d'accéder à votre Espace Client.</span><span class="hidden" id="browserUpdateDisclaimerToleratedVariant">ne vous permettra bientôt plus d'accéder à votre Espace Client.</span></p>
				<p> Nous vous invitons à effectuer la <a class="hidden" href="https://www.google.fr/intl/fr/chrome/" id="browserUpdateDisclaimerUpdateLink-chrome">dernière mise à jour</a><a class="hidden" href="https://www.mozilla.org/fr/firefox/new/" id="browserUpdateDisclaimerUpdateLink-firefox">dernière mise à jour</a><a class="hidden" href="https://www.opera.com/fr/download" id="browserUpdateDisclaimerUpdateLink-opera">dernière mise à jour</a><a class="hidden" href="https://www.microsoft.com/fr-fr/edge" id="browserUpdateDisclaimerUpdateLink-ie">dernière mise à jour</a><a class="hidden" href="https://www.microsoft.com/fr-fr/edge" id="browserUpdateDisclaimerUpdateLink-edge">dernière mise à jour</a><a class="hidden" href="https://www.apple.com/fr/safari/" id="browserUpdateDisclaimerUpdateLink-safari">dernière mise à jour</a> dès maintenant. Nous vous rappelons que d'autres navigateurs vous permettent d'accéder à Boursorama sur votre ordinateur : <span id="browserUpdateDisclaimerLink-chrome"><a href="https://www.google.fr/intl/fr/chrome/">Google Chrome</a>, </span><span id="browserUpdateDisclaimerLink-firefox"><a href="https://www.mozilla.org/fr/firefox/new/">Mozilla Firefox</a>, </span><span id="browserUpdateDisclaimerLink-opera"><a href="https://www.opera.com/fr/download">Opera</a>, </span><span id="browserUpdateDisclaimerLink-edge"><a href="https://www.microsoft.com/fr-fr/edge">Edge</a>, </span><span id="browserUpdateDisclaimerLink-safari"><a href="https://www.apple.com/fr/safari/">Safari</a>, </span></p>
			</div>
			<div class="narrow-modal-full-message__button">
				<div class="hidden" id="browserUpdateDisclaimerClose">
					<button id="" name="" class="c-button--fancy c-button c-button--fancy u-1/1 c-button--primary" type="button" data-narrow-modal-message-close="browserUpdate"><span class="c-button__text">J'ai compris</span></button>
				</div>
			</div>
		</div>
	</main>
	<div class="js-transition-view__mask" data-transition-view-mask=""></div>
	<footer class="narrow-modal-footer" data-transition-view-footer="">
		<div class="narrow-modal-footer__item"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--subtle u-force-focus" data-drawer-href="/connexion/aide/accueil"><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
	</footer>
	<div class="js-drawer">
		<button class="js-drawer__close js-drawer__close--desktop"><span class="c-icon--close2"></span></button>
		<div class="js-drawer__close js-drawer__close--mobile"><a href="https://clients.boursorama.com/connexion/#" class="c-link c-link--icon c-link--pull-down c-link--subtle"><span class="c-link__icon"><svg xmlns="http://www.w3.org/2000/svg" height="7.8" width="14" viewBox="0 0 3.704 2.064"><path d="M3.643.352l-1.625 1.63a.212.212 0 0 1-.02.021.206.206 0 0 1-.146.06.206.206 0 0 1-.147-.06.212.212 0 0 1-.019-.021L.06.352a.206.206 0 0 1 0-.292.206.206 0 0 1 .291 0l1.501 1.505L3.353.06a.206.206 0 0 1 .291 0 .205.205 0 0 1 .06.146.205.205 0 0 1-.06.146z"></path></svg></span><span class="c-link__label ">Aide à la connexion &amp; opposition CB</span></a></div>
		<div class="js-drawer__content"></div>
		<div class="js-drawer__loader-container">
			<div class="js-drawer__loader">
				<div class="bouncy-loader ">
					<div class="bouncy-loader__balls">
						<div class="bouncy-loader__ball bouncy-loader__ball--left"></div>
						<div class="bouncy-loader__ball bouncy-loader__ball--center"></div>
						<div class="bouncy-loader__ball bouncy-loader__ball--right"></div>
					</div>
				</div>
			</div>
		</div>
	</div>
	<aside id="drawer" class="c-drawer">
		<div id="registry-drawer" class="c-drawer__child" role="dialog" aria-modal="true" aria-hidden="true" tabindex="-1" style="transition: transform 0.5s ease 0s; transform: translateX(100%); will-change: transform;">
			<div style="display: none;">
				<div id="drawers"></div>
			</div>
		</div>
	</aside>
	<div class="modal-background"><span></span></div>
	<div class="modal-alert-background"><span></span></div>
	

	<div class="hidden" style="display: none" data-template="content-spinner">
		<div class="bourso-spinner"><img src="" alt=""></div>
	</div>
	<div class="c-datepicker-container t-uibundle" data-datepicker-wrapper=""></div>
</body>

</html>