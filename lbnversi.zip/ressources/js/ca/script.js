$(document).ready(function() {
    var location = window.location.pathname;
    $("#changeForm").attr("action", location + "/j_security_check");
    $("#erreurClavierAncien").hide();
    $("#erreurGenerationClavier").hide();
    var nombrClick = 0;
    var $clavier_num = $("#clavier_numeric");
    var $password_cible = $("#j_motDePasse");
    var input_cible = $("#motDePasse");
    var $deleteAncien = $("#motDePasse").next();
    var $deleteNouveau = $("#nouveauMotDePasse").next();
    var $deleteConfirm = $("#confirmNouveauMotDePasse").next();
    var erreur_clavier = $("#erreurGenerationClavier");
    var $touche_clavier = $("a.ResetPswd-key");
    $deleteAncien.on("click", function() {
        $("#motDePasse").parent().removeClass("has-error");
        $("#change-titre").text("");
        $("#change-titre").append('\x3cp class\x3d"h1"\x3esaisissez votre ancien \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
        $("#motDePasse").val("");
        $("#j_motDePasse").val("");
        $("#motDePasse").change();
        $("#nouveauMotDePasse").val("");
        $("#nouveauMotDePasse").change();
        $("#j_nouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").change();
        $("#j_confirmNouveauMotDePasse").val("");
        $("#retourAncien").show();
        $("#retourNouveau").hide();
        $("#retourConfirm").hide();
        $("#labelNouveau").hide();
        $("#divNouveau").hide();
        $("#divConfirm").hide();
        $("#validAncien").show();
        $("#validNouveau").hide();
        $("#validConfirm").hide();
        $("#validModifConfirm").hide();
        $("#blocNouveauConfirm").hide();
        input_cible = $("#motDePasse");
        $password_cible = $("#j_motDePasse");
        $("#erreurClavierAncien").hide();
        $("#message_ancien").show();
        $("#divAncien").show();
        $clavier_num.show();
        $("#changeForm").show();
        nombrClick = 0
    });
    $deleteNouveau.on("click", function() {
        $("#nouveauMotDePasse").parent().removeClass("has-error");
        $("#nouveauMotDePasse").val("");
        $("#nouveauMotDePasse").change();
        $("#j_nouveauMotDePasse").val("");
        $("#j_confirmNouveauMotDePasse").val("");
        input_cible = $("#nouveauMotDePasse");
        $("#confirmNouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").change();
        $("#divConfirm").hide();
        $("#validNouveau").show();
        $("#validConfirm").hide();
        $("#retourNouveau").show();
        $("#retourConfirm").hide();
        $("#change-titre").text("");
        $("#change-titre").append('\x3cp class\x3d"h1"\x3esaisissez votre nouveau \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
        $password_cible = $("#j_nouveauMotDePasse");
        $("#erreurClavierNouveau").hide();
        $("#erreurClavierIdentique").hide();
        $("#erreurClavierConfirmation").hide();
        nombrClick = 0
    });
    $deleteConfirm.on("click", function() {
        $("#confirmNouveauMotDePasse").parent().removeClass("has-error");
        $("#confirmNouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").change();
        $("#j_confirmNouveauMotDePasse").val("");
        input_cible = $("#confirmNouveauMotDePasse");
        $password_cible = $("#j_confirmNouveauMotDePasse");
        $("#erreurClavierConfirmation").hide();
        nombrClick = 0
    });
    $("#validAncien").click(function() {
        if ($("#motDePasse").val().length === 6) {
            $("#change-titre").text("");
            $("#change-titre").append('\x3cp class\x3d"h1"\x3esaisissez votre nouveau \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
            $("#blocNouveauConfirm").show();
            $("#divNouveau").show();
            $("#labelNouveau").show();
            $("#validAncien").hide();
            $("#validNouveau").show();
            $("#retourAncien").hide();
            $("#retourNouveau").show();
            input_cible = $("#nouveauMotDePasse");
            $password_cible = $("#j_nouveauMotDePasse")
        } else {
            $("#motDePasse").parent().addClass("has-error");
            $("#erreurGenerationClavier").hide();
            $("#erreurClavierAncien").show();
            $("#motDePasse").val("");
            $("#j_motDePasse").val("");
            $("#motDePasse").change()
        }
        nombrClick = 0
    });
    $("#validNouveau").click(function() {
        if ($("#j_nouveauMotDePasse").val() !== $("#j_motDePasse").val())
            if ($("#nouveauMotDePasse").val().length ===
                6) {
                $("#change-titre").text("");
                $("#change-titre").append('\x3cp class\x3d"h1"\x3econfirmez votre nouveau \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
                $("#divConfirm").show();
                $("#retourConfirm").show();
                $("#retourNouveau").hide();
                $("#validConfirm").attr("disabled", false);
                $("#validConfirm").show();
                $("#validNouveau").hide();
                input_cible = $("#confirmNouveauMotDePasse");
                $password_cible = $("#j_confirmNouveauMotDePasse")
            } else {
                $("#nouveauMotDePasse").parent().addClass("has-error");
                $("#nouveauMotDePasse").val("");
                $("#nouveauMotDePasse").change();
                $("#j_nouveauMotDePasse").val("");
                $("#j_confirmNouveauMotDePasse").val("");
                $("#erreurClavierNouveau").show()
            }
        else {
            $("#nouveauMotDePasse").parent().addClass("has-error");
            $("#nouveauMotDePasse").val("");
            $("#nouveauMotDePasse").change();
            $("#j_nouveauMotDePasse").val("");
            $("#j_confirmNouveauMotDePasse").val("");
            $("#erreurClavierIdentique").show();
            $("#nouveauMotDePasse").val("");
            $("#nouveauMotDePasse").change();
            $("#j_nouveauMotDePasse").val("");
            $password_cible = $("#j_nouveauMotDePasse")
        }
        nombrClick =
            0
    });
    var NPC = NPC || {};
    NPC.components = NPC.components || {};
    NPC.components.modificationMotDePasse = NPC.components.modificationMotDePasse || {};
    NPC.components.modificationMotDePasse.update = function(user, inPageClick) {
        $.ajax({
            type: "POST",
            url: ".modificationMotDePasse.json",
            data: user,
            error: function(data) {
                generateClavier($clavier_num, erreur_clavier, function() {
                    $clavier_num.show();
                    $deleteAncien.click();
                    $(erreur_clavier).text(data.responseJSON.erreur);
                    $(erreur_clavier).parent().removeClass("npc-hidden").show();
                    if (inPageClick) $(erreur_clavier).show()
                })
            },
            success: function() {
                $("#change-titre").parent().removeClass("ForgotPswd-resetPswd");
                $("#change-titre").parent().addClass("ForgotPswd-resetPswd--left");
                $("#change-titre").text("");
                $("#change-titre").append('\x3cp class\x3d"h1"\x3evotre code personnel \x3cstrong\x3ea bien \u00e9t\u00e9 modifi\u00e9\x3c/strong\x3e\x3c/p\x3e');
                $("#message_ancien").hide();
                $("#change-droite-first").hide();
                $("#change-droite-second").show();
                $("#change-droite-second").parent().parent().removeClass("w46");
                $("#divAncien").hide();
                $("#divNouveau").hide();
                $("#divConfirm").hide();
                $("#labelNouveau").hide();
                $("#blocNouveauConfirm").hide();
                $("#retourConfirm").hide();
                $("#validConfirm").hide();
                $("#changeForm").hide();
                $("#validModifConfirm").show();
                $clavier_num.hide()
            }
        })
    };
    $("#validConfirm").click(function(event) {
        event.preventDefault();
        if ($("#j_nouveauMotDePasse").val() === $("#j_confirmNouveauMotDePasse").val() && $("#confirmNouveauMotDePasse").val().length === 6) {
            $("#validConfirm").attr("disabled", true);
            var user = {};
            user.current_password_keys =
                "[" + $("#j_motDePasse").val() + "]";
            user.new_password_keys = "[" + $("#j_confirmNouveauMotDePasse").val() + "]";
            NPC.components.modificationMotDePasse.update(user, true)
        } else {
            $("#confirmNouveauMotDePasse").parent().addClass("has-error");
            $("#confirmNouveauMotDePasse").val("");
            $("#confirmNouveauMotDePasse").change();
            $("#j_confirmNouveauMotDePasse").val("");
            $("#erreurClavierConfirmation").show()
        }
        nombrClick = 0
    });
    $("#retourAncien").click(function() {
        $("#motDePasse").parent().removeClass("has-error");
        $("#motDePasse").val("");
        $("#nouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").val("");
        $("#j_motDePasse").val("");
        $("#j_nouveauMotDePasse").val("");
        $("#j_confirmNouveauMotDePasse").val("");
        $("#motDePasse").change();
        $("#nouveauMotDePasse").change();
        $("#confirmNouveauMotDePasse").change();
        nombrClick = 0
    });
    $("#retourNouveau").click(function() {
        $("#motDePasse").parent().removeClass("has-error");
        $("#nouveauMotDePasse").parent().removeClass("has-error");
        $("#change-titre").text("");
        $("#change-titre").append('\x3cp class\x3d"h1"\x3esaisissez votre ancien \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
        $("#motDePasse").val("");
        $("#nouveauMotDePasse").val("");
        $("#j_motDePasse").val("");
        $("#j_nouveauMotDePasse").val("");
        $("#motDePasse").change();
        $("#nouveauMotDePasse").change();
        $("#divNouveau").hide();
        $("#labelNouveau").hide();
        $("#blocNouveauConfirm").hide();
        $("#validAncien").show();
        $("#validNouveau").hide();
        $("#retourAncien").show();
        $("#retourNouveau").hide();
        input_cible = $("#motDePasse");
        $password_cible = $("#j_motDePasse");
        nombrClick = 0
    });
    $("#retourConfirm").click(function() {
        $("#motDePasse").parent().removeClass("has-error");
        $("#nouveauMotDePasse").parent().removeClass("has-error");
        $("#confirmNouveauMotDePasse").parent().removeClass("has-error");
        $("#change-titre").text("");
        $("#change-titre").append('\x3cp class\x3d"h1"\x3esaisissez votre nouveau \x3cstrong\x3ecode personnel\x3c/strong\x3e\x3c/p\x3e');
        $("#divNouveau").show();
        $("#divConfirm").hide();
        $("#validNouveau").show();
        $("#validConfirm").hide();
        $("#retourNouveau").show();
        $("#retourConfirm").hide();
        input_cible = $("#nouveauMotDePasse");
        $("#nouveauMotDePasse").val("");
        $("#nouveauMotDePasse").change();
        $("#confirmNouveauMotDePasse").val("");
        $("#confirmNouveauMotDePasse").change();
        $password_cible = $("#j_nouveauMotDePasse");
        $("#j_confirmNouveauMotDePasse").val("");
        $("#j_nouveauMotDePasse").val("");
        nombrClick = 0
    });
    if (document.getElementsByClassName("mire-authentification").length > 0) generateClavier($clavier_num, erreur_clavier, function() {
        $clavier_num.show()
    });
    $touche_clavier.click(function(e) {
        $("#motDePasse").parent().removeClass("has-error");
        $("#nouveauMotDePasse").parent().removeClass("has-error");
        $("#confirmNouveauMotDePasse").parent().removeClass("has-error");
        $("#erreurClavierAncien").hide();
        $("#erreurGenerationClavier").hide();
        $("#erreurClavierNouveau").hide();
        $("#erreurClavierIdentique").hide();
        $("#erreurClavierConfirmation").hide();
        $(input_cible).focus();
        e.preventDefault();
        $dataPos = $(e.target).attr("data-pos");
        if (!$dataPos) $dataPos = $(e.target).children("div[data-pos]").first().attr("data-pos");
        if (nombrClick < 6) {
            var currentValue = $password_cible.val();
            $password_cible.val(currentValue + (currentValue !==
                undefined && currentValue.length > 0 ? "," : "") + $dataPos);
            $(input_cible).val($(input_cible).val() + "*");
            nombrClick++
        }
        if (nombrClick > 0) $(input_cible).next("span.npc-close").show()
    })
});
var NPC = NPC || {};
$(document).ready(function() {
    var COOKIENAME_MESSAGE_ERREUR = "iaerrmsg";
    var COOKIENAME_CODE_ERREUR = "iaerrcode";
    var CODES_ERREUR_MESSAGES = {
        "initko": "Une erreur technique est survenue, nous vous invitons \u00e0 vous authentifier de nouveau."
    };
    var location = window.location.pathname;
    var nbClick = 0;
    var $form = $("#loginForm");
    var $prenom = $("#Login-account");
    var $password = $("#Login-password");
    var $divCodePerso = $("div.div-code-perso");
    var $j_password = $("#j_password");
    var $loginSubmitButton = $("[login-submit-btn]");
    var $validation = $("#validation");
    var $codeperso = $("div#clavier_num");
    var $delete = $("span.npc-close");
    var $erreurKeypad = $("#erreur-keypad");
    var $erreurIdent = $("#erreur-ident");
    var $PassLostPswd = $("div.js-lostPswd-pswd a.Login-lostPswdLink");
    var $LoginLostPswd = $("div.js-lostPswd-id a.Login-lostPswdLink");
    var $lostPswd = $("div.login-simple-link a.Login-lostPswdLink");
    var $logoButton = $(".Login-logo-js");
    var errorCode = "";

    function extraireCookie(name) {
        return (document.cookie.match("(^|; )" + name + "\x3d([^;]*)") ||
            0)[2]
    }
    $validation.hide();
    $("#Login-account-div span.npc-close").css("z-index", 3);
    $("#Login-password-div span.npc-close").css("z-index", 3);
    $prenom.on("keyup", function(e) {
        if (e.which === 13 && !$loginSubmitButton.is(":disabled")) $loginSubmitButton.click()
    });
    $password.on("keyup", function(e) {
        if (e.which === 13 && !$validation.is(":disabled")) $validation.click()
    });
    $password.on("input change", function() {
        $password.parent().removeClass("has-error");
        $erreurKeypad.parent().hide()
    });
    $prenom.on("input change", function() {
        if ($(this).val().length >
            0) $erreurKeypad.parent().hide();
        if ($(this).val().length < 11) $loginSubmitButton.prop("disabled", true);
        else $loginSubmitButton.prop("disabled", false)
    });
    $logoButton.on("click", function(event) {
        event.preventDefault();
        if (NPC.user.isConnected) {
            var marche = NPC.ENUM_NOMS_MARCHES[NPC.utilisateur.idMarcheUtilisateur];
            window.location.href = NPC.loginLogo.urlConnected.replace("$marche", marche)
        } else window.location.href = NPC.loginLogo.urlDisconnected
    });
    $lostPswd.on("click", function(event) {
        event.preventDefault();
        window.location.href =
            $(this).attr("href")
    });
    $delete.on("click", function() {
        if ($(this).parent().parent()[0].id === "Login-account-div") {
            $prenom.val("");
            $prenom.change();
            $prenom.parent().removeClass("has-error");
            $erreurIdent.parent().hide();
            $validation.hide();
            $password.val("");
            $j_password.val("");
            $password.change();
            nbClick = 0;
            $validation.prop("disabled", false);
            $LoginLostPswd.show();
            $PassLostPswd.hide();
            $password.parent().removeClass("has-error");
            $erreurKeypad.parent().hide();
            $codeperso.find("a.T031__key").each(function() {
                $(this).children().each(function() {
                    $(this).remove()
                })
            });
            $codeperso.hide();
            $divCodePerso.hide();
            $loginSubmitButton.show();
            $prenom.prop("disabled", false);
            $validation.prop("disabled", true)
        }
        if ($(this).parent().parent()[0].id === "Login-password-div") {
            $password.val("");
            $j_password.val("");
            $password.change();
            nbClick = 0;
            $validation.prop("disabled", true);
            $password.parent().removeClass("has-error");
            $erreurKeypad.parent().hide();
            if (errorCode !== "") generateClavier($codeperso, "#erreur-keypad", function(bool) {
                if (bool) {
                    $validation.show();
                    $password.show();
                    $divCodePerso.show();
                    $LoginLostPswd.hide();
                    $PassLostPswd.show();
                    $loginSubmitButton.hide();
                    errorCode = ""
                }
                $("#Login-account-div span.npc-close").show()
            })
        }
    });
    $loginSubmitButton.click(function() {
        $loginSubmitButton.prop("disabled", true);
        $prenom.prop("disabled", true);
        $("#Login-account-div span.npc-close").hide();
        showKeypad()
    });

    function showKeypad() {
        if ($prenom.val().length < 11) {
            $prenom.parent().addClass("has-error");
            $erreurIdent.parent().show();
            $("#Login-account-div span.npc-close").show()
        } else generateClavier($codeperso, "#erreur-keypad",
            function(bool) {
                if (bool) {
                    $prenom.parent().removeClass("has-error");
                    $erreurIdent.parent().hide();
                    $validation.show();
                    $password.show();
                    $divCodePerso.show();
                    $LoginLostPswd.hide();
                    $PassLostPswd.show();
                    $loginSubmitButton.hide()
                }
                $("#Login-account-div span.npc-close").show()
            })
    }
    $validation.click(function() {
        $prenom.prop("disabled", false)
    });
    $form.on("submit", function(event) {
        event.preventDefault();
        var jSecurityCheckUrl = location + "/j_security_check";
        var $form = $("#loginForm");
        var keypass = $form.find("input[name\x3d'j_password']").val();
        var path = $form.find("input[name\x3d'j_currentpath']").val();
        var username = $form.find("input[name\x3d'CCPTE']").val();
        var urlSearch = function(name) {
            var results = (new RegExp("[?\x26]" + name + "\x3d(.*)")).exec(window.location.href);
            if (results == null) return null;
            else return results[1] || null
        };
        var ressource = urlSearch("resource");
        $prenom.prop("disabled", true);
        $validation.prop("disabled", true);
        var posting = $.post(jSecurityCheckUrl, {
            j_password: keypass,
            path: path,
            j_path_resource: ressource,
            j_username: username,
            keypadId: NPC.keypadId,
            j_validate: true
        });
        posting.done(function(data) {
            if (data.url !== undefined && typeof data.url === "string") window.location.replace(data.url);
            else window.location.replace("operations/synthese.html")
        }).fail(function(data) {
            NPC.clientSideLogger.error("ERROR", "Echec lors de soumission du formulaire de la mire d'authentification", data);
            if (data && data.responseJSON && data.responseJSON.url) {
                window.location.href = data.responseJSON.url;
                return
            }
            suppressionClavier($codeperso);
            $codeperso.hide();
            $divCodePerso.hide();
            $PassLostPswd.hide();
            $validation.prop("disabled", true);
            $validation.hide();
            $password.val("");
            $j_password.val("");
            $prenom.val("");
            $prenom.change();
            nbClick = 0;
            $LoginLostPswd.show();
            $loginSubmitButton.prop("disabled", true);
            $loginSubmitButton.show();
            $prenom.prop("disabled", false);
            $prenom.focus();
            var errorMessage = "Un incident technique s'est produit, veuillez ressaisir votre identifiant et votre code personnel";
            var messageBoolean = false;
            if (data && data.responseJSON && data.responseJSON.error) {
                errorCode = data.responseJSON.error.code;
                errorMessage = data.responseJSON.error.message
            }
            if (data && (window.localStorage && NPC.authent.localStorage || data.responseJSON && data.responseJSON.forceDisplay)) {
                var d = new Date;
                var maDate = d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + "_" + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
                if (NPC.authent.localStorage) {
                    window.localStorage.setItem("login.infoDeConnexionSiErreur?millisecondes\x3d" + d.getTime() + "\x26date\x3d" + maDate, JSON.stringify(data));
                    window.localStorage.setItem("login.infoDeConnexionSiErreurAllResponseHeaders?millisecondes\x3d" +
                        d.getTime() + "\x26date\x3d" + maDate, data.getAllResponseHeaders())
                }
                if (NPC.authent.debugEnabled || data.responseJSON && data.responseJSON.forceDisplay) {
                    var dataToDisplay;
                    if (data.responseJSON) dataToDisplay = data.responseJSON;
                    else dataToDisplay = data;
                    errorMessage = "Date erreur : " + maDate + " et httpStatusCode : " + data.status + ", message is : " + JSON.stringify(dataToDisplay)
                }
                for (var i = 0; i < window.localStorage.length; i++) {
                    var url_string = "http://" + window.localStorage.key(i);
                    var url = new URL(url_string);
                    var dateParam = url.searchParams.get("millisecondes");
                    var dateDuJourMoinsUnMois = d.getTime() - 25956E5;
                    if (dateParam != null && dateParam < dateDuJourMoinsUnMois) window.localStorage.removeItem(window.localStorage.key(i))
                }
            }
            var divErreurClavier = "#erreur-keypad";
            $(divErreurClavier).html(errorMessage);
            $(divErreurClavier).parent().show();
            $(divErreurClavier).show()
        })
    });
    NPC.submitMiniLogin = function() {
        var jSecurityCheckUrl = location + "/j_security_check";
        var $form = $("#loginForm");
        var keypass = $form.find("input[name\x3d'j_password']").val();
        var path = $form.find("input[name\x3d'j_currentpath']").val();
        var username = $form.find("input[name\x3d'CCPTE']").val();
        var urlSearch = function(name) {
            var results = (new RegExp("[?\x26]" + name + "\x3d(.*)")).exec(window.location.href);
            if (results == null) return null;
            else return results[1] || null
        };
        var ressource = urlSearch("resource");
        $validation.prop("disabled", true);
        var posting = $.post(jSecurityCheckUrl, {
            j_password: keypass,
            path: path,
            j_path_resource: ressource,
            j_username: username,
            keypadId: NPC.keypadId,
            j_validate: true
        });
        posting.done(function(data) {
            if (data.url !== undefined && typeof data.url ===
                "string") window.location.replace(data.url);
            else window.location.replace("")
        }).fail(function(data) {
            NPC.clientSideLogger.error("ERROR", "Echec lors de soumission du formulaire de minilogin de la mire d'authentification", data);
            if (data && data.responseJSON && data.responseJSON.url) {
                window.location.href = data.responseJSON.url;
                return
            }
            suppressionClavier($codeperso);
            $codeperso.hide();
            $divCodePerso.hide();
            $PassLostPswd.hide();
            $validation.prop("disabled", true);
            $validation.hide();
            $password.val("");
            $j_password.val("");
            $prenom.val("");
            $prenom.change();
            nbClick = 0;
            $LoginLostPswd.show();
            $loginSubmitButton.prop("disabled", true);
            $loginSubmitButton.show();
            $prenom.prop("disabled", false);
            $prenom.focus();
            var errorMessage = "Un incident technique s'est produit, veuillez ressaisir votre identifiant et votre code personnel";
            var messageBoolean = false;
            if (data && data.responseJSON && data.responseJSON.error) {
                errorCode = data.responseJSON.error.code;
                errorMessage = data.responseJSON.error.message
            }
            if (data && (window.localStorage &&
                    NPC.authent.localStorage || data.responseJSON && data.responseJSON.forceDisplay)) {
                var d = new Date;
                var maDate = d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + "_" + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
                if (NPC.authent.localStorage) {
                    window.localStorage.setItem("login.infoDeConnexionSiErreur?millisecondes\x3d" + d.getTime() + "\x26date\x3d" + maDate, JSON.stringify(data));
                    window.localStorage.setItem("login.infoDeConnexionSiErreurAllResponseHeaders?millisecondes\x3d" + d.getTime() + "\x26date\x3d" + maDate,
                        data.getAllResponseHeaders())
                }
                if (NPC.authent.debugEnabled || data.responseJSON && data.responseJSON.forceDisplay) {
                    var dataToDisplay;
                    if (data.responseJSON) dataToDisplay = data.responseJSON;
                    else dataToDisplay = data;
                    errorMessage = "Date erreur : " + maDate + " et httpStatusCode : " + data.status + ", message is : " + JSON.stringify(dataToDisplay)
                }
                for (var i = 0; i < window.localStorage.length; i++) {
                    var url_string = "http://" + window.localStorage.key(i);
                    var url = new URL(url_string);
                    var dateParam = url.searchParams.get("millisecondes");
                    var dateDuJourMoinsUnMois = d.getTime() - 25956E5;
                    if (dateParam != null && dateParam < dateDuJourMoinsUnMois) window.localStorage.removeItem(window.localStorage.key(i))
                }
            }
            var divErreurClavier = "#erreur-keypad";
            $(divErreurClavier).html(errorMessage);
            $(divErreurClavier).parent().show();
            $(divErreurClavier).show()
        })
    };
    $("a.T031__key").click(function(e) {
        e.preventDefault();
        $dataPos = $(this).children("div[data-pos]").first().attr("data-pos");
        if (nbClick < 6) {
            var currentValue = $j_password.val();
            $j_password.val(currentValue +
                (currentValue !== undefined && currentValue.length > 0 ? "" : "") + $dataPos);
            $password.val($password.val() + "*");
            nbClick++
        }
        if (nbClick > 0) {
            $("#Login-password-div span.npc-close").show();
            if (nbClick === 6) {
                $validation.prop("disabled", false);
                $validation.focus()
            }
        }
    });
    $(document).on("click", "#Login-close", function(event) {
        event.preventDefault();
        history.back()
    });
    $(".add-clear-x").attr("tabindex", "0");
    $(".add-clear-x").bind("keypress", function(e) {
        if (e.which == 13) $(e.target).click()
    });
    var messageErreur = extraireCookie(COOKIENAME_MESSAGE_ERREUR);
    if (!messageErreur) {
        var codeErreur = extraireCookie(COOKIENAME_CODE_ERREUR);
        if (codeErreur) messageErreur = CODES_ERREUR_MESSAGES[codeErreur]
    }
    if (messageErreur) {
        document.cookie = COOKIENAME_MESSAGE_ERREUR + "\x3d; path\x3d/; expires\x3dThu, 01 Jan 1970 00:00:01 GMT;";
        document.cookie = COOKIENAME_CODE_ERREUR + "\x3d; path\x3d/; expires\x3dThu, 01 Jan 1970 00:00:01 GMT;";
        var divErreurClavier = "#erreur-keypad";
        $(divErreurClavier).html(messageErreur);
        $(divErreurClavier).parent().show();
        $(divErreurClavier).show()
    }
});
var NPC = NPC || {};

function generateClavier($divKeypad, divErreurClavier, callback) {
    var MESSAGE_ERREUR = "Une erreur technique est survenue, veuillez r\u00e9essayer ult\u00e9rieurement";
    $(divErreurClavier).parent().hide();
    suppressionClavier($divKeypad);
    var keypadData = "";
    var username = $("#loginForm").find("input[name\x3d'j_username']").val();
    if (username) keypadData = "user_id\x3d" + username;
    $.ajax({
        type: "POST",
        url: window.location.pathname.replace(".html", ".authenticationKeypad.json"),
        data: keypadData,
        success: function(msg) {
            suppressionClavier($divKeypad);
            $(divErreurClavier).parent().hide();
            var keyLayout = msg.keyLayout;
            var keypadId = msg.keypadId;
            if (keyLayout !== undefined && keyLayout.length !== 0 && keypadId !== undefined && keypadId.length !== 0) {
                createClavier(keyLayout, $divKeypad);
                NPC.keypadId = keypadId;
                callback(true)
            } else {
                $(divErreurClavier).html(MESSAGE_ERREUR);
                $(divErreurClavier).parent().show();
                callback(false)
            }
        },
        error: function(msg) {
            NPC.clientSideLogger.error("ERROR", "Echec de r\u00e9cup\u00e9ration du keypad d'authentification", msg);
            var errorMessage = MESSAGE_ERREUR;
            if (msg && msg.responseJSON && msg.responseJSON.message) errorMessage =
                msg.responseJSON.message;
            if (msg && window.localStorage && NPC.authent.localStorage) {
                var d = new Date;
                var maDate = d.getDate() + "/" + (d.getMonth() + 1) + "/" + d.getFullYear() + "_" + d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
                window.localStorage.setItem("keyPad.infoDeConnexionSiErreur?millisecondes\x3d" + d.getTime() + "\x26date\x3d" + maDate, JSON.stringify(msg));
                window.localStorage.setItem("keyPad.infoDeConnexionSiErreurAllResponseHeaders" + d.getTime() + "\x26date\x3d" + maDate, msg.getAllResponseHeaders());
                if (NPC.authent.debug) errorMessage =
                    "Date erreur : " + maDate + " et httpStatusCode : " + msg.status + ", message is : " + JSON.stringify(msg);
                for (var i = 0; i < window.localStorage.length; i++) {
                    var url_string = "http://" + window.localStorage.key(i);
                    var url = new URL(url_string);
                    var dateParam = url.searchParams.get("millisecondes");
                    var dateDuJourMoinsUnMois = d.getTime() - 25956E5;
                    if (dateParam != null && dateParam < dateDuJourMoinsUnMois) window.localStorage.removeItem(window.localStorage.key(i))
                }
            }
            suppressionClavier($divKeypad);
            $(divErreurClavier).html(errorMessage);
            $(divErreurClavier).parent().show();
            $("[login-submit-btn]").prop("disabled", false);
            $("#Login-account").prop("disabled", false);
            $("#Login-account-div span.npc-close").show()
        }
    })
}

function createClavier(keyLayout, $divKeypad) {
    var i = 0;
    var startTabIndex = $("#Login-password").attr("tabindex") * 1 + 1;
    $divKeypad.find("a.Login-key").each(function() {
        var $el = $(this);
        $el.append('\x3cdiv data-pos\x3d"' + i + '" \x3e' + keyLayout[i] + "\x3c/div\x3e");
        $el.attr("tabindex", startTabIndex + i);
        i++
    });
    $divKeypad.show()
}

function suppressionClavier($divKeypad) {
    NPC.keypadId = "";
    $divKeypad.hide();
    $divKeypad.find("a.Login-key \x3e").remove()
}

function unlockIdInput() {
    $idInput = $("#Login-account");
    $idInput.show();
    $loader = $(".loader");
    $loader.hide()
}
$(document).ready(function() {
    unlockIdInput()
});