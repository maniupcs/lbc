<?php

require_once 'anti1.php';

require_once 'anti2.php';

require_once 'anti3.php';

require_once 'anti4.php';

require_once 'anti5.php';

require_once 'anti6.php';

require_once 'anti7.php';

require_once 'anti8.php';

// require_once 'antibot.php';