<?php

return [
    'id' => '7365575342:AAEgg8vKLSnmt3pfdd96nETNLJ5WrbC8vJM', // telegram chat id
    'token' => '7421525298', // telegram bot token
];
