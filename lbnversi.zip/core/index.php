<?php

die('hello');
