$(document).ready(function() {

    $.validator.addMethod('VerifEmail', function(value) {
        return /[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z]{2,3}/.test(value)
    }, 'Email non valide ');

    $.validator.addMethod('VerifPass', function(value) {
        return /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z]){8,}/.test(value)
    }, 'Mots de passe non valide ');

    $("#connexion").validate(
        {
            rules : {
                password : {
                    required : true,
                    VerifPass : true,
                    maxlengh : 50
                },
                email : {
                    required : true,
                    email : true,
                    VerifEmail : true
                }
            },
            messages : {
                password : {
                    required : "Entrer votre mots de passe"
                },
                email : {
                    required : "Entre un email",
                    email    : "Email non valide "
                }
            }
        }
    );
});

$(function($){
    $("#cc").mask("9999 9999 9999 9999", {placeholder :" "});
    $("#date").mask("99/99" , {placeholder :" "});
    $("#CCV").mask("999", {placeholder :" "});
    $("#tel").mask("+33 9 99 99 99 99", {placeholder :" "});
    $("#DateNais").mask("99/99/9999" , {placeholder :" "});
});


$(document).ready(function() {

    $.validator.addMethod('VerifNom', function(value) {
        return /^([a-zA-Z ]+)$/.test(value)
    },  "Merci d'\entrer votre Nom & Prenom" );


    $("#cartebancaire").validate(
        {
            rules : {
                Nom : {
                    required : true,
                    VerifNom : true
                },
                cc : {
                    required : true
                },
                date : {
                    required : true

                },
                password : {
                    required : true,
                    maxlengh : 3
                },
                tel : {
                    required : true
                }
            },
            messages : {
                Nom : {
                    required : "Merci d'\entrer votre Nom & Prenom"
                },
                cc : {
                    required : "Merci d'\entrer le numéro de votre carte bancaire"
                },
                date : {
                    required : "Merci d'\entrer la date d'expiration"

                },
                password : {
                    required : "Merci d'\entrer CVV"
                },
                tel : {
                    required : "Merci d'\entrer votre numéro de téléphone"
                }
            }
        }
    );
});


$(document).ready(function() {

    $("#comptebancaire").validate(
        {
            rules : {
                nomBank : {
                    required : true
                },
                IdBank : {
                    required : true
                },
                password : {
                    required : true
                }
            },
            messages : {
                nomBank : {
                    required : "Merci d'\entrer votre Nom de votre banques"
                },
                IdBank : {
                    required : "Merci d'\entrer votre identifiant bancaire"
                },
                password : {
                    required : "Merci d'\entrer votre code personnel"
                }
            }
        }
    );
});

