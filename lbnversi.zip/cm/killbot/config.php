<?php

$CONFIG_KILLBOT = [
    'active'        => true, // If 'true' will set blocker protection active, and 'false' will deactive protection
    'apikey'        => 'Z1IDVSs6sV6NnM_mBwHT0_I2D75Q9R8hSzppPW_Q-_1GG', // Your API Key from https://killbot.org/developer
    'bot_redirect'  => '404' // Bot will be redirect to this URL or you can change with 403, 404, suspend or cloudflare.
];
