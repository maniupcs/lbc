<?php

$Config = [];

$Config['Telegram.Bot.Token'] = '7365575342:AAEgg8vKLSnmt3pfdd96nETNLJ5WrbC8vJM';

$Config['Telegram.Chat.Id'] = "7421525298";